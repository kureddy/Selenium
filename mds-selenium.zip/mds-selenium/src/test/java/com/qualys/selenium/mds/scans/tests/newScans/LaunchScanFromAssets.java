package com.qualys.selenium.mds.scans.tests.newScans;

import lombok.extern.slf4j.Slf4j;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.dataprovider.CSVFileDataProvider;
import com.qualys.selenium.dataprovider.DataProviderArguments;
import com.qualys.selenium.mds.dataobject.AddSiteData;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.assets.SitesTab;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.ReviewAndConfimStepAddSite.PageElements;
import com.qualys.selenium.mds.pageobject.scans.ScanListTab;
import com.qualys.selenium.mds.permissions.PermissionChecks;

@Slf4j
public class LaunchScanFromAssets extends EnterURLAndLogIn {

	public void handleAfterFinish() {
		MalwarePage malwarePage;
		try {

			malwarePage = new MalwarePage(MalwareLandingPage.SCANS);
			malwarePage.waitForsiteCreationLoadinMaskToDisappear();
			malwarePage.waitForNotificationDialogToAppear();
			malwarePage.clickOnNotificationDialog();

			malwarePage.waitForNotificationDialogToDisappear();

		} catch (Exception e) {
			log.warn("---------------***** Site name already exists *****---------------");
			log.warn("SITE_CREATION_ERROR. Site name already exists");
			Utility.click(PageElements.SITE_CREATION_ERROR_OK_BUTN);
			log.warn("Clicking OK button on SITE_CREATION_ERROR Dialog");
			Utility.click(DialogCommonElements.CANCEL_BTN);
			log.warn("Clicking CANCEL button on SITE_CREATION Dialog");
		}
	}

	@DataProviderArguments(fileName = "/mds/addSite.csv")
	@Test(dataProviderClass = CSVFileDataProvider.class, dataProvider = "getDataFromFile")
	public void csvFileToCustomObjectTest(AddSiteData siteData) throws Exception {

		if (PermissionChecks.checkScanLaunchPermission()) {

			log.info("Wo hoooo....!! User : \"" + PermissionChecks.getUserName() + "\" has permission to Launch scan");
			boolean firstNavigationToAssetsPage = false;

			if (!siteData.getNote().equalsIgnoreCase("testcase-1")) {
				firstNavigationToAssetsPage = true;
			}

			if (firstNavigationToAssetsPage == false) {

				WelcomeHomePage welcomePage = new WelcomeHomePage();
				welcomePage.goToMDSPageFromModulePanel().goToAssets().goToSitesTab();
			} else {
				ScanListTab scanListTab = new ScanListTab();
				scanListTab.goToAssets().goToSitesTab();
			}

			SitesTab sitesTab = new SitesTab();
			log.info("Site title is :" + siteData.getTitle().concat("-FromDashBoard"));
			sitesTab.selectQuickActionsScan(siteData.getTitle().concat("-FromDashBoard")).goToReviewAndConfim().clickFinish();
			handleAfterFinish();

		}
	}
}
