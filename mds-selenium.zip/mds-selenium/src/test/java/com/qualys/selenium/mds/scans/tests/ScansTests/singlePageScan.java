package com.qualys.selenium.mds.scans.tests.ScansTests;

import lombok.extern.slf4j.Slf4j;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.scans.ScanListTab;

@Slf4j
public class singlePageScan extends EnterURLAndLogIn {

	public void handleAfterFinish() {
		try {
			MalwarePage malwarePage = new MalwarePage(MalwareLandingPage.DASHBOARD);
			malwarePage.waitForNotificationDialogToAppear();

			malwarePage.clickOnNotificationDialog();

			malwarePage.waitForNotificationDialogToDisappear();

		} catch (Exception e) {
			log.warn("There is an error.Please check");
		}
	}

	@Test(priority = 1)
	public void launchSinglePageScanAndVerify() throws ElementNotFoundException {
		try {
			WelcomeHomePage welcomeHomePage = new WelcomeHomePage();
			welcomeHomePage.goToMDSPageFromModulePanel().goToScans().goToScanListTab().clickNewScan().selectNewScanSinglePage().typePageURL("http://www.mwtest.info/malware-demos-named")
					.clickScanBtn();

			handleAfterFinish();
			ScanListTab scanListTab = new ScanListTab();
			boolean isSinglePageScanLaunched = scanListTab.refreshScanListPage().isScanLaunched("Page Scan");

			if (isSinglePageScanLaunched) {
				log.info("Single page scan is launched");
			} else {
				Assert.fail("Single page scan is not launched");
			}
		} catch (RuntimeException e) {
			Assert.fail(e.getMessage());
		}
	}
	
	
}
