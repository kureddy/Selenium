package com.qualys.selenium.mds.scans.tests.reportsPortableDocFormat;

import lombok.extern.slf4j.Slf4j;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.dialogs.reports.NewReport.ReportType;
import com.qualys.selenium.mds.pageobject.reports.ReportListTab;
import com.qualys.selenium.mds.pageobject.reports.SummaryReportTab;

@Slf4j
public class SummaryReportPortableDocFormat extends EnterURLAndLogIn {

	public MalwarePage goToMDSModule() throws ElementNotFoundException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();
		try {
			welcomePage.goToMDSPageFromModulePanel();
		} catch (ElementNotFoundException e) {
			// TODO Auto-generated catch block
			e.logException("Some issue while going to MDS page from welcome page");
		}

		return new MalwarePage(MalwareLandingPage.DASHBOARD);
	}

	@Test(priority = 1)
	public void createSummaryReportBySite() throws ElementNotFoundException, InterruptedException {

		log.info("\n \n ************* Summary report by Site name test *************\n");

		String summaryReportBySite = "summaryReportBySiteName-" + Utility.getTime();
		// ReportListTab reportListTab = new ReportListTab();
		SummaryReportTab summaryReport = (SummaryReportTab) goToMDSModule().goToReports().goToReportList().clickNewReportBtn().selectReportFromDropDown(ReportType.SUMMARY)
				.clickReportBySiteSearchTrigger().selectSiteName("auto5-scheduleMonthly-Day-FromDashBoard").clickSelectBtn().clickCreateBtn();
		ReportListTab reportListTab = new ReportListTab();
		boolean isReportCreated = summaryReport.editAndSaveSummaryReportTitle(summaryReportBySite).selectPortableDocFormatPDF().addTagsToReport("Asset Name Contains").clickSaveBtn().closeSummaryReport()
				.verifyIfReportIsListed(summaryReportBySite);
		
		
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(summaryReportBySite, "PDF Document");
		boolean isTypeSummary = reportListTab.verifyTypeOfReport(summaryReportBySite, "Summary Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(summaryReportBySite);
		if (isReportCreated && isFormatHTML && isTypeSummary && isStatusComplete) {
			log.info("Summary report by site name : " + summaryReportBySite + " is created");
		} else {
			if(!isReportCreated)
			{
				Assert.fail("Summary report is not created.There is some issue.So failing the test case");
			}else if(!isFormatHTML)
			{
				Assert.fail("Format of Summary report is not expected");
			}else if(!isStatusComplete)
			{
				Assert.fail("Status of Summary report is not expected");
			}else
			{
				Assert.fail("Some thing was wrong while creating Summary report ");
			}
	}
	}

	@Test(priority = 2)
	public void createSummaryReportByTag() throws ElementNotFoundException, InterruptedException {

		log.info("\n \n ************* Summary report by Tag test *************\n");

		String summaryReportByTag = "summaryReportByTag-" + Utility.getTime();
		ReportListTab reportListTab = new ReportListTab();
		SummaryReportTab summaryReport = (SummaryReportTab) reportListTab.clickNewReportBtn().selectReportFromDropDown(ReportType.SUMMARY).selectTags("Asset Name Contains").clickCreateBtn();

		boolean isReportCreated = summaryReport.editAndSaveSummaryReportTitle(summaryReportByTag).selectPortableDocFormatPDF().addTagsToReport("Asset Name Contains").clickSaveBtn().closeSummaryReport()
				.verifyIfReportIsListed(summaryReportByTag);
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(summaryReportByTag, "PDF Document");
		boolean isTypeSummary = reportListTab.verifyTypeOfReport(summaryReportByTag, "Summary Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(summaryReportByTag);
		if (isReportCreated && isFormatHTML && isTypeSummary && isStatusComplete) {
			log.info("Summary report by tag : " + summaryReportByTag + " is created");
		} else {
			if(!isReportCreated)
			{
				Assert.fail("Summary report is not created.There is some issue.So failing the test case");
			}else if(!isFormatHTML)
			{
				Assert.fail("Format of Summary report is not expected");
			}else if(!isStatusComplete)
			{
				Assert.fail("Status of Summary report is not expected");
			}else
			{
				Assert.fail("Some thing was wrong while creating Summary report ");
			}
	}
	}

	/*@Test(priority = 3)// this test is worling.Commented out coz,By URL test is not required.
	public void createSummaryReportByURL() throws ElementNotFoundException, InterruptedException {

		log.info("\n \n ************* Summary report by URL test *************\n");

		String summaryReportByURL = "summaryReportByURL-" + Utility.getTime();
		ReportListTab reportListTab = new ReportListTab();
		SummaryReportTab summaryReport = (SummaryReportTab) reportListTab.clickNewReportBtn().selectReportFromDropDown(ReportType.SUMMARY).clickReportBySiteSearchTrigger()
				.selectURL("http://funkytown.vuln.qa.qualys.com/cassium/").clickSelectBtn().clickCreateBtn();

		boolean isReportCreated = summaryReport.editAndSaveSummaryReportTitle(summaryReportByURL).selectPortableDocFormatPDF().addTagsToReport("Asset Name Contains").clickSaveBtn().closeSummaryReport().goToReportList()
				.verifyIfReportIsListed(summaryReportByURL);
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(summaryReportByURL, "PDF Document");
		boolean isTypeSummary = reportListTab.verifyTypeOfReport(summaryReportByURL, "Summary Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(summaryReportByURL);
		if (isReportCreated && isFormatHTML && isTypeSummary && isStatusComplete) {
			log.info("Summary report by URL : " + summaryReportByURL + " is created");
		} else {
			if(!isReportCreated)
			{
				Assert.fail("Summary report is not created.There is some issue.So failing the test case");
			}else if(!isFormatHTML)
			{
				Assert.fail("Format of Summary report is not expected");
			}else if(!isStatusComplete)
			{
				Assert.fail("Status of Summary report is not expected");
			}else
			{
				Assert.fail("Some thing was wrong while creating Summary report ");
			}
	}
	}*/

}
