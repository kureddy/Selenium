package com.qualys.selenium.mds.scans.tests.ScansTests;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.scans.ScansPage;

public class EntireSiteScanTests  extends EnterURLAndLogIn {

	public ScansPage goToScansPage() throws ElementNotFoundException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();
		return welcomePage.goToMDSPageFromModulePanel().goToScans();
	}

	
	@Test
	public void scanEntireSite() throws InterruptedException, ElementNotFoundException
	{
		
		
		//ScanListTab scanListTab = new ScanListTab();
		
	goToScansPage().goToScanListTab().clickNewScan().selectNewScanEntireSite().typeScanTitle("gnlsz;kdjgklsz")
	.selectScanTitleFromDopDown("LDnhvljADf");
	}
	
	
	
	
}
