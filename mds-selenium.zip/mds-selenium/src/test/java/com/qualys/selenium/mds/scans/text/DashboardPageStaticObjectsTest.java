package com.qualys.selenium.mds.scans.text;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;

public class DashboardPageStaticObjectsTest extends EnterURLAndLogIn{

    @Test
    public void testPageObjectsOfAddSite() throws ElementNotFoundException{ 
        WelcomeHomePage welcomePage = new WelcomeHomePage();

        // From welcome page go to MDS page
        MalwarePage malwarePage = welcomePage.goToMDSPageFromModulePanel();

        // From malware page go to dashboard page
        DashboardPage dashboardPage = malwarePage.goToDashBoard();
        
        
        dashboardPage.verifyDashboardPageStaticText();
    }
    
}
