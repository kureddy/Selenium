package com.qualys.selenium.mds.scans.tests;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import org.testng.annotations.Test;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.permissions.PermissionChecks;
import com.qualys.selenium.mds.permissions.PermissionServices;
import com.qualys.selenium.mds.permissions.QueryDB;

@Slf4j
public class CheckAutoFillSiteTitle extends EnterURLAndLogIn {

	public List<String> getSiteTitles() {
		String sqlQuery = "select NAME from GRC.ASSET where CUSTOMER_ID=186926 and ASSET_TYPE='MALWARE_DOMAIN'  and deleted != 1";
		List<String> siteTitles = QueryDB.executeQuery(sqlQuery, "NAME");
		return siteTitles;
	}

	public List<String> getSiteUrls() {
		String sqlQuery = "select URL from GRC.MALWARE_DOMAIN m inner join GRC.ASSET a on a.ID=m.ASSET_ID and a.CUSTOMER_ID=186926 and a.ASSET_TYPE='MALWARE_DOMAIN' and a.DELETED!=1";
		List<String> siteUrls = QueryDB.executeQuery(sqlQuery, "URL");
		return siteUrls;
	}

	 @Test
	public void compareAutoFillDropDownSiteData() throws ElementNotFoundException {

		if (PermissionChecks.hasPermission(PermissionServices.MALWARE_SCAN_LAUNCH.getName())) {
			log.info("Wo hoooo....!! User : \"" + PermissionChecks.getUserName() + "\" has permission to launch scan");

			WelcomeHomePage welcomePage = new WelcomeHomePage() ;

			List<String> siteTitlesAndurls = welcomePage.goToMDSPageFromModulePanel().goToDashBoard().clickNewScanEntireSite().goToTargetStep().clickSiteTitleDropDown().getSiteTitleDL();
			List<String> siteTitlesOnly = new ArrayList<String>();
			List<String> siteURLOnly = new ArrayList<String>();

			String[] splitSiteDetails = null;

			for (int i = 0; i < siteTitlesAndurls.size(); i++) {

				splitSiteDetails = siteTitlesAndurls.get(i).split("\n|URL:");

			}

			for (int i = 0; i < splitSiteDetails.length; i = i + 3) {

				siteTitlesOnly.add(splitSiteDetails[i]);
				siteTitlesOnly.add("s,dgbsaklg");
			}
			for (int i = 2; i < splitSiteDetails.length; i = i + 3) {

				siteURLOnly.add(splitSiteDetails[i]);
				siteURLOnly.add("sLKghl;SGe");
			}

			Collection<String> similarTitles = new HashSet<String>(siteTitlesOnly);
			Collection<String> differentTitles = new HashSet<String>();

			Collection<String> similarUrls = new HashSet<String>(siteURLOnly);
			Collection<String> differentUrls = new HashSet<String>();

			if (getSiteTitles().containsAll(siteTitlesOnly)) {
				log.info("Contains all the domains");
			} else {

				differentTitles.addAll(siteTitlesOnly);
				differentTitles.addAll(getSiteTitles());

				similarTitles.retainAll(getSiteTitles());
				differentTitles.removeAll(similarTitles);

				log.warn("some titles are  matching");
				log.info("**************differences in data******************");
				log.info("\n\nTitles from DB : " + getSiteUrls() + "\n\nTitles from UI " + siteTitlesOnly + "\n\nSimilar :" + similarTitles + "\n\nDifferent : " + differentTitles);
				// System.out.printf("\nFrom DB : %s%n From UI : %s%n Similar Titles : %s%n Difference : %s%n ",
				// getSiteUrls() , siteTitlesOnly,similar,different);
			}

			if (getSiteUrls().containsAll(siteURLOnly)) {
				log.info("Contains all the domains");
			} else {

				differentUrls.addAll(siteURLOnly);
				differentUrls.addAll(getSiteUrls());

				similarUrls.retainAll(getSiteUrls());
				differentUrls.removeAll(similarUrls);

				log.warn("some titles are  matching");
				log.info("**************differences in data******************");
				log.info("\n\nTitles from DB : " + getSiteUrls() + "\n\nTitles from UI " + siteURLOnly + " \n\nSimilar :" + similarUrls + "\n\nDifferent : " + differentUrls);
				log.warn("some URLS are not matching");
			}
		}

	}

}
