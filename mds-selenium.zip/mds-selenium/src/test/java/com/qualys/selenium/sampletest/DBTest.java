package com.qualys.selenium.sampletest;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.testng.annotations.Test;

import com.qualys.selenium.core.JDBConnection;

public class DBTest {
    protected JDBConnection dbConnection;

    /*public  DBTest()  {
        dbConnection = JDBConnection.getInstance();
    }*/
   
    public int testDB()
    {
        
        int data = 0;
        
        String sqlQuery = "select CUSTOMER_ID from GRC.USER_LOCAL where USERNAME='superuser'";
        Connection conn = JDBConnection.getDB();
        try{
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlQuery);
            while(rs.next())
            {
                int cust_id= rs.getInt("CUSTOMER_ID");
                System.out.println(cust_id);
            }
            
            stmt.close();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return data;
    }
   @Test
    public void test()
    {
        System.out.println(testDB());
    }
}
