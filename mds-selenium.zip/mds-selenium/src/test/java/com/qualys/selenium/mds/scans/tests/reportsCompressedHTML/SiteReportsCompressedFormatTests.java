package com.qualys.selenium.mds.scans.tests.reportsCompressedHTML;

import lombok.extern.slf4j.Slf4j;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.dialogs.reports.NewReport.ReportType;
import com.qualys.selenium.mds.pageobject.reports.ReportListTab;
import com.qualys.selenium.mds.pageobject.reports.SiteReportTab;

@Slf4j
public class SiteReportsCompressedFormatTests extends EnterURLAndLogIn {

	public MalwarePage goToMDSModule() throws ElementNotFoundException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();
		try {
			welcomePage.goToMDSPageFromModulePanel();
		} catch (ElementNotFoundException e) {
			// TODO Auto-generated catch block
			e.logException("Some issue while going to MDS page from welcome page");
		}

		return new MalwarePage(MalwareLandingPage.DASHBOARD);
	}

	/*
	 * 1. Create a site report by site URL 2. save the compressed HTML of site
	 * report 3. Verify if the site report is listed in report list tab
	 */
/*
	@Test(priority = 1) // this test is worling.Commented out coz, Site URL test is not required.
	public void createSiteReportByURLAndVerify() throws ElementNotFoundException, InterruptedException {
		log.info("\n \n ************* Site report by site URL test ************* \n");
		String siteReportTitle = "siteReportByURL-" + Utility.getTime();
		// ReportListTab reportListTab = new ReportListTab();

		SiteReportTab siteReportTab = (SiteReportTab) goToMDSModule().goToReports().goToReportList().clickNewReportBtn().selectReportFromDropDown(ReportType.SITE).clickReportBySiteSearchTrigger()
				.selectURL("http://lamp.vuln.qa.qualys.com/").clickSelectBtn().clickCreateBtn();
		boolean isReportCreated = siteReportTab.editAndSaveSiteReportTitle(siteReportTitle).selectCompressedHTML().addTagsToReport("Asset Name Contains").clickSaveBtn().closeSiteReport().goToReportList()
				.verifyIfReportIsListed(siteReportTitle);
		ReportListTab reportListTab = new ReportListTab();
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(siteReportTitle, "HTML (Zipped)");
		boolean isTypeSite = reportListTab.verifyTypeOfReport(siteReportTitle, "Site Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(siteReportTitle);
		if (isReportCreated && isFormatHTML && isTypeSite && isStatusComplete) {
			log.info("Site report by site URL : " + siteReportTitle + " is created");
		} else {
			if (!isReportCreated) {
				Assert.fail("Site report is not created.There is some issue.So failing the test case");
			} else if (!isFormatHTML) {
				Assert.fail("Format of Site report is not expected");
			} else if (!isStatusComplete) {
				Assert.fail("Status of Site report is not expected");
			} else {
				Assert.fail("Some thing was wrong while creating Site report ");
			}
		}

	}*/

	/*
	 * 1. Create a site report by site Name 2. save the compressed HTML of site
	 * report 3. Verify if the site report is listed in report list tab
	 */
	@Test(priority = 1)
	public void createSiteReportBySiteNameAndVerify() throws ElementNotFoundException, InterruptedException {
		log.info("\n \n ************* Site report by scan Name test *************\n");
		String siteReportTitle = "siteReportBySiteName-" + Utility.getTime();
		

		SiteReportTab siteReportTab = (SiteReportTab) goToMDSModule().goToReports().goToReportList().clickNewReportBtn().selectReportFromDropDown(ReportType.SITE).clickReportBySiteSearchTrigger().selectSiteName("auto9-IP-save-scan-FromAssetsTab")
				.clickSelectBtn().clickCreateBtn();
		boolean isReportCreated = siteReportTab.editAndSaveSiteReportTitle(siteReportTitle).selectCompressedHTML().addTagsToReport("Asset Name Contains").clickSaveBtn().closeSiteReport().goToReportList()
				.verifyIfReportIsListed(siteReportTitle);
		ReportListTab reportListTab = new ReportListTab();
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(siteReportTitle, "HTML (Zipped)");
		boolean isTypeSite = reportListTab.verifyTypeOfReport(siteReportTitle, "Site Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(siteReportTitle);
		if (isReportCreated && isFormatHTML && isTypeSite && isStatusComplete) {
			log.info("Site report by site name :  " + siteReportTitle + " is created");
		} else {
			if (!isReportCreated) {
				Assert.fail("Site report is not created.There is some issue.So failing the test case");
			} else if (!isFormatHTML) {
				Assert.fail("Format of Site report is not expected");
			} else if (!isStatusComplete) {
				Assert.fail("Status of Site report is not expected");
			} else {
				Assert.fail("Some thing was wrong while creating Site report ");
			}
		}

	}

	@Test(priority = 2)
	public void createSiteReportByTagAndVerify() throws ElementNotFoundException, InterruptedException {
		log.info("\n \n ************* Site report by tag test *************\n");

		String siteReportByTag = "siteReportByTag-" + Utility.getTime();
		ReportListTab reportListTab = new ReportListTab();
		SiteReportTab siteReport = (SiteReportTab)  reportListTab.clickNewReportBtn().selectReportFromDropDown(ReportType.SITE).selectTags("Asset Name Contains").clickCreateBtn();

		boolean isReportCreated = siteReport.editAndSaveSiteReportTitle(siteReportByTag).selectCompressedHTML().addTagsToReport("Asset Name Contains").clickSaveBtn().closeSiteReport().verifyIfReportIsListed(siteReportByTag);
		
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(siteReportByTag, "HTML (Zipped)");
		boolean isTypeSite = reportListTab.verifyTypeOfReport(siteReportByTag, "Site Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(siteReportByTag);
		if (isReportCreated && isFormatHTML && isTypeSite && isStatusComplete) {
			log.info("Site report by tag : " + siteReportByTag + " is created");
		} else {
			if (!isReportCreated) {
				Assert.fail("Site report is not created.There is some issue.So failing the test case");
			} else if (!isFormatHTML) {
				Assert.fail("Format of Site report is not expected");
			} else if (!isStatusComplete) {
				Assert.fail("Status of Site report is not expected");
			} else {
				Assert.fail("Some thing was wrong while creating Site report ");
			}
		}
	}

}
