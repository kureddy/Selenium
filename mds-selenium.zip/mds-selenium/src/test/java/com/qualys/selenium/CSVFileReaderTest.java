package com.qualys.selenium;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.dataprovider.CSVFileDataProvider;
import com.qualys.selenium.dataprovider.DataProviderArguments;
import com.qualys.selenium.mds.dataobject.NewScanData;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite.NewScanEntireSiteDialog;

public class CSVFileReaderTest extends EnterURLAndLogIn{

	@DataProviderArguments(fileName="/sample.csv")
	@Test(dataProviderClass=CSVFileDataProvider.class, dataProvider="getDataFromFile")
	public void csvFileToParameterTest(String x, int y){
		System.out.println(x + ":" + y);
	}
	
	@DataProviderArguments(fileName="/new-scan-data.csv")
	@Test(dataProviderClass=CSVFileDataProvider.class, dataProvider="getDataFromFile")
	public void csvFileToCustomObjectTest(NewScanData test) throws ElementNotFoundException{
		
		WelcomeHomePage welcomePage = new WelcomeHomePage();

        // From welcome page go to MDS page
        MalwarePage malwarePage = welcomePage.goToMDSPageFromModulePanel();

        // From malware page go to dashboard page
        DashboardPage dashboardPage = malwarePage.goToDashBoard();
        
        // Click on new scan entire site
        NewScanEntireSiteDialog newScanEntireSitePage = dashboardPage.clickNewScanEntireSite();

        newScanEntireSitePage.goToTargetStep().selectTargetScanIntensity(test.getIntensity()).selectTargetSiteTitle(test.title);
	}
}
