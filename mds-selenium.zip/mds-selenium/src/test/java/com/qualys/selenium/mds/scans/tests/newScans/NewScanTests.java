package com.qualys.selenium.mds.scans.tests.newScans;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.scans.ScanListTab;
import com.qualys.selenium.mds.permissions.QueryDB;

@Slf4j
public class NewScanTests extends EnterURLAndLogIn {

	public List<String> getAllSitesFromDB() {
		String sqlQuery = "select DISTINCT(a.NAME) from GRC.ASSET a inner join GRC.MALWARE_DOMAIN md on a.ID=md.ASSET_ID inner join GRC.SCAN_MALWARE sm on md.ASSET_ID=sm.MALWARE_ASSET_ID inner join GRC.SCAN s  on s.ID=sm.SCAN_ID  where a.USER_ID=1740919 and s.DELETED=0 and a.DELETED=0 and md.DELETED=0";
		List<String> siteTitles = QueryDB.executeQuery(sqlQuery, "NAME");
		return siteTitles;
	}

	public List<String> getAllScansOFSite(String siteName) {
		String sqlQuery = "select s.TITLE from GRC.ASSET a inner join GRC.MALWARE_DOMAIN md on a.ID=md.ASSET_ID inner join GRC.SCAN_MALWARE sm on md.ASSET_ID=sm.MALWARE_ASSET_ID  inner join GRC.SCAN s on s.ID=sm.SCAN_ID  where a.USER_ID=1740919 and a.NAME=+\'"
				+ siteName + "\'";
		List<String> siteTitles = QueryDB.executeQuery(sqlQuery, "Title");
		return siteTitles;
	}

	public ScanListTab goToScansListTab() throws ElementNotFoundException {

		WelcomeHomePage welcomePage = new WelcomeHomePage();
		ScanListTab scanListTab;
		scanListTab = welcomePage.goToMDSPageFromModulePanel().goToScans().goToScanListTab();
		return scanListTab;

	}

	// Check if, the scans of corresponding assets when filtered by sites panel
	// on the left side of Scans Lists tab are shown on Scans list DL
	
	// TODO -Blocked by bug :  MSUI-867 : MDS pagination issue
	@Test
	public void scanListDLFilterBySiteVerify() throws ElementNotFoundException {

		goToScansListTab();

		// Assert.assertEquals(actual, expected);

		for (int i = 0; i < getAllSitesFromDB().size(); i++) {
			ScanListTab scanListTab = new ScanListTab();
			
			//Select the site and click on site on left panel 
			scanListTab.clickLeftPanelScanssDataFilter(getAllSitesFromDB().get(i));

			List<String> actual = scanListTab.getAllScansTitleText();
			
			//Get All the scans of the site
			List<String> expected = getAllScansOFSite(getAllSitesFromDB().get(i));
			// expected.add("s.dflas;dngl");
			Collection<String> similarTitles = new HashSet<String>(actual);
			Collection<String> differentTitles = new HashSet<String>();

			//Check if data in DB and UI matches
			if (actual.containsAll(expected)) {
				log.info("Assert passed");
			} 
			//Else fail the assert and log the similar and different scans.
			else {
				differentTitles.addAll(actual);
				differentTitles.addAll(expected);

				similarTitles.retainAll(expected);
				differentTitles.removeAll(similarTitles);
				log.warn("Similar : " + similarTitles + "\n different : " + differentTitles);
				Assert.fail("Test case failed as the data list does not match with DB data. Different DL : "  +differentTitles);
			}
		}

	}

}
