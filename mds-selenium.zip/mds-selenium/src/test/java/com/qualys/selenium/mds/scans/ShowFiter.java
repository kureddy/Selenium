package com.qualys.selenium.mds.scans;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.reports.ReportListTab;
import com.qualys.selenium.mds.pageobject.reports.ReportsPage;
import com.qualys.selenium.mds.pageobject.scans.ScansPage;

public class ShowFiter extends EnterURLAndLogIn {

    ReportsPage reportsPage;
    ReportListTab reportListTab;

    @Test
    public void test() throws InterruptedException, ElementNotFoundException {

        WelcomeHomePage welcomePage = new WelcomeHomePage();

        // From welcome page go to MDS page
        MalwarePage malwarePage = welcomePage.goToMDSPageFromModulePanel();

        ScansPage scansPage = malwarePage.goToScans();
        scansPage.goToScanListTab().clickShowFilters()
        .filterByTags("IpRange").filterByTodayScanDate();
        

    }
}
