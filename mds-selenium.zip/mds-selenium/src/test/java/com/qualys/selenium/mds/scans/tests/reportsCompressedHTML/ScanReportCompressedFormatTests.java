package com.qualys.selenium.mds.scans.tests.reportsCompressedHTML;

import lombok.extern.slf4j.Slf4j;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.dialogs.reports.NewReport.ReportType;
import com.qualys.selenium.mds.pageobject.reports.ReportListTab;
import com.qualys.selenium.mds.pageobject.reports.ScanReportTab;

@Slf4j
public class ScanReportCompressedFormatTests extends EnterURLAndLogIn {

	public MalwarePage goToMDSModule() throws ElementNotFoundException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();
		try {
			welcomePage.goToMDSPageFromModulePanel();
		} catch (ElementNotFoundException e) {
			// TODO Auto-generated catch block
			e.logException("Some issue while going to MDS page from welcome page");
		}

		return new MalwarePage(MalwareLandingPage.DASHBOARD);
	}

	/*
	 * 1. Create a scan report by scan date 2. save the compressed HTML of scan
	 * report 3. Verify if the scan report is listed in report list tab
	 */
	//@Test(priority = 1) // this test is worling.Commented out coz, Scan date test is not required.
	/*public void createScanReportByScanDateAndVerify() throws ElementNotFoundException, InterruptedException {

		log.info("\n \n ************ Scan report by scan date test *************\n");
		String scanReportTitle = "scanReportByScanDate-" + Utility.getTime();
		// ReportListTab reportListTab = new ReportListTab();
		ScanReportTab scanReportTab = (ScanReportTab) goToMDSModule().goToReports().goToReportList().clickNewReportBtn().selectReportFromDropDown(ReportType.SCAN).clickReportByScanSearchTrigger()
				.selectScanDate("Wed Dec 10 2014 17:34:25 GMT-0800 (Pacific Standard Time)").clickSelectBtn().clickCreateBtn();

		boolean isReportCreated = scanReportTab.editAndSaveScanReportTitle(scanReportTitle).selectCompressedHTML().addTagsToReport("Asset Name Contains").clickSaveBtn().closeScanReport()
				.verifyIfReportIsListed(scanReportTitle);
		ReportListTab reportListTab = new ReportListTab();
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(scanReportTitle, "HTML (Zipped)");
		boolean isTypeScan = reportListTab.verifyTypeOfReport(scanReportTitle, "Scan Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(scanReportTitle);
		if (isReportCreated && isFormatHTML && isTypeScan && isStatusComplete) {
			log.info("Scan report by scan date : " + scanReportTitle + " is created");
		} else {
			if (!isReportCreated) {
				Assert.fail("Scan report is not created.There is some issue.So failing the test case");
			} else if (!isFormatHTML) {
				Assert.fail("Format of Scan report is not expected");
			} else if (!isStatusComplete) {
				Assert.fail("Status of Scan report is not expected.");
			} else {
				Assert.fail("Some thing was wrong while creating Scan report ");
			}

		}

	}*/

	/*
	 * 1. Create a scan report by scan Title 2. save the compressed HTML of scan
	 * report 3. Verify if the scan report is listed in report list tab
	 */
	@Test(priority = 1)
	public void createScanReportByScanTitleAndVerify() throws ElementNotFoundException, InterruptedException {
		log.info("\n \n ************* Scan report by scan title test *************\n");
		String scanReportTitle = "scanReportByScanTitle-" + Utility.getTime();

		
		ScanReportTab scanReportTab = (ScanReportTab) goToMDSModule().goToReports().goToReportList().clickNewReportBtn().selectReportFromDropDown(ReportType.SCAN).clickReportByScanSearchTrigger().selectScanTitle("Scan auto9-IP-save-scan-FromDashBoard")
				.clickSelectBtn().clickCreateBtn();

		boolean isReportCreated = scanReportTab.editAndSaveScanReportTitle(scanReportTitle)
				.selectCompressedHTML()
				.addTagsToReport("Asset Name Contains")
				.clickSaveBtn().closeScanReport()
				.verifyIfReportIsListed(scanReportTitle);
		
		ReportListTab reportListTab = new ReportListTab();
		boolean isFormatHTML = reportListTab.verifyFormatOfReport(scanReportTitle, "HTML (Zipped)");
		boolean isTypeScan = reportListTab.verifyTypeOfReport(scanReportTitle, "Scan Report");
		boolean isStatusComplete = reportListTab.verifyStatuseOfReport(scanReportTitle);
		if (isReportCreated && isFormatHTML && isTypeScan && isStatusComplete) {
			log.info("Scan report by scan title : " + scanReportTitle + " is created");
		} else {
			if (!isReportCreated) {
				Assert.fail("Scan report is not created.There is some issue.So failing the test case");
			} else if (!isFormatHTML) {
				Assert.fail("Format of Scan report is not expected");
			} else if (!isStatusComplete) {
				Assert.fail("Status of Scan report is not expected");
			} else {
				Assert.fail("Some thing was wrong while creating Scan report ");
			}
		}
	}

}
