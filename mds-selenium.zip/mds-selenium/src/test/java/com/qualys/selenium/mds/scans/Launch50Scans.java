package com.qualys.selenium.mds.scans;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.scans.ScanListTab;

public class Launch50Scans extends EnterURLAndLogIn {

	// Testcase to reproduce bug Deadlock when trying to update scan MSUI-830
	// Comenting this test as I dont want it in test suite
	 @Test
	public void launch50Scans() throws ElementNotFoundException, InterruptedException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();
		welcomePage.goToMDSPageFromModulePanel().goToScans().goToScanListTab();
		ScanListTab scanListTab = new ScanListTab();
		for (int i = 0; i <= 50; i++) {
			scanListTab.selectQuickActionsScanAgain("auto").clickContinue().clickFinish();

			MalwarePage malwarePage = new MalwarePage(MalwareLandingPage.SCANS);
			malwarePage.waitForNotificationDialogToAppear();
			malwarePage.clickOnNotificationDialog();

		}

	}

}
