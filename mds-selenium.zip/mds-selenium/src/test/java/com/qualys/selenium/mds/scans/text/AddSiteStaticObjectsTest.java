package com.qualys.selenium.mds.scans.text;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.ReviewAndConfimStepAddSite;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.SchedulingStep;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.SiteDetailsStep;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog.AddSiteDialogMode;
import com.qualys.selenium.mds.permissions.PermissionChecks;
import com.qualys.selenium.mds.permissions.PermissionServices;

public class AddSiteStaticObjectsTest extends EnterURLAndLogIn {

	@Test
	public void testPageObjectsOfAddSite() throws SiteCreationMaxedOutException, ElementNotFoundException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();

		// From welcome page go to MDS page
		MalwarePage malwarePage = welcomePage.goToMDSPageFromModulePanel();

		// From malware page go to dashboard page
		DashboardPage dashboardPage = malwarePage.goToDashBoard();

		dashboardPage.clickOnAddSiteLink();
		AddSiteDialog addSiteDialog = new AddSiteDialog(AddSiteDialogMode.CREATE);
		addSiteDialog.verifySideBarStepsStaticText();

		SiteDetailsStep siteDetailsStep = new SiteDetailsStep(AddSiteDialogMode.CREATE);
		siteDetailsStep.goToSiteDetails().typeSiteDetailsTitle("test1").typeSiteDetailsSiteURL("http://testURL.com")
		.verifySiteDetailsStepStaticText().clickContinue().clickContinue()
				.verifyCrawlExclusionListStepStaticText().clickContinue();

		if (PermissionChecks.hasPermission(PermissionServices.MALWARE_SCAN_SCHEDULE_CREATE.getName())) {
			SchedulingStep schedulingStep = new SchedulingStep(AddSiteDialogMode.CREATE);
			schedulingStep.verifySchedulingStepStaticText().clickContinue();
		} else {
			ReviewAndConfimStepAddSite reviewAndConfimStep = new ReviewAndConfimStepAddSite(AddSiteDialogMode.CREATE);
			reviewAndConfimStep
			.verifyReviewAndConfirmStepStaticText();

		}
	}
}
