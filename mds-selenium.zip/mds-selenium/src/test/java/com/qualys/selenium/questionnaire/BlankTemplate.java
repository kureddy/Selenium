package com.qualys.selenium.questionnaire;

import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;

public class BlankTemplate extends EnterURLAndLogIn {

	@Test
	public void clickOnBlankTemplate() throws ElementNotFoundException
	{
		WelcomeHomePage welcomePage = new WelcomeHomePage();
		welcomePage.goToQuestionnairePageFromModulePanel();
	}
}
