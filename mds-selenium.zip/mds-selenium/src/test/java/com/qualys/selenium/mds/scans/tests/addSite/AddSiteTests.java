package com.qualys.selenium.mds.scans.tests.addSite;

import lombok.extern.slf4j.Slf4j;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.dataprovider.CSVFileDataProvider;
import com.qualys.selenium.dataprovider.DataProviderArguments;
import com.qualys.selenium.mds.dataobject.AddSiteData;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.assets.SitesTab;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog.AddSiteDialogMode;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.ReviewAndConfimStepAddSite;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.ReviewAndConfimStepAddSite.LandingPageAfterAddSite;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.ReviewAndConfimStepAddSite.PageElements;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.SchedulingStep;
import com.qualys.selenium.mds.permissions.PermissionChecks;
import com.qualys.selenium.mds.permissions.PermissionServices;

@Slf4j
public class AddSiteTests extends EnterURLAndLogIn {
	String landingOn;

	public void handleAfterFinish() {
		MalwarePage malwarePage;
		try {
			if (landingOn.equals("dashboard")) {
				malwarePage = new MalwarePage(MalwareLandingPage.DASHBOARD);
			} else {
				malwarePage = new MalwarePage(MalwareLandingPage.ASSETS);
			}
			malwarePage.waitForsiteCreationLoadinMaskToDisappear();
			malwarePage.waitForNotificationDialogToAppear();
			malwarePage.clickOnNotificationDialog();

			malwarePage.waitForNotificationDialogToDisappear();

		} catch (Exception e) {
			log.warn("---------------***** Site name already exists *****---------------");
			log.warn("SITE_CREATION_ERROR. Site name already exists");
			Utility.click(PageElements.SITE_CREATION_ERROR_OK_BUTN);
			log.warn("Clicking OK button on SITE_CREATION_ERROR Dialog");
			Utility.click(DialogCommonElements.CANCEL_BTN);
			log.warn("Clicking CANCEL button on SITE_CREATION Dialog");
		}
	}

	public boolean checkSiteCreationError(AddSiteDialog addSiteDialog) {
		boolean errorExists = false;
		if (addSiteDialog == null) {
			errorExists = true;
		} else {
			errorExists = false;
		}

		return errorExists;
	}

	@DataProviderArguments(fileName = "/mds/addSite.csv")
	@Test(priority = 1, dataProviderClass = CSVFileDataProvider.class, dataProvider = "getDataFromFile")
	public void addSitesFromDashboard(AddSiteData siteData) throws Exception {
		landingOn = "dashboard";
		log.info("\n\n ******************** Executing :" + siteData.getNote() + " *********************** \n");

		if (PermissionChecks.checkAddSitePermission()) {
			log.info("Wo hoooo....!! User : \"" + PermissionChecks.getUserName() + "\" has permission to create site");
			boolean firstNavigationToAddSiteLink = false;
			boolean siteCreationErrorExists = false;

			if (!siteData.getNote().equalsIgnoreCase("testcase-1")) {
				firstNavigationToAddSiteLink = true;
			}

			if (firstNavigationToAddSiteLink == false) {

				WelcomeHomePage welcomePage = new WelcomeHomePage();
				AddSiteDialog addSiteDialog = welcomePage.goToMDSPageFromModulePanel().goToDashBoard().clickOnAddSiteLink();
				siteCreationErrorExists = checkSiteCreationError(addSiteDialog);

			} else {

				DashboardPage dashboardPage = new DashboardPage();
				AddSiteDialog addSiteDialog = dashboardPage.clickOnAddSiteLink();
				siteCreationErrorExists = checkSiteCreationError(addSiteDialog);

			}

			if (!siteCreationErrorExists) {
				AddSiteDialog addSiteDialog = new AddSiteDialog(AddSiteDialogMode.CREATE);

				if (PermissionChecks.hasPermission(PermissionServices.MALWARE_SCAN_SCHEDULE_CREATE.getName())) {
					((SchedulingStep) addSiteDialog.goToSiteDetails().typeSiteDetailsTitle(siteData.getTitle().concat("-FromDashBoard")).typeSiteDetailsSiteURL(siteData.getUrl())
							.selectSiteDetailTags(siteData.getChooseTag()).clickContinue().typeMaximumPages(siteData.getMaxPages()).selectScanIntensity(siteData.getChooseIntensity())

							.typeInHeaderInjection(siteData.headers).clickContinue().typeURLInWhiteList(siteData.getUrlWL()).typeRegularExpressionInWhiteList(siteData.getRegExpWL())
							.typeURLInBlackList(siteData.getUrlBL()).typeRegularExpressionInBlackList(siteData.getRegExpBL()).clickContinue()).enableSchedulingCheckBox(siteData.getEnableSchedule());
					SchedulingStep schedulingStep = new SchedulingStep(AddSiteDialogMode.CREATE);
					if (siteData.enableSchedule.equalsIgnoreCase("yes")) {
						if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("Single Occurrence")) {
							schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).clickContinue();
						} else if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("Daily")) {
							schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
									.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).typeEveryXDays(siteData.getEvery_X_Days()).clickContinue();
						} else if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("weekly")) {

							schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
									.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).typeEndsAfterXWeeks(siteData.getEvery_X_Weeks()).selectDaysCheckBox(siteData.getRecurrenceOnDays())
									.clickContinue();
						} else if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("monthly")) {
							// First radio button
							if (siteData.getEnableXDayXOfEveryMonth().equalsIgnoreCase("yes") && siteData.getEnableXDayofXWeekXthMonth().equalsIgnoreCase("no")) {
								schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
										.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).enableXthDayOfXthMonth(siteData.getEnableXDayXOfEveryMonth()).clickContinue();
							} else if (siteData.getEnableXDayofXWeekXthMonth().equalsIgnoreCase("yes") && siteData.getEnableXDayXOfEveryMonth().equalsIgnoreCase("no")) {
								schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
										.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).enableXDayofXWeekXthMonth(siteData.getEnableXDayofXWeekXthMonth())
										.selectDayNumberInWords(siteData.getDayNumberInWords()).selectDayName(siteData.dayName).typeEveryXNoOfMonths(siteData.getMonthNumberB()).clickContinue();
							}

						}
					} else {
						schedulingStep.clickContinue();
					}
				} else {
					addSiteDialog.goToSiteDetails().typeSiteDetailsTitle(siteData.getTitle()).typeSiteDetailsSiteURL(siteData.getUrl()).selectSiteDetailTags(siteData.getChooseTag()).clickContinue()
							.typeMaximumPages(siteData.getMaxPages()).selectScanIntensity(siteData.getChooseIntensity()).typeInHeaderInjection(siteData.headers).clickContinue()
							.typeURLInWhiteList(siteData.getUrlWL()).typeRegularExpressionInWhiteList(siteData.getRegExpWL()).typeURLInBlackList(siteData.getUrlBL())
							.typeRegularExpressionInBlackList(siteData.getRegExpBL()).clickContinue();
				}

				ReviewAndConfimStepAddSite reviewAndConfimStep = new ReviewAndConfimStepAddSite(AddSiteDialogMode.CREATE);
				if (siteData.getAddSiteOrScan().equalsIgnoreCase("addSite") || siteData.getAddSiteOrScan().equalsIgnoreCase("add Site") || siteData.getAddSiteOrScan().equalsIgnoreCase("finish")) {
					reviewAndConfimStep.clickFinish(LandingPageAfterAddSite.DASHBOARD);
					handleAfterFinish();

				} else if (siteData.getAddSiteOrScan().equalsIgnoreCase("scan & Scan") || siteData.getAddSiteOrScan().equalsIgnoreCase("scan")) {
					reviewAndConfimStep.clickSaveAndScanNow(LandingPageAfterAddSite.DASHBOARD);
					handleAfterFinish();

				} else {
					log.error("AddSiteOrScan value from csv file /mds/addSiteNoSchedule.csv is invalid");
				}
			} else {
				log.error("As site creation error exists,Not executing the workFlow of textcase " + siteData.getNote());
				log.error("Check above error logs");
				MalwarePage.clickOkOfSiteCreationError();
				log.warn("Exiting from testcase and not executing rest of cases from CSV file");
				killBrowser();
				Assert.fail("Failing testcase");

			}

		} else {

			log.error("User do not have permission to create site");
		}
	}

	@DataProviderArguments(fileName = "/mds/addSite.csv")
	@Test(priority = 2, dataProviderClass = CSVFileDataProvider.class, dataProvider = "getDataFromFile")
	public void addSitesFromAssetsTab(AddSiteData siteData) throws Exception {
		landingOn = "assets";
		log.info("\n\n ******************** Executing :" + siteData.getNote() + " *********************** \n");

		if (PermissionChecks.checkAddSitePermission()) {
			log.info("Wo hoooo....!! User : \"" + PermissionChecks.getUserName() + "\" has permission to create site");
			boolean onSiteCreationDialog = false;
			boolean siteCreationErrorExists = false;

			if (!siteData.getNote().equalsIgnoreCase("testcase-1")) {
				onSiteCreationDialog = true;
			}

			if (onSiteCreationDialog == false) {

				MalwarePage malwarePage = new MalwarePage(MalwareLandingPage.DASHBOARD);
				AddSiteDialog addSiteDialog = malwarePage.goToAssets().clickAddSiteBtn();

				siteCreationErrorExists = checkSiteCreationError(addSiteDialog);

			} else {

				SitesTab sitesTab = new SitesTab();
				AddSiteDialog addSiteDialog = sitesTab.clickAddSiteBtn();
				siteCreationErrorExists = checkSiteCreationError(addSiteDialog);

			}

			if (!siteCreationErrorExists) {
				AddSiteDialog addSiteDialog = new AddSiteDialog(AddSiteDialogMode.CREATE);

				if (PermissionChecks.hasPermission(PermissionServices.MALWARE_SCAN_SCHEDULE_CREATE.getName())) {
					((SchedulingStep) addSiteDialog.goToSiteDetails().typeSiteDetailsTitle(siteData.getTitle().concat("-FromAssetsTab")).typeSiteDetailsSiteURL(siteData.getUrl())
							.selectSiteDetailTags(siteData.getChooseTag()).clickContinue().typeMaximumPages(siteData.getMaxPages()).selectScanIntensity(siteData.getChooseIntensity())

							.typeInHeaderInjection(siteData.headers).clickContinue().typeURLInWhiteList(siteData.getUrlWL()).typeRegularExpressionInWhiteList(siteData.getRegExpWL())
							.typeURLInBlackList(siteData.getUrlBL()).typeRegularExpressionInBlackList(siteData.getRegExpBL()).clickContinue()).enableSchedulingCheckBox(siteData.getEnableSchedule());
					SchedulingStep schedulingStep = new SchedulingStep(AddSiteDialogMode.CREATE);
					if (siteData.enableSchedule.equalsIgnoreCase("yes")) {
						if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("Single Occurrence")) {
							schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).clickContinue();
						} else if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("Daily")) {
							schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
									.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).typeEveryXDays(siteData.getEvery_X_Days()).clickContinue();
						} else if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("weekly")) {

							schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
									.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).typeEndsAfterXWeeks(siteData.getEvery_X_Weeks()).selectDaysCheckBox(siteData.getRecurrenceOnDays())
									.clickContinue();
						} else if (siteData.getChooseRecurrenceMode().equalsIgnoreCase("monthly")) {
							// First radio button
							if (siteData.getEnableXDayXOfEveryMonth().equalsIgnoreCase("yes") && siteData.getEnableXDayofXWeekXthMonth().equalsIgnoreCase("no")) {
								schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
										.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).enableXthDayOfXthMonth(siteData.getEnableXDayXOfEveryMonth()).clickContinue();
							} else if (siteData.getEnableXDayofXWeekXthMonth().equalsIgnoreCase("yes") && siteData.getEnableXDayXOfEveryMonth().equalsIgnoreCase("no")) {
								schedulingStep.selectRecurrenceMode(siteData.getChooseRecurrenceMode()).enableRecurrenceEndsAfter(siteData.getEnableRecurrenceEndsAfter())
										.typeRecurrenceOccurrences(siteData.getRecurrenceOccurrences()).enableXDayofXWeekXthMonth(siteData.getEnableXDayofXWeekXthMonth())
										.selectDayNumberInWords(siteData.getDayNumberInWords()).selectDayName(siteData.dayName).typeEveryXNoOfMonths(siteData.getMonthNumberB()).clickContinue();
							}

						}
					} else {
						schedulingStep.clickContinue();
					}
				} else {
					addSiteDialog.goToSiteDetails().typeSiteDetailsTitle(siteData.getTitle()).typeSiteDetailsSiteURL(siteData.getUrl()).selectSiteDetailTags(siteData.getChooseTag()).clickContinue()
							.typeMaximumPages(siteData.getMaxPages()).selectScanIntensity(siteData.getChooseIntensity()).typeInHeaderInjection(siteData.headers).clickContinue()
							.typeURLInWhiteList(siteData.getUrlWL()).typeRegularExpressionInWhiteList(siteData.getRegExpWL()).typeURLInBlackList(siteData.getUrlBL())
							.typeRegularExpressionInBlackList(siteData.getRegExpBL()).clickContinue();
				}

				ReviewAndConfimStepAddSite reviewAndConfimStep = new ReviewAndConfimStepAddSite(AddSiteDialogMode.CREATE);
				if (siteData.getAddSiteOrScan().equalsIgnoreCase("addSite") || siteData.getAddSiteOrScan().equalsIgnoreCase("add Site") || siteData.getAddSiteOrScan().equalsIgnoreCase("finish")) {
					reviewAndConfimStep.clickFinish(LandingPageAfterAddSite.ASSETS_SITES_TAB);
					handleAfterFinish();
				} else if (siteData.getAddSiteOrScan().equalsIgnoreCase("scan & Scan") || siteData.getAddSiteOrScan().equalsIgnoreCase("scan")) {
					reviewAndConfimStep.clickSaveAndScanNow(LandingPageAfterAddSite.ASSETS_SITES_TAB);
					handleAfterFinish();

				} else {
					log.error("AddSiteOrScan value from csv file /mds/addSiteNoSchedule.csv is invalid");
				}
			} else {
				log.error("As site creation error exists,Not executing the workFlow of textcase " + siteData.getNote());
				log.error("Check above error logs");
				MalwarePage.clickOkOfSiteCreationError();
				log.warn("Exiting from testcase and not executing rest of cases from CSV file");
				killBrowser();
				Assert.fail("Failing testcase");

			}

		} else {

			log.error("User do not have permission to create site");
		}
	}
}
