package com.qualys.selenium.mds.scans.tests.detections;

import lombok.extern.slf4j.Slf4j;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.scans.DetectionsTab;
import com.qualys.selenium.mds.pageobject.scans.ScanListTab;
import com.qualys.selenium.mds.pageobject.scans.ScansPage;

@Slf4j
public class DetectionsPageTests extends EnterURLAndLogIn {

	public void handleAfterFinish() {
		try {
			MalwarePage malwarePage = new MalwarePage(MalwareLandingPage.SCANS);
			malwarePage.waitForNotificationDialogToAppear();

			malwarePage.clickOnNotificationDialog();

			malwarePage.waitForNotificationDialogToDisappear();

		} catch (Exception e) {
			log.warn("There is an error.Please check");
		}
	}

	public ScansPage goToScansPage() throws ElementNotFoundException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();
		return welcomePage.goToMDSPageFromModulePanel().goToScans();
	}

	/* @Test
	public void rescanDL() throws ElementNotFoundException {

		goToScansPage().goToDetectionTab().selectAllDetectionsCheckBox().selectActionsRescanPage().goToTargetStep().clickContinue().clickFinish();
		handleAfterFinish();
	}*/

	@Test(priority = 1)
	public void verifyDetectionView() {
		try {
			goToScansPage().goToDetectionTab().selectQuickActionsView("http://www.mwtest.info/malware-demos-named/MS06-013/MS06-013.html").clickClose();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}

	@Test(priority = 2)
	public void verifyDetectionRescan() throws ElementNotFoundException {
		String detectionScanName = "automated page scan " + Utility.getUUID();
		DetectionsTab detectionsTab = new DetectionsTab();
		detectionsTab.goToDetectionTab().selectQuickActionsRescanPage("http://www.mwtest.info/malware-demos-named/MS06-013/MS06-013.html").goToTargetStep().typeTargetScanTitle(detectionScanName)
				.clickContinue().clickFinish();
		handleAfterFinish();
		ScanListTab scanListTab = new ScanListTab();
		try {
			
			String scanStatus = scanListTab.refreshScanListPage()
					.getStatusTextOfScan(detectionScanName);
			
			if (scanStatus.equalsIgnoreCase("Running") || scanStatus.equalsIgnoreCase("Submitted") || scanStatus.equalsIgnoreCase("Finished") ) {
				log.info("Launched scan of detection ");
			} else {
				log.error("Did not launch detection scan");
				Assert.fail("Test case failed as scan is not launched");
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}

	}
}
