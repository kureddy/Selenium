package com.qualys.selenium.mds.scans.text;

import com.qualys.selenium.core.EnterURLAndLogIn;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.dialogs.schedule.ScheduleDialogue;
import com.qualys.selenium.mds.pageobject.dialogs.schedule.TaskDetails;

public class ScheduleStaticObjectsTest extends EnterURLAndLogIn {

	//@Test
	public void testPageObjectsOfAddSite() throws ElementNotFoundException {
		WelcomeHomePage welcomePage = new WelcomeHomePage();

		// From welcome page go to MDS page
		MalwarePage malwarePage = welcomePage.goToMDSPageFromModulePanel();

		malwarePage.goToScans().goToSchedulesTab().clickNewSchedule();
		ScheduleDialogue scheduleDialogue = new ScheduleDialogue("create");
		scheduleDialogue.verifySideBarStepsStaticText();
		
		TaskDetails taskDetails = new TaskDetails("create");
		
		taskDetails.typeScheduleName("NEW SCHEDULE").verifyTaskDetailsStepStaticText();

	}
}
