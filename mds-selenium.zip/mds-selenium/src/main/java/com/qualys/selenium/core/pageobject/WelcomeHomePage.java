package com.qualys.selenium.core.pageobject;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.permissions.PermissionChecks;
import com.qualys.selenium.mds.permissions.PermissionServices;
import com.qualys.selenium.questionnaire.pageobject.QuestionnairePage;
import com.qualys.selenium.questionnaire.pageobject.QuestionnairePage.QuestionnaireLandingPage;

@Slf4j
public class WelcomeHomePage extends AbstractFrame {

	public enum PageElements implements IPageElement {
		// PAGE_VERIFY_ELEMENT("#FrameModuleCardPanel .modules-list"),
		PAGE_VERIFY_ELEMENT("#FrameModuleCardPanel"),
		QWEB_VM_MODULE(".module.QWEB_VM"),
		ASSET_MANAGEMENT_MODULE(".module.ASSET_MANAGEMENT"),
		QWEB_PCI_MODULE(".module.QWEB_PCI"),
		WAS_MODULE(".module.WAS"),
		WAF_MODULE(".module.WAF"),
		ADMIN_MODULE(".module.ADMIN"),
		// MDS_MODULE(".module.MALWARE_SCANNING");
		MDS_MODULE(".module.MDS"),
		QUESTIONNAIRE_MODULE(".module.QUESTIONNAIRE");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}

	public WelcomeHomePage() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.PAGE_VERIFY_ELEMENT);

		log.info(Utility.getCurrentUrl());

		PermissionChecks.getPermissions();
		log.info("User : " + PermissionChecks.getUserName() + " has permissions: " + PermissionChecks.getPermissions());

		if (PermissionChecks.isSuperUser() && !Utility.getCurrentUrl().contains("/home")) {

			throw new IllegalStateException("This is not the landing page of super user. Laneded url :" + Utility.getCurrentUrl());
		} else if (!PermissionChecks.isSuperUser() && !Utility.getCurrentUrl().contains("module/mds/")) {
			throw new IllegalStateException("This is not the landing page of sub user");
		}
	}

	public MalwarePage goToMDSPageFromModulePanel() throws ElementNotFoundException {

		if (!PermissionChecks.isSuperUser() && PermissionChecks.containsOnlyProduct(PermissionServices.PRODUCT_MALWARE_ENTERPRISE.getName())) {
			log.info("User : " + PermissionChecks.getUserName() + "Contains only 1 product ");
			return new MalwarePage(MalwareLandingPage.DASHBOARD);
		} else {
			Utility.click(PageElements.MDS_MODULE);
			return new MalwarePage(MalwareLandingPage.DASHBOARD);
		}
	}

	public QuestionnairePage goToQuestionnairePageFromModulePanel() throws ElementNotFoundException {
		if (!PermissionChecks.isSuperUser() && PermissionChecks.containsOnlyProduct(PermissionServices.PRODUCT_QUESTIONNAIRE_BETA.getName())) {
			log.info("User : " + PermissionChecks.getUserName() + "Contains only 1 product ");
			return new QuestionnairePage(QuestionnaireLandingPage.DASHBOARD);
		} else {
			Utility.click(PageElements.QUESTIONNAIRE_MODULE);
			return new QuestionnairePage(QuestionnaireLandingPage.DASHBOARD);
		}
	}

}
