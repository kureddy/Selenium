package com.qualys.selenium.customexceptions;

public class MyException {

	public static void main(String[] args) {
		try {

			userword("abce");
			userword("ppp");
			
		} catch (SiteCreationMaxedOutException e) {

		}
	}
	
	static void userword(String mword) throws SiteCreationMaxedOutException
	{
		if(mword.equals("abce"))
		{
			throw new SiteCreationMaxedOutException(mword);
		}else
		{
			System.out.println("correct");
		}
	}


}
