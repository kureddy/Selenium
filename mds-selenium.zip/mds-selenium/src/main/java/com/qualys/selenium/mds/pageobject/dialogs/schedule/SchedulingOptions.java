package com.qualys.selenium.mds.pageobject.dialogs.schedule;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;

@Slf4j
public class SchedulingOptions extends ScheduleDialogue{
    
    
    public enum PageElements implements IPageElement {

       STEP_VERIFY_LEFT_PANEL_BEFORE_FILLING(".schedule-object-window .step-scheduling:not(.middle-inactive)"),
       STEP_VERIFY_LEFT_PANEL_AFTER_FILLING(".schedule-object-window .step-scheduling:not(.middle-inactive).middle-passed"),
       
       
       RECURRANCE_MODE_DOWN_ARROW_TRIGGER(".schedule-object-window .section-panel-body div.x-form-label-top div.x-form-field-trigger-wrap>input.x-trigger-noedit+img"),
       
       
       
       RECURRANCE_MODE_CONTAINTER_SINGLE_OCCURANCE("//div[contains(@class,'x-combo-list')]//div[text()='Single occurrence']",IdentifiedBy.XPATH),
       
       //DAILY
       RECURRANCE_MODE_CONTAINTER_DAILY("//div[contains(@class,'x-combo-list')]//div[text()='Daily']",IdentifiedBy.XPATH),
       DAILY_WAIT("daily",IdentifiedBy.ID),
       DAILY_TOTAL_DAYS(".schedule-object-window div.section-panel+div>div+div>div>div+div.x-panel:not(.x-hide-display)"),
 
       
       //WEEKLY
       RECURRANCE_MODE_CONTAINTER_WEEKLY("//div[contains(@class,'x-combo-list')]//div[text()='Weekly']"),
       WEEKLY_WAIT("weekly",IdentifiedBy.ID),
       
       
       //MONTHLY
       RECURRANCE_MODE_CONTAINTER_MONTHLY("//div[contains(@class,'x-combo-list')]//div[text()='Monthly']",IdentifiedBy.XPATH),
       MONTHLY_WAIT("monthly",IdentifiedBy.ID),
       
       //GENERAL
       ENDS_AFTER_CHECKBOX(".schedule-object-window .section-panel-body input[name=occurrenceEndCb]"),
       OCCURENCES_DISABLED(".schedule-object-window .section-panel-body input[name=occurrenceCnt]:disabled"),
       OCCURENCES_ENABLED(".schedule-object-window .section-panel-body input[name=occurrenceCnt]:not([disabled])"),
       
       
       
       START_DATE_DOWN_ARROW_TRIGGER(".schedule-object-window .section-panel-body input[name=start-date]"),
       START_DATE_DOWN_CONTAINER_DATE_PICKER("x-datepicker-cb-menu"),
       DATE_PICKER_TOADAY_DATE(".x-date-menu .x-date-picker table .x-date-bottom button"),
    
       TIME_DOWN_ARROW_TRIGGER(".schedule-object-window .section-panel-body input[name=start-time]"),
       TIME_DOWN_CONTAINER("div[class=x-combo-list-inner]"),
       TIME_DOWN_CONTAINER_ITEMS("div[class=x-combo-list-inner] .x-combo-list-item"),
       
       TIME_ZONE_DOWN_ARROW_TRIGGER(".schedule-object-window .q-scroller:not(.x-hide-display) .refreshable-combobox img:last-of-type"),
       TIMEZONE_REFRESH_BUTN(".refreshable-combobox img:first-of-type"),
       TIME_ZONE_DOWN_CONTAINER(".results-hint"),
       TIME_ZONE_DOWN_CONTAINER_ITEMS(".combobox-item");
       
       
       

        String key;
        IdentifiedBy identifiedBy;

        PageElements(String key, IdentifiedBy identifiedBy) {
            this.key = key;
            this.identifiedBy = identifiedBy;
        }

        PageElements(String key) {
            this(key, IdentifiedBy.CSS);
        }

        @Override
        public String getLocator() {
            return this.key;
        }

        @Override
        public IdentifiedBy getIdentifiedBy() {
            return this.identifiedBy;
        }

    }
    public SchedulingOptions(String mode){
        super(mode);
        if (!Utility.isElementPresent(PageElements.STEP_VERIFY_LEFT_PANEL_BEFORE_FILLING)) {
            log.info("Currently at url : {}", Utility.getCurrentUrl());
            throw new IllegalStateException(
                    "This is not the AddSite>Site Details List page");
        }
    }
    
    public SchedulingOptions(String mode,String Previous) {
        super(mode);
        if (!Utility.isElementPresent(PageElements.STEP_VERIFY_LEFT_PANEL_AFTER_FILLING)) {
            log.info("Currently at url : {}", Utility.getCurrentUrl());
            throw new IllegalStateException(
                    "This is not the AddSite>Crawl Exclusion List page");
        }
    }

  

    public SchedulingOptions selectRecurrenceMode(String recurrenceMode) throws ElementNotFoundException {

        Utility.click(PageElements.RECURRANCE_MODE_DOWN_ARROW_TRIGGER);
        Utility.waitForElementPresent(PageElements.RECURRANCE_MODE_CONTAINTER_SINGLE_OCCURANCE);

        if (recurrenceMode.equalsIgnoreCase("Single occurence")) {
            Utility.click(PageElements.RECURRANCE_MODE_CONTAINTER_SINGLE_OCCURANCE);

        } else if (recurrenceMode.equalsIgnoreCase("Daily")) {

            Utility.click(PageElements.RECURRANCE_MODE_CONTAINTER_DAILY);

            Utility.waitForElementPresent(PageElements.DAILY_WAIT);

        } else if (recurrenceMode.equalsIgnoreCase("weekly")) {
            Utility.click(PageElements.RECURRANCE_MODE_CONTAINTER_WEEKLY);
            Utility.waitForElementPresent(PageElements.WEEKLY_WAIT);
            
            
        } else if (recurrenceMode.equalsIgnoreCase("Monthly")) {

            Utility.click(PageElements.MONTHLY_WAIT);

            Utility.waitForElementPresent(PageElements.WEEKLY_WAIT);
        }

        return this;
    }

    public SchedulingOptions enableRecurrenceEndsAfter() {
        Utility.click(PageElements.ENDS_AFTER_CHECKBOX);
        return this;
    }

    public SchedulingOptions selectLaunchInfoStartDate() {

        Utility.moveToElementAndClick(PageElements.START_DATE_DOWN_ARROW_TRIGGER);
        return this;
    }

    public SchedulingOptions selectLaunchInfoTime() {
        return this;
    }

    public SchedulingOptions selectLaunchInfoTimeZone() {
        return this;
    }

   /* public ReviewAndConfimStep clickFinish() {

        Utility.click(AddSiteDialog.PAGE_CONSTANTS_STARTS_WITH
                + "Continue_Button_Navigation_XPATH", IdentifiedBy.XPATH);
        return new ReviewAndConfimStep();
    }*/

    public ReviewAndConfirm clickContinue()
    {
        Utility.click(DialogCommonElements.CONTINUE_BTN);
        return new ReviewAndConfirm();
    }
    public void clickCancel() {
        Utility.click(DialogCommonElements.CANCEL_BTN);
      
    }

    public TaskDetails clickPrevious() {
        Utility.click(DialogCommonElements.PREVIOUS_BTN);
        return new TaskDetails("create","Previous");
    }
    
   /* public  SiteDetailsStep verifyTaskDetailsStepStaticText()
    {
        CustomVerification customVerification = new CustomVerification();
        
        customVerification.verifyEquals("Task details step SCAN_DETAILS_HEADER_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_DETAILS_HEADER_LABEL), "Scan details");
        customVerification.verifyEquals("Task details step SCHEDULE_NAME_LABEL", Utility.getTextOfPageObject(PageElements.SCHEDULE_NAME_LABEL), "Schedule Name");
        customVerification.verifyEquals("Task details step SCHEDULE_BY_LABEL", Utility.getTextOfPageObject(PageElements.SCHEDULE_BY_LABEL), "Schedule by");
        customVerification.verifyEquals("Task details step SITE_TITLE_LABEL", Utility.getTextOfPageObject(PageElements.SITE_TITLE_LABEL), "Site Title*");
        customVerification.verifyEquals("Task details step SCAN_PREFERENCES_HEADER_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_PREFERENCES_HEADER_LABEL), "Scan Preferences");
        customVerification.verifyEquals("Task details step MAX_PAGES_LABEL", Utility.getTextOfPageObject(PageElements.MAX_PAGES_LABEL), "Maximum Pages*");
        customVerification.verifyEquals("Task details step SCAN_INTENSITY_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_INTENSITY_LABEL), "Scan Intensity*");
        
        customVerification.verifyEquals("Task details step continue button ",Utility.getTextOfPageObject(DialogCommonElements.CONTINUE_BTN),"Continue");
        customVerification.verifyEquals("Task details step cancel button ",Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN),"Cancel");
  
		return null;
    }*/
}


