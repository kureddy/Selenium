package com.qualys.selenium.mds.pageobject.dialogs.addsite;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;

@Slf4j
public class SiteDetailsStep extends AddSiteDialog {

	// public static final String siteDetailsPassedWebEle =
	// SiteDetails.PAGE_CONSTANTS_STARTS_WITH+ "LeftPanel_Passed_Verify";

	public enum PageElements implements IPageElement {

		STEP_VERIFY_ACTIVE_BODY(".step-basic:not(.middle-inactive):not(.first-passed)"),
		STEP_VERIFY_PASSED_BODY(".step-basic:not(.middle-inactive).first-passed"),

		WINDOW_CLOSE_BUTTON(".malware-site-object-window .q-window-header div[title=Close]"),

		SITE_DETAILS_STEP_HEADER_DESCRIPTION_LABEL(".malware-site-object-window .q-step-header .object-panel div"),

		SOURCE_FILE_HEADER_LABEL(".malware-site-object-window .section-edit-panel:nth-of-type(2) .section-panel-header-text"),
		SOURCE_FILE_CHECKBOX(".malware-site-object-window .enable-uploading input[type=checkbox]"),
		SOURCE_FILE_CHECKBOX_LABEL(".malware-site-object-window .enable-uploading label"),
		REQUIRED_FIELDS_NOTICE_LABEL(".malware-site-object-window .q-scroller:nth-of-type(1) .notice-required div"),
		SITE_DETAILS_HEADER_LABEL(".malware-site-object-window .section-edit-panel:nth-of-type(3) .section-panel-header-text"),
		SITE_DETAILS_DESCRIPTION_LABEL(".malware-site-object-window .section-panel  .notice"),
		SITE_DETAILS_TITLE_LABEL(".malware-site-object-window .section-edit-panel:nth-of-type(3) .x-form-item:nth-of-type(1) label"),
		SITE_DETAILS_SITE_URL_LABEL(".malware-site-object-window .section-edit-panel:nth-of-type(3) .x-form-item:nth-of-type(2) label"),
		TAGS_HEADER_LABEL(".malware-site-object-window #tag-combo-id-object-window .section-panel-header-text"),
		TAGS_DESCRIPTION_LABEL(".malware-site-object-window #tag-combo-id-object-window .notice"),
		TAGS_NO_TAGS_SELECTED_LABEL(".malware-site-object-window #tag-combo-id-object-window .selected-tags-view span"),

		TURN_HELP_TIPS_ON_OFF_LABEL(".malware-site-object-window .q-window-header div.help-on"), // TODO
																									// :
																									// no
																									// such
																									// element
																									// exception
		LAUNCH_HELP_LABEL(".malware-site-object-window .q-window-header div.launch-help"),

		HELP_TIPS_ON(".malware-site-object-window .q-window-header div.help-on .help-toggle-on"),
		HELP_TIPS_OFF(".malware-site-object-window .q-window-header div.help-on .help-toggle-off"),

		SITE_DETAILS_TITLE_TEXTFIELD(
				".malware-site-object-window div[class*=-object-window-content] div:not(.x-hide-display):nth-of-type(1)[class=q-scroller] .section-edit-panel:nth-of-type(3) input[name=title]"),
		SITE_DETAILS_TITLE_ERROR_MESSAGE_NOT_PRESENT(".malware-site-object-window input[name=title]:not(.x-form-invalid)"),

		SITE_URL_TEXT_FILED(
				".malware-site-object-window div[class*=-object-window-content] div:not(.x-hide-display):nth-of-type(1)[class=q-scroller] .section-edit-panel:nth-of-type(3) input[name=url]"),
		SITE_URL_ERROR_MESSAGE_NOT_PRESENT(".malware-site-object-window input[name=url]:not(.x-form-invalid)"),

		TAGS_COMBO_DOWN_ARROW_TRIGGER(".malware-site-object-window div:not(x-hide-display) .x-form-twin-triggers img:nth-child(2)"),
		TAGS_COMBO_DOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
		TAGS_COMBO_DOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	// public AddSiteDialogMode addSiteDialogMode;

	public SiteDetailsStep(AddSiteDialogMode mode) throws SiteCreationMaxedOutException, ElementNotFoundException {

		super(mode);
		if (!Utility.isElementPresent(PageElements.STEP_VERIFY_ACTIVE_BODY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the AddSite > Site Details List page");
		}

	}

	public SiteDetailsStep typeSiteDetailsTitle(String siteTitle) {
		if (!siteTitle.equalsIgnoreCase("none")) {
			try {

				Utility.waitForElementPresent(PageElements.SITE_DETAILS_TITLE_TEXTFIELD);
				Utility.typeInEditBox(PageElements.SITE_DETAILS_TITLE_TEXTFIELD, siteTitle);
				if (!Utility.getTextOfPageObject(PageElements.SITE_DETAILS_TITLE_TEXTFIELD).equals(siteTitle)) {
					Utility.typeInEditBox(PageElements.SITE_DETAILS_TITLE_TEXTFIELD, siteTitle);
				}
				log.info("Typed Site title in SiteDetailsStep " + siteTitle);

			} catch (Exception e) {
				log.error("Error at SiteDetailsStep > typeSiteDetailsTitle");
				e.printStackTrace();
			}
			return this;
		} else {
			log.info("SiteTile = " + siteTitle + "So not typing in that text field");
			return this;
		}
	}

	public SiteDetailsStep typeSiteDetailsSiteURL(String siteURL) {
		if (!siteURL.equalsIgnoreCase("none")) {
			Utility.typeInEditBox(PageElements.SITE_URL_TEXT_FILED, siteURL);
			return this;
		} else {
			log.info("siteURL = " + siteURL + "So not typing in that text field");
			return this;
		}
	}

	public SiteDetailsStep selectSiteDetailTags(String selectTag) throws InterruptedException {
		if (!selectTag.equalsIgnoreCase("none")) {
			try {
				Utility.waitForElementPresent(PageElements.SITE_URL_ERROR_MESSAGE_NOT_PRESENT);
				log.info("Waiting for Element SITE_URL_ERROR_MESSAGE_NOT_PRESENT");
			} catch (Exception e) {
				log.error("Error while waiting for SITE_URL_ERROR_MESSAGE_NOT_PRESENT");
				e.printStackTrace();
			}

			try {
				Utility.click(PageElements.TAGS_COMBO_DOWN_ARROW_TRIGGER);
				log.info("Clicking on  Element TAGS_COMBO_DOWN_ARROW_TRIGGER");
			} catch (Exception e) {
				log.error("Error while Clicking on TAGS_COMBO_DOWN_ARROW_TRIGGER");
				e.printStackTrace();
			}

			try {
				Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_CONTAINER);
				log.info("Waiting for Element Element TAGS_COMBO_DOWN_CONTAINER");

			} catch (Exception e) {
				log.error("Error while waiting for TAGS_COMBO_DOWN_CONTAINER");
				e.printStackTrace();
			}

			WebElement superElement = Utility.getElement(PageElements.TAGS_COMBO_DOWN_CONTAINER);
			Thread.sleep(50);
			;
			if (!superElement.getText().equals("")) {
				try {
					Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS);
					log.info("Waiting for Element Element TAGS_COMBO_DOWN_CONTAINER_ITEMS");

				} catch (Exception e) {
					log.error("Error while waiting for TAGS_COMBO_DOWN_CONTAINER_ITEMS");
					e.printStackTrace();
				}
				if (selectTag.contains(",")) {

					String[] splitEachTag = selectTag.split(",");
					for (String eachTag : splitEachTag) {
						System.out.println(eachTag);
						try {
							Utility.selectMultipleValuesDoubleClick(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS, superElement, eachTag);
							log.info("Selecting and double clicking on  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + eachTag);
						} catch (Exception e) {
							log.error("Error while selecting  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + eachTag);
							e.printStackTrace();
						}
					}
				} else {
					try {
						Utility.selectMultipleValuesDoubleClick(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS, superElement, selectTag);
						log.info("Selecting and double clicking on  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + selectTag);
					} catch (Exception e) {
						log.error("Error while selecting  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + selectTag);
						e.printStackTrace();
					}

				}

				return this;
			} else {
				log.warn("User do not have any tags to select");
				return this;
			}
		} else {
			log.info("selectTag = " + selectTag + " so not selecting any tags");
			return this;
		}
	}

	public SiteDetailsStep oNHelpTips() {
		Utility.click(PageElements.HELP_TIPS_ON);
		return this;
	}

	public SiteDetailsStep oFFHelpTips() {
		Utility.click(PageElements.HELP_TIPS_OFF);
		return this;
	}

	public SiteDetailsStep launchHelp() {
		Utility.click(PageElements.LAUNCH_HELP_LABEL);
		return this;
	}

	public ScanSettingsStep clickContinue() throws SiteCreationMaxedOutException, ElementNotFoundException {

		try {
			Utility.click(DialogCommonElements.CONTINUE_BTN);
			log.info("Clicking on ScanSettingsStep > CONTINUE_BTN");
		} catch (Exception e) {
			log.error("Error while clicking on ScanSettingsStep > CONTINUE_BTN");
			e.printStackTrace();
		}

		return new ScanSettingsStep(siteDialogueMode);
	}

	public DashboardPage clickCancel() throws ElementNotFoundException {

		Utility.click(DialogCommonElements.CANCEL_BTN);

		return new DashboardPage();
	}

	public SiteDetailsStep verifySiteDetailsStepStaticText() {
		CustomVerification customVerification = new CustomVerification();

		// customVerification.verifyEquals("Site Details step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help ");
		// //TODO : no such element exception

		customVerification.verifyEquals("Site Details step LAUNCH_HELP_LABEL", Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL), "Launch help...");

		customVerification.verifyEquals("Site Details step SITE_DETAILS_STEP_HEADER_DESCRIPTION_LABEL", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_STEP_HEADER_DESCRIPTION_LABEL),
				"Add site details manually or by uploading a CSV file.");

		customVerification.verifyEquals("Site Details step source file header ", Utility.getTextOfPageObject(PageElements.SOURCE_FILE_HEADER_LABEL), "Source file (CSV Format)");

		customVerification.verifyEquals("Site Details step 'I have a CSV file to upload' SOURCE_FILE_CHECKBOX_LABEL ", Utility.getTextOfPageObject(PageElements.SOURCE_FILE_CHECKBOX_LABEL),
				"I have a CSV file to upload");

		customVerification.verifyEquals("Site Details step REQUIRED_FIELDS_NOTICE_LABEL", Utility.getTextOfPageObject(PageElements.REQUIRED_FIELDS_NOTICE_LABEL), "(*) REQUIRED FIELDS");

		customVerification.verifyEquals("Site Details step SITE_DETAILS_HEADER_LABEL", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_HEADER_LABEL), "Site Details");

		customVerification.verifyEquals("Site Details step SITE_DETAILS_DESCRIPTION_LABEL ", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_DESCRIPTION_LABEL),
				"Please enter information about the site you would like to scan for malware.");

		customVerification.verifyEquals("Site Details step SITE_DETAILS_TITLE_LABEL", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_TITLE_LABEL), "Title*");

		customVerification.verifyEquals("Site Details step SITE_DETAILS_DESCRIPTION_LABEL", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_DESCRIPTION_LABEL),
				"Please enter information about the site you would like to scan for malware.");

		customVerification.verifyEquals("Site Details step TAGS_HEADER_LABEL", Utility.getTextOfPageObject(PageElements.TAGS_HEADER_LABEL), "Tags");

		customVerification.verifyEquals("Site Details step TAGS_DESCRIPTION_LABEL ", Utility.getTextOfPageObject(PageElements.TAGS_DESCRIPTION_LABEL),
				"Double-click a tag in the list to assign it to the site. Assigned tags appear below. (Note that you can add tags to the site at a later time.)");

		customVerification.verifyEquals("Site Details step no TAGS_NO_TAGS_SELECTED_LABEL ", Utility.getTextOfPageObject(PageElements.TAGS_NO_TAGS_SELECTED_LABEL), "(No tags selected)");

		customVerification.verifyEquals("Site Details step CONTINUE_BTN ", Utility.getTextOfPageObject(DialogCommonElements.CONTINUE_BTN), "Continue");

		customVerification.verifyEquals("Site Details step cancel button  ", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN), "Cancel");

		return this;
	}
}
