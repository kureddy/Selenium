package com.qualys.selenium.mds.pageobject.scans;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;

@Slf4j
public class ScansPage extends MalwarePage {

	public enum PageElements implements IPageElement {

		SCANS_PAGE_VERIFY("#scans:not(.x-hide-display).tab-container"),
		SITES_LIST_TAB("#scans:not(.x-hide-display) div[ref=scan-history]"),
		DETECTIONS_TAB("#scans:not(.x-hide-display) div[ref=infected-pages]"),
		SCHEDULES_TAB("#scans:not(.x-hide-display) div[ref=datalist-schedules]");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public ScansPage() throws ElementNotFoundException{
		super(MalwareLandingPage.SCANS);
		if (!Utility.isElementPresent(PageElements.SCANS_PAGE_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the MDS>Scans page");
		}
	}

	// go to each tab on Scans module in MDS(Scan List,Detections,Schedules)

	// go to Scans>scan List tab
	public ScanListTab goToScanListTab() throws ElementNotFoundException{
		Utility.waitForElementPresent(PageElements.SITES_LIST_TAB);
		Utility.click(PageElements.SITES_LIST_TAB);
		
		// Utility.waitForElementPresent(ScanListTab.PAGE_CONSTANTS_STARTS_WITH
		// + "Verify",IdentifiedBy.CSS);

		return new ScanListTab();
	}

	// go to Scans>Detections List tab
	public DetectionsTab goToDetectionTab() throws ElementNotFoundException{
		Utility.waitForElementPresent(PageElements.DETECTIONS_TAB);
		Utility.click(PageElements.DETECTIONS_TAB);
		
		return new DetectionsTab();
	}

	// go to Scans>Schedules List tab
	public SchedulesTab goToSchedulesTab() throws ElementNotFoundException {
		Utility.click(PageElements.SCHEDULES_TAB);
		Utility.waitForElementPresent(PageElements.SCHEDULES_TAB);

		return new SchedulesTab();
	}

}
