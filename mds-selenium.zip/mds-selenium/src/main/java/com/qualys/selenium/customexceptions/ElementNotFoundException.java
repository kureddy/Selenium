package com.qualys.selenium.customexceptions;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SuppressWarnings("serial")
public class ElementNotFoundException extends Exception {

	String elementNotFound;

	public ElementNotFoundException(String message) {
		elementNotFound = message;
	}

	public String myMessage(String message) {
		return "Element is not found " + message +"\nSelector is : " + elementNotFound;
	}

	public String getExceptionMessage() {
		return elementNotFound;

	}

	public void logException(String messageToPrint) {
		String message = messageToPrint;
		log.error(myMessage(message));
	}

}
