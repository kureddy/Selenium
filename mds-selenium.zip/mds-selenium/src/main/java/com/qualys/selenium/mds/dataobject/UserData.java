package com.qualys.selenium.mds.dataobject;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class UserData {
	private  String userId;
	private  List<String> products;
	private String userName;
	private String qGAccountID;
	private String firstName;
	private String lastName;
	private String customerId;
	private String password;
	private String description;
	private int isSuperUser;
	private int canAccessAllAssets;
	private ArrayList<String> permissions;

	public UserData(String userName) {
		this.userName = userName;
	}

}
