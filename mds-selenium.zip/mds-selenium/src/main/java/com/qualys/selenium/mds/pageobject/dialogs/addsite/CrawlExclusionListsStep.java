package com.qualys.selenium.mds.pageobject.dialogs.addsite;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.permissions.PermissionChecks;
import com.qualys.selenium.mds.permissions.PermissionServices;

@Slf4j
public class CrawlExclusionListsStep extends AddSiteDialog {

	public enum PageElements implements IPageElement {

		STEP_VERIFY_ACTIVE_BODY(".step-url:not(.middle-inactive)"),
		STEP_VERIFY_PASSED_BODY(".step-url:not(.middle-inactive).middle-passed"),

		CRAWL_EXCLUSION_LIST_STEP_HEADER_DESCRIPTION_LABEL(".malware-site-object-window .q-step-header .object-panel div"),
		WHITE_LIST_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(2) .section-panel-header-text"),
		REQUIRED_FIELDS_NOTICE_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .notice-required"),
		WHITE_LIST_DESCRIPTION_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(2) .notice"),
		WHITE_LIST_URL_CHECKBOX_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(2) .section-panel-body .x-form-item :nth-of-type(1) label"),
		WHITE_LIST_REGULAR_EXPRESSION_CHECKBOX_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(2) .section-panel-body .x-form-item:nth-of-type(4) .x-form-element label"),
		BLACK_LIST_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(3) .section-panel-header-text"),
		BLACK_LIST_DESCRIPTION_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(3) .notice"),
		BLACK_LIST_URL_CHECKBOX_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(3) .section-panel-body .x-form-item :nth-of-type(1) label"),
		BLACK_LIST_REGULAR_EXPRESSION_CHECKBOX_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(3) .section-panel:nth-of-type(3) .section-panel-body .x-form-item:nth-of-type(4) .x-form-element label"),

		// help tips
		TURN_HELP_TIPS_ON_OFF_LABEL(".malware-site-object-window .q-window-header div.help-on"), // TODO
																									// :
																									// no
																									// such
																									// element
																									// exception
		LAUNCH_HELP_LABEL(".malware-site-object-window .q-window-header div.launch-help"),

		HELP_TIPS_ON(".malware-site-object-window .q-window-header div.help-on .help-toggle-on"),
		HELP_TIPS_OFF(".malware-site-object-window .q-window-header div.help-on .help-toggle-off"),

		WHITE_LIST_URL_CHECKBOX(".malware-site-object-window input[name=wl-url-enable]"),
		WHITE_LIST_URL_TEXTFIELD(".malware-site-object-window div[class*=-object-window-content] div:not(.x-hide-display):nth-of-type(3)[class=q-scroller] textarea[name=wl-url]:not(.x-hide-display)"),
		WHITE_LIST_REGULAREXPRESSION_CHECKBOX(".malware-site-object-window input[name=wl-regex-enable]"),
		WHITE_LIST_REGULAREXPRESSION_TEXTFIELD(
				".malware-site-object-window div[class*=-object-window-content] div:not(.x-hide-display):nth-of-type(3)[class=q-scroller] textarea[name=wl-regex]:not(.x-item-disabled)"),

		BLACK_LIST_URL_CHECKBOX(".malware-site-object-window input[name=bl-url-enable]"),
		BLACK_LIST_URL_TEXTFIELD(".malware-site-object-window  textarea[name=bl-url]:not(.x-hide-display)"),
		BLACK_LIST_REGULAREXPRESSION_CHECKBOX(".malware-site-object-window input[name=bl-regex-enable]"),
		BLACK_LIST_REGULAREXPRESSION_TEXTFIELD(".malware-site-object-window  textarea[name=bl-regex]:not(.x-hide-display)");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public CrawlExclusionListsStep(AddSiteDialogMode mode) throws SiteCreationMaxedOutException, ElementNotFoundException {
		super(mode);
		if (Utility.waitForElementPresent(PageElements.STEP_VERIFY_ACTIVE_BODY) == null) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Add site>Crawl Exclusion Lists page");
		}
	}


	public CrawlExclusionListsStep enableWhiteListURLCheckbox() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.WHITE_LIST_URL_CHECKBOX);
		Utility.selectCheckBox(PageElements.WHITE_LIST_URL_CHECKBOX);

		/*
		 * Utility.selectCheckBox(PAGE_CONSTANTS_STARTS_WITH +
		 * "WhiteList_URL_CheckBox_Navigation", IdentifiedBy.CSS);
		 */
		return this;
	}

	public CrawlExclusionListsStep enableWhiteListRegularExpresstionCheckBox() {

		Utility.selectCheckBox(PageElements.WHITE_LIST_REGULAREXPRESSION_CHECKBOX);

		/*
		 * Utility.selectCheckBox(PAGE_CONSTANTS_STARTS_WITH +
		 * "WhiteList_RegExpression_CheckBox_Navigation", IdentifiedBy.CSS);
		 */

		return this;
	}

	public CrawlExclusionListsStep enableBlackListURLCheckBox() {

		Utility.selectCheckBox(PageElements.BLACK_LIST_URL_CHECKBOX);

		return this;
	}

	public CrawlExclusionListsStep enableBlackListRegularExpressionChceckBox() {
		Utility.selectCheckBox(PageElements.BLACK_LIST_REGULAREXPRESSION_CHECKBOX);
		return this;
	}

	public CrawlExclusionListsStep typeURLInWhiteList(String urlForWhiteList) throws ElementNotFoundException {
		if (!urlForWhiteList.equalsIgnoreCase("none")) {
			log.info("enabling white list URL checkbox");
			enableWhiteListURLCheckbox();
			Utility.waitForElementPresent(PageElements.WHITE_LIST_URL_TEXTFIELD);
			Utility.typeInEditBox(PageElements.WHITE_LIST_URL_TEXTFIELD, urlForWhiteList);
			log.info("typing in white list url text field");
			if (!Utility.getTextOfPageObject(PageElements.WHITE_LIST_URL_TEXTFIELD).equals(urlForWhiteList)) {
				Utility.typeInEditBox(PageElements.WHITE_LIST_URL_TEXTFIELD, urlForWhiteList);
			}
			return this;
		} else {
			log.trace("urlForWhiteList =" + urlForWhiteList + "so not typing in white list URL field");
			return this;
		}
	}

	public CrawlExclusionListsStep typeRegularExpressionInWhiteList(String regExForWhiteList) throws ElementNotFoundException {
		if (!regExForWhiteList.equalsIgnoreCase("none")) {
			log.info("enabling white list reg expression checkbox");
			enableWhiteListRegularExpresstionCheckBox();

			Utility.waitForElementPresent(PageElements.WHITE_LIST_REGULAREXPRESSION_TEXTFIELD);
			Utility.typeInEditBox(PageElements.WHITE_LIST_REGULAREXPRESSION_TEXTFIELD, regExForWhiteList);
			if (!Utility.getTextOfPageObject(PageElements.WHITE_LIST_REGULAREXPRESSION_TEXTFIELD).equals(regExForWhiteList)) {
				Utility.typeInEditBox(PageElements.WHITE_LIST_REGULAREXPRESSION_TEXTFIELD, regExForWhiteList);
			}
			return this;
		} else {
			log.trace("regExForWhiteList =" + regExForWhiteList + "so not typing in white list Reg Expression field");
			return this;
		}

	}

	public CrawlExclusionListsStep typeURLInBlackList(String urlForBlackList) {
		if (!urlForBlackList.equalsIgnoreCase("none")) {
			log.info("enabling black list url checkbox");
			enableBlackListURLCheckBox();
			Utility.typeInEditBox(PageElements.BLACK_LIST_URL_TEXTFIELD, urlForBlackList);
			if (!Utility.getTextOfPageObject(PageElements.BLACK_LIST_URL_TEXTFIELD).equals(urlForBlackList)) {
				Utility.typeInEditBox(PageElements.BLACK_LIST_URL_TEXTFIELD, urlForBlackList);
			}

			return this;
		} else {
			log.trace("urlForBlackList =" + urlForBlackList + "so not typing in black list URL field");
			return this;
		}

	}

	public CrawlExclusionListsStep typeRegularExpressionInBlackList(String regEXForBlackList) {
		if (!regEXForBlackList.equalsIgnoreCase("none")) {
			log.info("enabling black list reg expression checkbox");
			enableBlackListURLCheckBox();

			Utility.typeInEditBox(PageElements.BLACK_LIST_REGULAREXPRESSION_TEXTFIELD, regEXForBlackList);
			if (!Utility.getTextOfPageObject(PageElements.BLACK_LIST_REGULAREXPRESSION_TEXTFIELD).equals(regEXForBlackList)) {
				Utility.typeInEditBox(PageElements.BLACK_LIST_REGULAREXPRESSION_TEXTFIELD, regEXForBlackList);
			}
			return this;

		} else {
			log.trace("regEXForBlackList =" + regEXForBlackList + "so not typing in white list Reg expression field");
			return this;
		}
	}

	public CrawlExclusionListsStep oNHelpTips() {
		Utility.click(PageElements.HELP_TIPS_ON);
		return this;
	}

	public CrawlExclusionListsStep oFFHelpTips() {
		Utility.click(PageElements.HELP_TIPS_OFF);
		return this;
	}

	public CrawlExclusionListsStep launchHelp() {
		Utility.click(PageElements.LAUNCH_HELP_LABEL);
		return this;
	}

	public AddSiteDialog clickContinue() throws SiteCreationMaxedOutException, ElementNotFoundException {
		if (PermissionChecks.hasPermission(PermissionServices.MALWARE_SCAN_SCHEDULE_CREATE.getName())) {
			Utility.click(DialogCommonElements.CONTINUE_BTN);
			return new SchedulingStep(siteDialogueMode);
		} else {
			Utility.click(DialogCommonElements.CONTINUE_BTN);
			return new ReviewAndConfimStepAddSite(siteDialogueMode);
		}
	}

	public DashboardPage clickCancel() throws ElementNotFoundException {

		Utility.click(DialogCommonElements.CANCEL_BTN);

		return new DashboardPage();
	}

	public ScanSettingsStep clickPrevious() throws SiteCreationMaxedOutException, ElementNotFoundException {
		Utility.click(DialogCommonElements.PREVIOUS_BTN);

		return new ScanSettingsStep(siteDialogueMode, "Previous");
	}

	public CrawlExclusionListsStep verifyCrawlExclusionListStepStaticText() {
		CustomVerification customVerification = new CustomVerification();

		// customVerification.verifyEquals("Site Details step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help ");
		// //TODO : no such element exception
		customVerification.verifyEquals("Site Details step LAUNCH_HELP_", Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL), "Launch help");

		customVerification.verifyEquals("Crawl Exclusion List step header description should be 'Specify URLs that will be added to these lists.'",
				Utility.getTextOfPageObject(PageElements.CRAWL_EXCLUSION_LIST_STEP_HEADER_DESCRIPTION_LABEL), "Specify URLs that will be added to these lists.");

		customVerification.verifyEquals("Crawl Exclusion List step WHITE LIST header should be  'White List'", Utility.getTextOfPageObject(PageElements.WHITE_LIST_HEADER_LABEL), "White List");
		customVerification.verifyEquals("Crawl Exclusion List step required fields notice ", Utility.getTextOfPageObject(PageElements.REQUIRED_FIELDS_NOTICE_LABEL), "(*) REQUIRED FIELDS");
		customVerification
				.verifyEquals(
						"Crawl Exclusion List step WHITE LIST description ",
						Utility.getTextOfPageObject(PageElements.WHITE_LIST_DESCRIPTION_LABEL),
						"Set up a white list to allow links to be scanned even if a black list would normally block it. If a white list is created, but no black list has been created, then a default black list equivalent to \"block all URLs\" is assumed.");
		customVerification.verifyEquals("Crawl Exclusion List step WHITE LIST checkbox 'URL' ", Utility.getTextOfPageObject(PageElements.WHITE_LIST_URL_CHECKBOX_LABEL), "URLs");
		customVerification.verifyEquals("Crawl Exclusion List step WHITE LIST checkbox 'Regular expression' ", Utility.getTextOfPageObject(PageElements.WHITE_LIST_REGULAR_EXPRESSION_CHECKBOX_LABEL),
				"Regular Expressions");

		customVerification.verifyEquals("Crawl Exclusion List step BLACK LIST header should be 'Black List'", Utility.getTextOfPageObject(PageElements.BLACK_LIST_HEADER_LABEL), "Black List");
		System.out
				.println("Set up a black list to prevent those URLs or their sub-directories from being scanned.\nAny link that matches a black list entry will not be scanned unless it also matches a white list entry.");
		customVerification
				.verifyEquals("Crawl Exclusion List step BLACK LIST description /not matching", Utility.getTextOfPageObject(PageElements.BLACK_LIST_DESCRIPTION_LABEL),
						"Set up a black list to prevent those URLs or their sub-directories from being scanned.\nAny link that matches a black list entry will not be scanned unless it also matches a white list entry.");

		customVerification.verifyEquals("Crawl Exclusion List step BLACK LIST checkbox 'URL' ", Utility.getTextOfPageObject(PageElements.BLACK_LIST_URL_CHECKBOX_LABEL), "URLs");
		customVerification.verifyEquals("Crawl Exclusion List step BLACK LIST heckbox 'Regular expression' ", Utility.getTextOfPageObject(PageElements.BLACK_LIST_REGULAR_EXPRESSION_CHECKBOX_LABEL),
				"Regular Expressions");

		customVerification.verifyEquals("Crawl Exclusion List step continue button ", Utility.getTextOfPageObject(DialogCommonElements.CONTINUE_BTN), "Continue");
		customVerification.verifyEquals("Crawl Exclusion List step cancel button ", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN), "Cancel");

		return this;

	}
}
