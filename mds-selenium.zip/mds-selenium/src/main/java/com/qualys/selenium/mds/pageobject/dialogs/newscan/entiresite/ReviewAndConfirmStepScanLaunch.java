package com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractStep;
import com.qualys.selenium.mds.pageobject.scans.ScanListTab;
@Slf4j
public class ReviewAndConfirmStepScanLaunch extends AbstractStep{

	
    public enum PageElements implements IPageElement{
    	PAGE_LOADING_CHECK(".scan-object-window .step-review.last-active"),
    	
    	REVIEW_AND_CONFIRM_STEP_HEADER_LABEL(".scan-object-window .q-step-header .object-panel .q-content-header"),
        DEFINITION_HEADER_LABEL("//div[contains(@class,'scan-object-window')]//div[2][contains(@class,'q-scroller')]//span[contains(text(),'Definition')]",IdentifiedBy.XPATH),
        SCAN_TITLE_LABEL("//div[contains(@class,'scan-object-window')]//div[2][contains(@class,'q-scroller')]//label[contains(text(),'Scan Title')]",IdentifiedBy.XPATH),
        TARGET_INFORMATION_HEADER_LABEL("//div[contains(@class,'scan-object-window')]//div[2][contains(@class,'q-scroller')]//span[contains(text(),'Target Information')]",IdentifiedBy.XPATH),    
        SITE_URL_LABEL("//div[contains(@class,'scan-object-window')]//div[2][contains(@class,'q-scroller')]//label[contains(text(),'Site URL')]",IdentifiedBy.XPATH),
        
        MAXIMUM_PAGES_LABEL("//div[contains(@class,'scan-object-window')]//div[2][contains(@class,'q-scroller')]//label[contains(text(),'Max. Pages')]",IdentifiedBy.XPATH),
        SCAN_INTENSITY_LABEL("//div[contains(@class,'scan-object-window')]//div[2][contains(@class,'q-scroller')]//label[contains(text(),'Intensity')]",IdentifiedBy.XPATH),
        
        //help tips 
        TURN_HELP_TIPS_ON_OFF_LABEL(".scan-object-window .q-window-header div.help-on"), //TODO : no such element exception
        LAUNCH_HELP_LABEL(".scan-object-window .q-window-header div.launch-help"),
        
        HELP_TIPS_ON(".scan-object-window .q-window-header div.help-on .help-toggle-on"),
        HELP_TIPS_OFF(".scan-object-window .q-window-header div.help-on .help-toggle-off");
    	
		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}
		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}
		
		@Override
		public String getLocator() {
			return this.key;
		}
		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}
    
    public ReviewAndConfirmStepScanLaunch() throws ElementNotFoundException{
    	
        Utility.waitForElementPresent(PageElements.PAGE_LOADING_CHECK);
    }
    
    public TargetPageStep clickPrevious() throws ElementNotFoundException{
        Utility.waitForElementPresent(DialogCommonElements.PREVIOUS_BTN);
        Utility.click(DialogCommonElements.PREVIOUS_BTN);
        return new TargetPageStep();
    }
    
    // ToDo--> can return to dashboard/scans/assets
    public ScanListTab clickFinish() throws ElementNotFoundException{
    	Utility.waitForElementPresent(DialogCommonElements.FINISH_BTN);
    	log.info("clicking on Finsih button of Review and confirm page");
        Utility.click(DialogCommonElements.FINISH_BTN);  
        return new ScanListTab();
    }
    
    
    
    
    public  ReviewAndConfirmStepScanLaunch verifyReviewAndConfirmStepStaticText()
    {
        CustomVerification customVerification = new CustomVerification();
        
      //customVerification.verifyEquals("Target step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help "); //TODO : no such element exception
        customVerification.verifyEquals("Review and Confirm LAUNCH_HELP_",Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL),"Launch help");
        
        customVerification.verifyEquals("Review and Confirm  DEFINITION_HEADER_LABEL    ",Utility.getTextOfPageObject(PageElements.DEFINITION_HEADER_LABEL), "Definition");
        customVerification.verifyEquals("Review and Confirm  SCAN_TITLE_LABEL   ",Utility.getTextOfPageObject(PageElements.SCAN_TITLE_LABEL), "Scan Title");
        customVerification.verifyEquals("Review and Confirm  SITE_TITLE_LABEL    ",Utility.getTextOfPageObject(PageElements.TARGET_INFORMATION_HEADER_LABEL), "Target Information");
        customVerification.verifyEquals("Review and Confirm  SITE_URL_LABEL    ",Utility.getTextOfPageObject(PageElements.SITE_URL_LABEL), "Site URL");
        
        
        customVerification.verifyEquals("Review and Confirm  MAXIMUM_PAGES_LABEL    ",Utility.getTextOfPageObject(PageElements.MAXIMUM_PAGES_LABEL), "Max. Pages");
        customVerification.verifyEquals("Review and Confirm  SCAN_INTENSITY_LABEL    ",Utility.getTextOfPageObject(PageElements.SCAN_INTENSITY_LABEL), "Intensity"); 
        
        customVerification.verifyEquals("Review and Confirm  PREVIOUS_BTN_REVIEW_AND_CONFIRM    ",Utility.getTextOfPageObject(DialogCommonElements.PREVIOUS_BTN_REVIEW_AND_CONFIRM),"Previous");
        customVerification.verifyEquals("Review and Confirm  FINISH_BTN   ",Utility.getTextOfPageObject(DialogCommonElements.FINISH_BTN),"Finish");
        customVerification.verifyEquals("Review and Confirm  CANCEL_BTN   ",Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN),"Cancel");
        
        return this;
        
        
        
    }
}
