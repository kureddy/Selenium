package com.qualys.selenium.mds.pageobject.assets;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.core.pageobject.AbstractFrame;

@Slf4j
public class TagManagementTab extends AbstractFrame {
	

	
	  public enum PageElements implements IPageElement {

	       TAG_MANAGEMENT_TAB_VERIFY("#datalist-tags:not(.x-hide-display)"),
	       

	       //PENDING TO TEST NAVIGATION
	        SHOW_FILTER("#datalist-tags:not(.x-hide-display) .filter-summary-panel .filter-buttons"),
	        CLEAR_FILTER("#datalist-tags:not(.x-hide-display) .filter-summary-panel .filter-buttons .clear-filters-link"),
	        HIDE_FILTER("#datalist-tags:not(.x-hide-display) .filter-summary-panel .filter-buttons .toggle-filter-link"),
	        FILTER_APPLIED_NUMBER("#datalist-tags:not(.x-hide-display) .filter-summary-panel .filter-count span b"),
	        
	        
	        FILTER_EXPANDED_SEARCH_TEXT_FIELD("#datalist-tags:not(.x-hide-display) .filter-panel-expanded .filter-panel:not(.x-hide-display) .filter-column-panel-start .filter-hide-label input");
	        String key;
	        IdentifiedBy identifiedBy;

	        PageElements(String key, IdentifiedBy identifiedBy) {
	            this.key = key;
	            this.identifiedBy = identifiedBy;
	        }

	        PageElements(String key) {
	            this(key, IdentifiedBy.CSS);
	        }

	        @Override
	        public String getLocator() {
	            // TODO Auto-generated method stub
	            return this.key;
	        }

	        @Override
	        public IdentifiedBy getIdentifiedBy() {
	            // TODO Auto-generated method stub
	            return this.identifiedBy;
	        }

	    }
	  
	  
	public TagManagementTab(){
		if (!Utility.isElementPresent(PageElements.TAG_MANAGEMENT_TAB_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException(
					"This is not the Assets>Tag Management page");
		}
	}
	
	//FILTERS EXPANDED NAVIGATION(SHOW FILTERS)
    public TagManagementTab clickShowFilters()
    {
        Utility.click(PageElements.SHOW_FILTER);
        return this;
    }
    
    public TagManagementTab searchFilter()
    {
        Utility.click(PageElements.FILTER_EXPANDED_SEARCH_TEXT_FIELD);
        return this;
    }
   
    public TagManagementTab clickHideFilters()
    {
        Utility.click(PageElements.HIDE_FILTER);
        return this;
    }
    public TagManagementTab clickClearFilters()
    {
        Utility.click(PageElements.CLEAR_FILTER);
        return this;
    }
    
}
