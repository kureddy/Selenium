/* contains following methods:
 * select Checkboxes(all schedules,single schedule) 
 * => Methods --> selectAllSchedulesCheckBox(),selectSingleScheduleCheckBox(String detectionName)
 * 
 * Navigate to QuickActions dropdown(Select View,Rescan Page) 
 * => Methods --> clickQuickActionsDropDown(String detectionName),selectQuickActionsView(String detectionName),selectQuickActionsEdit(String scheduleName),electQuickActionsEdit(String scheduleName)
 * selectQuickActionsSaveAs(String scheduleName),selectQuickActionsActivate(String scheduleName),selectQuickActionsDeactivate(String scheduleName),selectQuickActionsDelete(String scheduleName)
 * 
 * Navigate to refresh button
 * => methods --> refreshScanListPage()
 * 
 * Navigat to Actions dropdown  
 * => methods --> clickActionsDropDown(),selectActionsView(),selectActionsEdit(),selectActionsSaveAs(),selectActionsActivate(),selectActionsDeactivate(),selectActionsDelete(),
 * 
 * Navigate to Filter dropdown on the right(select Download,SortBy-->PageURL,High,Med,Low,Rows Shown-->20,50,100,200)
 * => methods --> clickFilterDropDown(),selectFilterDownload(),selectFilterSortBy(),selectFilterSortByName(),selectFilterSortByScanTitle(),selectFilterSortByTag(),selectFilterRowsShown()
 * selectFilterRowsShown20(),selectFilterRowsShown50(),selectFilterRowsShown100(),selectFilterRowsShown200()

 * Navigate to header Titles(click on PageURL,High,Med,Low,Severity)
 * => methods -->  SortScanNameFromHeader(),SortScanTitleFromHeader(),SortTagFromHeader(),  SortNameFromHeader()
 * 
 *  
 * Navigating to Paging combo(left arrow,right arrow,middle paging combo dropdown)
 * => methods --> leftPagingComboArrowButton(),rightPagingComboArrowButton(),clickPagingComboDropDown(),electPagingComboRange(int start, int end)
 * 
 * 
 * Navigating to left panel data(clicking on Left panel sites),selecting the rows equal to detections found
 * => methods --> clickLeftPanelSitesDataFilter(String siteName),selectRowsShownEqualToLeftPanelDetectionsFound(String siteName)
 * 
 * Getting all text from each column
 * ==> methods --> getAllPageURLText(),getAllHighVulnsText(),getAllMediumVulnsText(),getAllLowVulns(),getAllSeverity()
 * Getting text of each detection (pageURL,high,med,low,severity) 
 *  ==> methods --> getHighVulnsOfDetection(String detectionName),getMedVulnsOfDetection(String detectionName),getLowVulnsOfDetection(String detectionName),getSeverityOfDetection(String detectionName)
 */

package com.qualys.selenium.mds.pageobject.scans;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.schedule.ScheduleDialogue;

@Slf4j
public class SchedulesTab extends ScansPage {

    public enum PageElements implements IPageElement {

    	
    	SCHEDULES_TAB_VERIFY("#datalist-schedules:not(.x-hide-display"),
    	PAGE_LOADING_MASKED_VERIFY("#datalist-schedules:not(.x-hide-display) .mds-schedule-datalist .q-datalist:not(.x-masked) .q-datalist-bwrap:not(.x-masked)"),
        PAGE_LOADING_NOT_MASKED_VERIFY("#datalist-schedules:not(.x-hide-display) .mds-schedule-datalist .q-datalist.x-masked .q-datalist-bwrap.x-masked"),
    	
        NEW_SCHEDULE_DOWN_BTN("//div[contains(@class,'mds-schedule-datalist')]//div[contains(@class,'q-datalist-tbar')]//tr[contains(@class,'x-toolbar-left-row')]//button[contains(text(),'New Schedule')]",IdentifiedBy.XPATH),

    	REFRESH_PAGE_BTN("#datalist-schedules:not(.x-hide-display) .x-small-editor .x-toolbar-right .x-tbar-loading"),
    	
    	FILTER_SETTINGS_DROPDOWN("#datalist-schedules:not(.x-hide-display) .x-small-editor .x-toolbar-right .dlist_view_btn"),
        FILTER_SETTINGS_DOWNLOAD(".q_view_menu .x-menu-list li:nth-child(1)"),
        FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]",IdentifiedBy.XPATH),
           SORT_BY_NAME("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
           SORT_BY_SITE_TITLE("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
           SORT_BY_TAGS("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
           
        FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Rows Shown')]",IdentifiedBy.XPATH),
           ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
           ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
           ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
           ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

           
           
       PAGING_COMBO_LEFT_BTN("#datalist-schedules .q-datalist-tbar.q-datalist-tbar-noheader  .x-toolbar-right tr.x-toolbar-right-row .first:not(.x-item-disabled)"),
       PAGING_COMBO_RIGHT_BTN("#datalist-schedules .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row .last:not(.x-item-disabled)"),
       PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("#datalist-schedules .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row input[name=pagingCombo]"),
       PAGING_COMBO_RANGE_DROPDOWN_CONTAINER(".x-combo-list"),
       PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS(".x-combo-list-item"),
        
       PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM(".x-combo-list .x-combo-list-item:nth-child(1)"),

       LIST_HEADER_SCHEDULE_TITLE("#datalist-schedules:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-hd-name"),
       LIST_HEADER_SITE_TITLE("#datalist-schedules:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-hd-malwareDomain"),
       LIST_HEADER_TAGS("#datalist-schedules:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-td-tag"),
       LIST_HEADER_NEXT_DATE("#datalist-schedules:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-td-nextDate"),
       
       ALL_SCHEDULES_CHECKBOX("#datalist-schedules:not(.x-hide-display) .q-datalist-body table .x-grid3-hd-checker"),
       
       LEFT_PANEL_FILTER_CONTAINER("#datalist-schedules:not(.x-hide-display) .left-navigation .x-panel-bwrap .data-view-filter .data-view-filter-list "),//SUPER ELEMENT
       LEFT_PANEL_FILTER_SCAN_TITLE(".record .url"),//SUB ELEMENT
       LEFT_PANEL_FILTER_SCANS_PERFORMED(".record .desc"),//SUB ELEMENT
       
       EACH_SCHEDULE_ROWS("#datalist-schedules:not(.x-hide-display) .mds-schedule-datalist .x-grid3-scroller"),////SUPER ELEMENT
       EACH_SCHEDULE_NAME(".x-grid3-td-name.q-quick-menu-column"),//SUB ELEMENT
       EACH_SCHEDULE_SITE_TITLE(".x-grid3-td-malwareDomain .x-grid3-col-malwareDomain"),//SUB ELEMENT
       EACH_SCHEDULE_TAGS(".x-grid3-td-tag .x-grid3-col-tag"),//SUB ELEMENT
       EACH_SCHEDULE_NEXT_DATE(".x-grid3-td-nextDate .x-grid3-col-nextDate"),//SUB ELEMENT
       
       
       EACH_SCAN_CHECKBOX("#datalist-schedules:not(.x-hide-display) .x-grid3-scroller .x-grid3-td-checker.x-grid3-cell-first"),

       ACTIONS_DOWN_BTN("#datalist-schedules:not(.x-hide-display) .actionBtn:not(.x-item-disabled)"),
       ACTIONS_DOWN_VIEW("//li[1][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View')]",IdentifiedBy.XPATH),
       ACTIONS_DOWN_EDIT("//li[2][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Edit')]",IdentifiedBy.XPATH),
       ACTIONS_DOWN_SAVE_AS("//li[3][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Save As')]",IdentifiedBy.XPATH),
       ACTIONS_DOWN_ACTIVATE("//li[5][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Activate')]",IdentifiedBy.XPATH),
       ACTIONS_DOWN_DEACTIVATE("//li[6][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Deactivate')]",IdentifiedBy.XPATH),
       ACTIONS_DOWN_DELETE("//li[8][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Delete')]",IdentifiedBy.XPATH),
       
       
       QUICK_ACTIONS_DOWN_BTN("#datalist-schedules:not(.x-hide-display) .q-quick-menu-column"),
       QUICK_ACTIONS_DOWN_QUICK_ACTIONS_LABEL("li.x-menu-list-item:not(.x-item-disabled):nth-child(1)"),
       QUICK_ACTIONS_DOWN_VIEW("li.x-menu-list-item:not(.x-item-disabled):nth-child(2)"),
       QUICK_ACTIONS_DOWN_EDIT("li.x-menu-list-item.x-item-disabled:nth-child(3)"),
       QUICK_ACTIONS_DOWN_SAVE_AS("li.x-menu-list-item:not(.x-item-disabled):nth-child(4)"),
       QUICK_ACTIONS_DOWN_ACTIVATE("li.x-menu-list-item:not(.x-item-disabled):nth-child(6)"),
       QUICK_ACTIONS_DOWN_DEACTIVATE("li.x-menu-list-item.x-item-disabled:nth-child(7)"),
       QUICK_ACTIONS_DOWN_DELETE("li.x-menu-list-item:not(.x-item-disabled):nth-child(9)"),
       

    	//PENDING TO TEST NAVIGATION
        SHOW_FILTER("#datalist-schedules:not(.x-hide-display) .filter-summary-panel .filter-buttons"),
        CLEAR_FILTER("#datalist-schedules:not(.x-hide-display) .filter-summary-panel .filter-buttons .clear-filters-link"),
        HIDE_FILTER("#datalist-schedules:not(.x-hide-display) .filter-summary-panel .filter-buttons .toggle-filter-link"),
        FILTER_APPLIED_NUMBER("#datalist-schedules:not(.x-hide-display) .filter-summary-panel .filter-count span b"),
        
        
        FILTER_EXPANDED_SCHEDULE_NAME_TEXT_FIELD("#datalist-schedules:not(.x-hide-display) .filter-panel-expanded .filter-panel:not(.x-hide-display) .filter-panel-column-body input"),
        
        
        
        FILTER_EXPANDED_SITE_NAME_TEXT_FIELD("#datalist-schedules:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) input"),               
        FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX("#datalist-schedules:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(2) div.x-hide-label input"),
        FILTER_EXPANDED_SITE_TYPE_WAS_CHECKBOX("#datalist-schedules:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(2) div.x-hide-label:last-of-type input"),
      
        FILTER_EXPANDED_TAG_DROPDOWN("#datalist-schedules:not(.x-hide-display) .tag-combo-box span>img:last-of-type"),
        FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
        FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node"),
        FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN("div[class='x-layer']>div+div");
       //Should look at it TODO
    	//MDS_ScansPage_ScanList_FirstScan =div.x-grid3-body>div table.x-grid3-row-table>tbody tr td:nth-child(10) div:nth-child(1).scan-info 


        String key;
        IdentifiedBy identifiedBy;

        PageElements(String key, IdentifiedBy identifiedBy) {
            this.key = key;
            this.identifiedBy = identifiedBy;
        }

        PageElements(String key) {
            this(key, IdentifiedBy.CSS);
        }

        @Override
        public String getLocator() {
            // TODO Auto-generated method stub
            return this.key;
        }

        @Override
        public IdentifiedBy getIdentifiedBy() {
            // TODO Auto-generated method stub
            return this.identifiedBy;
        }

    }
    
    
    public SchedulesTab() throws ElementNotFoundException{
    	if(!Utility.isElementPresent(PageElements.SCHEDULES_TAB_VERIFY))
		{
		log.info("Currently at url : {}", Utility.getCurrentUrl());  
		throw new IllegalStateException("This is not the MDS > Scans page");
		};
        
    }

   
    public ScheduleDialogue clickNewSchedule() {

        Utility.click(PageElements.NEW_SCHEDULE_DOWN_BTN);

        return new ScheduleDialogue("create");
    }

    public SchedulesTab selectAllSchedulesCheckBox() {
        if (Utility.isElementPresent(PageElements.ALL_SCHEDULES_CHECKBOX)) {

            Utility.selectCheckBox(PageElements.ALL_SCHEDULES_CHECKBOX);

        } else {
            throw new NoSuchElementException(
                    "All schedules checkbox is not present");
        }

        return this;
    }

    public SchedulesTab selectSingleSchedulecheckBox(String scheduleName) {
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);

        Utility.selectCheckBoxOfSingleRecord(PageElements.EACH_SCHEDULE_NAME,
        		PageElements.EACH_SCAN_CHECKBOX,
                superElement,scheduleName);

        return this;
    }

    public SchedulesTab clickQuickActionsDropDown(String scheduleName) throws ElementNotFoundException {

        Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_BTN);
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);

        Utility.selectQuickActionsOfSingleRecord(PageElements.EACH_SCHEDULE_NAME,PageElements.QUICK_ACTIONS_DOWN_BTN,
                superElement,scheduleName);

        return this;

    }

    // TODO return type schedule View dialog
    public SchedulesTab selectQuickActionsView(String scheduleName) throws ElementNotFoundException{

        clickQuickActionsDropDown(scheduleName);
        Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW);
        return this;
    }

    public SchedulesTab selectQuickActionsEdit(String scheduleName) throws ElementNotFoundException {

        clickQuickActionsDropDown(scheduleName);
        Utility.click(PageElements.QUICK_ACTIONS_DOWN_EDIT);
        return new SchedulesTab();
    }

    public SchedulesTab selectQuickActionsSaveAs(String scheduleName) throws ElementNotFoundException {
        clickQuickActionsDropDown(scheduleName);
        Utility.click(PageElements.QUICK_ACTIONS_DOWN_SAVE_AS);
        return new SchedulesTab();
    }

    public SchedulesTab selectQuickActionsActivate(String scheduleName) throws ElementNotFoundException {
        clickQuickActionsDropDown(scheduleName);
        Utility.click(PageElements.QUICK_ACTIONS_DOWN_ACTIVATE);
        return new SchedulesTab();
    }

    public SchedulesTab selectQuickActionsDeactivate(String scheduleName) throws ElementNotFoundException {
        clickQuickActionsDropDown(scheduleName);
        Utility.click(PageElements.QUICK_ACTIONS_DOWN_DEACTIVATE);
        return new SchedulesTab();
    }

    public SchedulesTab selectQuickActionsDelete(String scheduleName) throws ElementNotFoundException {
        clickQuickActionsDropDown(scheduleName);
        Utility.click(PageElements.QUICK_ACTIONS_DOWN_DELETE);
        return new SchedulesTab();
    }
    
    public SchedulesTab waitForPageMasking() throws ElementNotFoundException {
        Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY);
        return this;
    }
    
    private SchedulesTab waitForPageUnMasking() throws ElementNotFoundException {
        Utility.waitForElementPresent(PageElements.PAGE_LOADING_NOT_MASKED_VERIFY);
        return this;
        
    }

    public SchedulesTab refreshScanListPage() throws ElementNotFoundException {
        Utility.waitForElementPresent(PageElements.REFRESH_PAGE_BTN);
        Utility.click(PageElements.REFRESH_PAGE_BTN);
        waitForPageMasking();
        waitForPageUnMasking();
        
        
        return this;
    }

    public SchedulesTab clickActionsDropDown() {
        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_BTN)) {
            Utility.click(PageElements.ACTIONS_DOWN_BTN);
        } else {
            throw new NoSuchElementException(
                    "Actions button is either disabled or not present on the page");
        }

        return this;
    }

    public SchedulesTab selectActionsView() {
        clickActionsDropDown();
        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_VIEW)) {
            Utility.click(PageElements.ACTIONS_DOWN_VIEW);
            
        } else {
            throw new NoSuchElementException(
                    "Actions>view button is either disabled or not present on the page");
        }

        return this;
    }

    public SchedulesTab selectActionsEdit() {
        clickActionsDropDown();
        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_EDIT)) {
            Utility.click(PageElements.ACTIONS_DOWN_EDIT);
        } else {
            throw new NoSuchElementException(
                    "Actions>Edit button is either disabled or not present on the page");
        }
        return this;
    }

    public SchedulesTab selectActionsSaveAs() {
        clickActionsDropDown();

        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_SAVE_AS)) {
            Utility.click(PageElements.ACTIONS_DOWN_SAVE_AS);
        } else {
            throw new NoSuchElementException(
                    "Actions>save As button is either disabled or not present on the page");
        }

        return this;
    }

    public SchedulesTab selectActionsActivate() {
        clickActionsDropDown();

        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_ACTIVATE)) {
            Utility.click(PageElements.ACTIONS_DOWN_ACTIVATE);
        } else {
            throw new NoSuchElementException(
                    "Actions>Activate button is either disabled or not present on the page");
        }
        return this;
    }

    public SchedulesTab selectActionsDeactivate() {
        clickActionsDropDown();

        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_DEACTIVATE)) {
            Utility.click(PageElements.ACTIONS_DOWN_DEACTIVATE);
        } else {
            throw new NoSuchElementException(
                    "Actions>Deactivate button is either disabled or not present on the page");
        }
        return this;
    }

    public SchedulesTab selectActionsDelete() {
        clickActionsDropDown();
        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_DELETE)) {
            Utility.click(PageElements.ACTIONS_DOWN_DELETE);
        } else {
            throw new NoSuchElementException(
                    "Actions>Delete button is either disabled or not present on the page");
        }
        return this;
    }

    public SchedulesTab clickFilterDropDown() {

        Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
        return this;
    }

    public SchedulesTab selectFilterDownload() {
        clickFilterDropDown();
        Utility.click(PageElements.FILTER_SETTINGS_DOWNLOAD);
        return this;
    }

    public SchedulesTab selectFilterSortBy() {

        clickFilterDropDown();
        Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);

        return this;
    }

    public SchedulesTab selectFilterSortByName() throws ElementNotFoundException {

        selectFilterSortBy();
        Utility.waitForElementPresent(PageElements.SORT_BY_NAME);
        Utility.moveToElementAndClick(PageElements.SORT_BY_NAME);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab selectFilterSortByScanTitle() throws ElementNotFoundException {
        selectFilterSortBy();
        Utility.waitForElementPresent(PageElements.SORT_BY_SITE_TITLE);
        Utility.moveToElementAndClick(PageElements.SORT_BY_SITE_TITLE);
        return this;
    }

    public SchedulesTab selectFilterSortByTag() throws ElementNotFoundException {

        selectFilterSortBy();
        Utility.waitForElementPresent(PageElements.SORT_BY_TAGS);
        Utility.moveToElementAndClick(PageElements.SORT_BY_TAGS);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab selectFilterRowsShown() throws ElementNotFoundException {

        clickFilterDropDown();
        Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab selectFilterRowsShown20() throws ElementNotFoundException {

        selectFilterRowsShown();
        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab selectFilterRowsShown50() throws ElementNotFoundException {

        selectFilterRowsShown();
        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
        waitForPageMasking();
        waitForPageUnMasking();
        
        return this;
    }

    public SchedulesTab selectFilterRowsShown100() throws ElementNotFoundException {

        selectFilterRowsShown();
        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab selectFilterRowsShown200() throws ElementNotFoundException {
        selectFilterRowsShown();
        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab SortScheduleNameFromHeader() throws ElementNotFoundException {
        Utility.click(PageElements.LIST_HEADER_SCHEDULE_TITLE);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab SortSiteTitleFromHeader() throws ElementNotFoundException

    {
        Utility.click(PageElements.LIST_HEADER_SITE_TITLE);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab SortTagFromHeader() throws ElementNotFoundException {
        Utility.click(PageElements.LIST_HEADER_TAGS);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    // Should not sort by date
    public SchedulesTab SortDateFromHeader() throws ElementNotFoundException {
        Utility.click(PageElements.LIST_HEADER_NEXT_DATE);
        waitForPageMasking();
        waitForPageUnMasking();
        return this;
    }

    public SchedulesTab leftPagingComboArrowButton() throws ElementNotFoundException {
        if (Utility.isElementPresent(PageElements.PAGING_COMBO_LEFT_BTN)) {
            Utility.click(PageElements.PAGING_COMBO_LEFT_BTN);
            waitForPageMasking();
            waitForPageUnMasking();

        } else {
            throw new IllegalStateException(
                    "Left button to navigate to nextpage  element is disabled");
        }
        return this;
    }

    public SchedulesTab rightPagingComboArrowButton() throws ElementNotFoundException {

        if (Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN) != null) {
            Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
            waitForPageMasking();
            waitForPageUnMasking();


        } else {

            throw new IllegalStateException(
                    "Right button to navigate to nextpage  element is disabled");
        }
        return this;
    }

    public SchedulesTab clickPagingComboDropDown() {
        Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
        
        return this;
    }

    // need waitforpageload
    public SchedulesTab selectPagingComboRange(int start, int end) throws ElementNotFoundException {

        clickPagingComboDropDown();
        Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);
        WebElement superElelemnt = Utility
                .getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);

        Utility.selectFromCombo(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS,
           superElelemnt, start + " - " + end + " of "
                        + end);
        waitForPageMasking();
        waitForPageUnMasking();
        System.out.println(start + " - " + end + " of " + end);
        return this;
    }

    public void  selectRowsToGetText() throws ElementNotFoundException {
       
            clickPagingComboDropDown();
            Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);
            String pageRange = Utility
                    .getTextOfPageObject(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);

            String[] splitRange = pageRange.split("\\W");
            int totalSchedules = Integer.parseInt(splitRange[5]);

            if (totalSchedules > 20 && totalSchedules <= 50) {
                selectFilterRowsShown50();
               waitForPageMasking();
            }

            else if (totalSchedules > 50 && totalSchedules <= 100) {
                selectFilterRowsShown100();
                waitForPageMasking();
            }

            else if (totalSchedules > 100 && totalSchedules <= 200) {
                selectFilterRowsShown200();
                waitForPageMasking();
            }
     
    }
    public String getSiteTitleOfSchedule(String scheduleName) throws ElementNotFoundException {

        String siteTilte = "";
        selectRowsToGetText();
        
        waitForPageUnMasking();
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_ROWS);
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);

        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_SITE_TITLE);
        
        siteTilte = Utility.getTextOfRecordColumn(PageElements.EACH_SCHEDULE_SITE_TITLE,
        		PageElements.EACH_SCHEDULE_SITE_TITLE,
                superElement,scheduleName);
        
        return siteTilte;
    }

    public String getTagsOfDetection(String scheduleName) throws ElementNotFoundException {

        String tags = "";
        selectRowsToGetText();
        waitForPageUnMasking();
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_ROWS);
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);

        tags = Utility.getTextOfRecordColumn(PageElements.EACH_SCHEDULE_NAME,
        		PageElements.EACH_SCHEDULE_TAGS,
                superElement,
                scheduleName);
        return tags;
    }

    public String getNextDateOfDetection(String scheduleName) throws ElementNotFoundException {

        String tags = "";
        selectRowsToGetText();
        waitForPageUnMasking();
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_ROWS);
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);

        tags = Utility.getTextOfRecordColumn(PageElements.EACH_SCHEDULE_NAME,
        		PageElements.EACH_SCHEDULE_NEXT_DATE,
                superElement,scheduleName);
        return tags;
    }

    public StringBuffer getAllSiteTitlesText() throws ElementNotFoundException{
        selectRowsToGetText();
        waitForPageUnMasking();
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_ROWS);
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_SITE_TITLE);

        List<WebElement> detectionsPageURLWebElement = Utility
                .getRecordWebEements(PageElements.EACH_SCHEDULE_SITE_TITLE,
                       superElement);
        StringBuffer allPageURLs = new StringBuffer();
        for (int scanTitleRow = 0; scanTitleRow < detectionsPageURLWebElement
                .size(); scanTitleRow++) {
            allPageURLs.append(detectionsPageURLWebElement.get(scanTitleRow)
                    .getText() + "\n");
        }
        return allPageURLs;
    }

    public StringBuffer getAllTagsText() throws ElementNotFoundException{
        selectRowsToGetText();
        waitForPageUnMasking();
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_ROWS);
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_TAGS);
        List<WebElement> highVulnsWebElements = Utility.getRecordWebEements(
        		PageElements.EACH_SCHEDULE_TAGS, superElement);
        StringBuffer allhighVulns = new StringBuffer();
        for (int scanDateRow = 0; scanDateRow < highVulnsWebElements.size(); scanDateRow++) {
            allhighVulns.append(highVulnsWebElements.get(scanDateRow).getText()
                    + "\n");
        }
        return allhighVulns;
    }

    public StringBuffer getAllNextDatesText() throws ElementNotFoundException{
        selectRowsToGetText();
        waitForPageUnMasking();
       
        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_ROWS);
        WebElement superElement = Utility
                .getElement(PageElements.EACH_SCHEDULE_ROWS);

        Utility.waitForElementPresent(PageElements.EACH_SCHEDULE_NEXT_DATE);
        List<WebElement> mediumVulnsWebElements = Utility.getRecordWebEements(
        		PageElements.EACH_SCHEDULE_NEXT_DATE , superElement);
        StringBuffer allMediumVulns = new StringBuffer();
        for (int scanDateRow = 0; scanDateRow < mediumVulnsWebElements.size(); scanDateRow++) {
            allMediumVulns.append(mediumVulnsWebElements.get(scanDateRow)
                    .getText() + "\n");
        }
        return allMediumVulns;
    }
    
    
    //FILTERS EXPANDED NAVIGATION(SHOW FILTERS)
    public SchedulesTab clickShowFilters()
    {
        Utility.click(PageElements.SHOW_FILTER);
        return this;
    }
    
   
   

    public SchedulesTab filterByScheduleName(String scheduleName)
    {
        Utility.typeInEditBox(PageElements.FILTER_EXPANDED_SCHEDULE_NAME_TEXT_FIELD,scheduleName);
        return this;
    }
   
    
    public SchedulesTab typeSiteNametoFilter(String siteName)
    {
        Utility.typeInEditBox(PageElements.FILTER_EXPANDED_SITE_NAME_TEXT_FIELD,siteName);
        return this;
    }
    
    public SchedulesTab filterBySiteTypeCheckbox(String mdsORwas)
    {
        if(mdsORwas.equalsIgnoreCase("MDS"))
        {
            Utility.click(PageElements.FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX);
        }
        else if(mdsORwas.equalsIgnoreCase("WAS"))
        {
            Utility.click(PageElements.FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX);
        }
        return this;
    }
    
    public SchedulesTab filterByTags(String tagName) throws ElementNotFoundException
    {
        

        Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN);

        Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

        WebElement superElement = Utility
                .getElement(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

        Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS);

        Utility.selectMultipleValuesDoubleClick(
                PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS, superElement,
                tagName);
        Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN);
        return this;
    }
  
    
   
    
    
    
    public SchedulesTab clickHideFilters()
    {
        Utility.click(PageElements.HIDE_FILTER);
        return this;
    }
    public SchedulesTab clickClearFilters()
    {
        Utility.click(PageElements.CLEAR_FILTER);
        return this;
    }

}
