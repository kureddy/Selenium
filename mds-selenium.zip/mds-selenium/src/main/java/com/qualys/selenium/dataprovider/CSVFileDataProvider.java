package com.qualys.selenium.dataprovider;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.testng.annotations.DataProvider;

import au.com.bytecode.opencsv.CSVReader;

public class CSVFileDataProvider {
	
	@DataProvider(name="getDataFromFile")
    public static Iterator<Object[]> getDataFromFile(Method testMethod) throws Exception{
    	
    	//Getting the filename from the DataProviderArguments annotation defined on top of each test method
    	DataProviderArguments args = testMethod.getAnnotation(DataProviderArguments.class);
    	String fileName = args.fileName();
    	
    	if(!fileName.endsWith(".csv")){
    		throw new RuntimeException("ONLY SUPPORTING CSV FOR NOW");
    	}
    	
    	//Reading all the lines from the file.
    	//Currently only supporting CSV
         List<String> lines = CSVFileDataProvider.getRawLinesFromFile(fileName);
        

    	//Getting the method parameter datatypes
    	@SuppressWarnings("rawtypes")
		Class[] methodParameterTypes = testMethod.getParameterTypes();
        if(methodParameterTypes.length == 1 && methodParameterTypes[0].getName().startsWith("com.qualys.selenium")){
    		return getCustomObjectInstance(methodParameterTypes[0], lines);
    	}
        List<Object[]> data = new ArrayList<Object[]>();
        for (String line : lines){
        	//Each line in CSV should match with the test method accepted parameters (order also matters) 
        	CSVReader reader = new CSVReader(new StringReader(line), ',', '\'');            
        	String parametersString[] = reader.readNext();
        	reader.close();
        	Object[] parameterValues = new Object[parametersString.length];

        	
    		int i=0;
        	for(String attributeValue: parametersString){
        		if(methodParameterTypes[i].getName().equals("java.lang.Integer") ||
        				methodParameterTypes[i].getName().equals("int")){
        			parameterValues[i] = new Integer(attributeValue);
        		}else if(methodParameterTypes[i].getName().equals("java.lang.Long") ||
        				methodParameterTypes[i].getName().equals("long")){
        			parameterValues[i] = new Long(attributeValue);
        		}else{
        			parameterValues[i] = attributeValue;
        		}
        		i++;	
        	}
            data.add(parameterValues);
        	
        }
        return data.iterator();
    }
    
	private static Iterator<Object[]> getCustomObjectInstance(@SuppressWarnings("rawtypes") Class clazz, List<String> lines) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IOException{
    	List<Object[]> list = new ArrayList<Object[]>();
		String[] fieldNames = lines.get(0).split(",");
		for(int i=1;i<lines.size();i++){
			Object obj = clazz.newInstance();
			//String[] fieldValues = lines.get(i).split(",");
			CSVReader reader = new CSVReader(new StringReader(lines.get(i)), ',', '"');            
        	String[] fieldValues= reader.readNext();
        	reader.close();
			int index = 0;
			for(String fieldName: fieldNames){
				setField(obj, fieldName, fieldValues[index++]);
			}
			list.add(new Object[]{obj});
		}
		return list.iterator();
    }
 
    private static boolean setField(Object object, String fieldName, Object fieldValue) {
        Class<?> clazz = object.getClass();
        while (clazz != null && fieldValue != null) {
            try {
                Field field = clazz.getDeclaredField(fieldName);
                field.setAccessible(true);
                
                
                if(field.getType().getName().equals("java.lang.Integer") ||
                		field.getType().getName().equals("int")){
                	field.set(object, new Integer(fieldValue.toString()));
        		}else if(field.getType().getName().equals("java.lang.Long") ||
                		field.getType().getName().equals("long")){
                	field.set(object, new Long(fieldValue.toString()));
        		}else{
        			field.set(object, fieldValue);
        		}
                return true;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
    public static List<String> getRawLinesFromFile(String filePath) throws Exception{
        InputStream is = CSVFileDataProvider.class.getResourceAsStream(filePath);
        List<String> lines = IOUtils.readLines(is, "UTF-8");
        
        is.close();
        return lines;
    }
}
