package com.qualys.selenium.mds.pageobject.dialogs.reports;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;
import com.qualys.selenium.mds.pageobject.dialogs.reports.ReportSelectionDialog.ScanSelectionDialog;
import com.qualys.selenium.mds.pageobject.dialogs.reports.ReportSelectionDialog.SiteSelectionDialog;
import com.qualys.selenium.mds.pageobject.dialogs.reports.ReportSelectionDialog.SummarySelectionDialog;
import com.qualys.selenium.mds.pageobject.reports.ReportsPage;
import com.qualys.selenium.mds.pageobject.reports.ScanReportTab;
import com.qualys.selenium.mds.pageobject.reports.SiteReportTab;
import com.qualys.selenium.mds.pageobject.reports.SummaryReportTab;

@Slf4j
public class NewReport extends AbstarctReportsDialog {

	public enum ReportType {

		SCAN("Scan Report"),
		SITE("Site Report"),
		SUMMARY("Summary Report");

		String uiValue;

		ReportType(String uiValue) {
			this.uiValue = uiValue;
		}

		public String getUiValue() {
			return this.uiValue;
		}
	}

	private ReportType reportType;

	public enum PageElements implements IPageElement {

		NEW_REPORT_DIALOG_VERIFY("//span[text()='Define your new report']", IdentifiedBy.XPATH),

		NEW_REPORT_TAB_MASK("div[class*=frame-mask]"),

		NEW_REPORT_HEADER_TEXT("div[class*=-dialog] span[class*=dialog-header-text]"),

		CHOOSE_REPORT_TYPE_DROPDOWN("div[class*=-dialog] div[class*=section-edit-panel] div[class*=form-field-trigger-wrap] img"),
		// CHOOSE_REPORT_TYPE_DROPDOWN_CONTAINER("div[class*=combo-list] div[class*=combo-list-inner]"),
		CHOOSE_REPORT_TYPE_DROPDOWN_CONTAINER("div:last-of-type[class*=combo-list] div[class*=combo-list-inner]"),
		CHOOSE_REPORT_TYPE_DROPDOWN_CONTAINER_ITEMS("div[class*=combo-list-item]"),

		REPORT_BY_SITE_RADIO_BTN("div:nth-of-type(1)[class*=-hide-label] input[name=reportBy]"),
		REPORT_SEARCH_TRIGGER("div[class*=q-dialog] div:nth-of-type(3)[class*=section-panel] div:not(.x-item-disabled)[class*=field-wrap] img[class*=search-trigger]"),

		REPORT_BY_TAG_RADIO_BTN("div:nth-of-type(3)[class*=-hide-label] input[name=reportBy]"),
		TAGS_COMBO_DOWN_ARROW_TRIGGER(
				"div[class*=q-dialog] div:nth-of-type(3)[class*=section-panel] div[class*=form-item] div:not(.x-item-disabled)[class=tag-combo-box] span[class*=twin-triggers] img:nth-of-type(2)"),
		// TAGS_COMBO_DOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
		//TAGS_COMBO_DOWN_CONTAINER("//div[contains(@style,'visibility: visible')]//div[contains(@class,'basic-tag-tree')]//ul[contains(@class,'-tree-arrows')]//div[contains(@class,'tree-root-node')]",IdentifiedBy.XPATH),
		//TAGS_COMBO_DOWN_CONTAINER("//div[contains(@style,'visibility: visible')]//div[contains(@class,'basic-tag-tree')]//div[contains(@class,'-panel-body-noheader')]//ul[contains(@class,'tree-arrows')]",IdentifiedBy.XPATH),
		 TAGS_COMBO_DOWN_CONTAINER("//div[contains(@style,'visibility: visible')]//div[contains(@class,'basic-tag-tree')]//div[contains(@class,'-tree-root-node')]",IdentifiedBy.XPATH),
				
				
		// TAGS_COMBO_DOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node");
		TAGS_COMBO_DOWN_CONTAINER_ITEMS("//div[contains(@class,'basic-tag-tree')]//ul//li[contains(@class,'tree-node')]", IdentifiedBy.XPATH);

		// PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM("div[class*=combo-list] div[class*=combo-list-inner] div:first-child[class*=combo-selected]"),

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}
	}

	public NewReport() throws ElementNotFoundException {
		if (!Utility.isElementPresent(PageElements.NEW_REPORT_DIALOG_VERIFY) || !Utility.getTextOfPageObject(PageElements.NEW_REPORT_HEADER_TEXT).equals("Define your new report")) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Reports>New Report List page.Landed on : " + Utility.getCurrentUrl()  );
		}
	}

	public void waitForPageToUnMask() {
		log.info("waiting for New report dialog to unmask");
		Utility.waitUntilElementDissAppears(PageElements.NEW_REPORT_TAB_MASK);

	}

	public NewReport selectReportFromDropDown(ReportType reportType) throws ElementNotFoundException {

		Utility.click(PageElements.CHOOSE_REPORT_TYPE_DROPDOWN);

		Utility.waitForElementPresent(PageElements.CHOOSE_REPORT_TYPE_DROPDOWN_CONTAINER);

		WebElement superElement = Utility.getElement(PageElements.CHOOSE_REPORT_TYPE_DROPDOWN_CONTAINER);

		Utility.waitForElementPresent(PageElements.CHOOSE_REPORT_TYPE_DROPDOWN_CONTAINER_ITEMS);

		Utility.selectFromCombo(PageElements.CHOOSE_REPORT_TYPE_DROPDOWN_CONTAINER_ITEMS, superElement, reportType.getUiValue());

		this.reportType = reportType;
		return this;
	}

	public NewReport selectReportBySiteRadioBtn() throws ElementNotFoundException {
		Utility.selectRadioButton(PageElements.REPORT_BY_SITE_RADIO_BTN);
		return this;
	}

	public ScanSelectionDialog clickReportByScanSearchTrigger() throws ElementNotFoundException {
		Utility.click(PageElements.REPORT_SEARCH_TRIGGER);
		return new ScanSelectionDialog(this);
	}

	public SiteSelectionDialog clickReportBySiteSearchTrigger() throws ElementNotFoundException {
		if (Utility.isRadioButtonSelected(PageElements.REPORT_BY_SITE_RADIO_BTN)) {
			Utility.click(PageElements.REPORT_SEARCH_TRIGGER);
		} else {
			selectReportBySiteRadioBtn();
			Utility.click(PageElements.REPORT_SEARCH_TRIGGER);
		}
		return new SiteSelectionDialog(this);
	}

	public SummarySelectionDialog clickReportBySummerySearchTrigger() throws ElementNotFoundException {
		Utility.click(PageElements.REPORT_SEARCH_TRIGGER);
		return new SummarySelectionDialog(this);
	}

	public NewReport selectReportByTagRadioBtn() throws ElementNotFoundException {
		Utility.selectRadioButton(PageElements.REPORT_BY_TAG_RADIO_BTN);
		return this;
	}

	public NewReport selectTags(String selectTag) throws ElementNotFoundException, InterruptedException {
		selectReportByTagRadioBtn();
		if (!selectTag.equalsIgnoreCase("none")) {

			try {
				waitForPageToUnMask();
				Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_ARROW_TRIGGER);
				Utility.click(PageElements.TAGS_COMBO_DOWN_ARROW_TRIGGER);
				log.info("Clicking on  Element TAGS_COMBO_DOWN_ARROW_TRIGGER");
			} catch (Exception e) {
				log.error("Error while Clicking on TAGS_COMBO_DOWN_ARROW_TRIGGER");
				e.printStackTrace();
			}

			try {

				Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_CONTAINER);

				log.info("Waiting for Element Element TAGS_COMBO_DOWN_CONTAINER");

			} catch (Exception e) {
				log.error("Error while waiting for TAGS_COMBO_DOWN_CONTAINER");
				e.printStackTrace();
			}

			WebElement superElement = Utility.getElement(PageElements.TAGS_COMBO_DOWN_CONTAINER);
			Thread.sleep(100);
			//System.out.println("tags are: " + superElement.getText());
			System.out.println("tags are: " + superElement.getText());
			if (!superElement.getText().equals("")) {
				try {
					Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS);

					log.info("Waiting for Element Element TAGS_COMBO_DOWN_CONTAINER_ITEMS");

				} catch (Exception e) {
					log.error("Error while waiting for TAGS_COMBO_DOWN_CONTAINER_ITEMS");
					e.printStackTrace();
				}
				if (selectTag.contains("-")) {

					String[] splitEachTag = selectTag.split("-");
					for (String eachTag : splitEachTag) {
						System.out.println(eachTag);
						try {
							Utility.selectMultipleValuesDoubleClick(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS, superElement, eachTag);
							log.info("Selecting and double clicking on  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + eachTag);
						} catch (Exception e) {
							log.error("Error while selecting  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + eachTag);
							e.printStackTrace();
						}
					}
				} else {
					try {
						Utility.selectMultipleValuesDoubleClick(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS, superElement, selectTag);
						log.info("Selecting and double clicking on  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + selectTag);
					} catch (Exception e) {
						log.error("Error while selecting  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + selectTag);
						e.printStackTrace();
					}

				}

				return this;
			} else {
				log.warn("User do not have any tags to select");
				return this;
			}
		} else {
			log.info("selectTag = " + selectTag + " so not selecting any tags");
			return this;
		}
	}

	public ReportsPage clickCreateBtn() throws ElementNotFoundException {
		Utility.click(DialogCommonElements.CREATE_BTN);
		switch (this.reportType) {
		case SCAN:
			return new ScanReportTab();
		case SITE:
			return new SiteReportTab();
		case SUMMARY:
			return new SummaryReportTab();
		default:
			throw new RuntimeException("No Report Type selected");
		}
	}

}
