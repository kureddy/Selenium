package com.qualys.selenium.mds.pageobject.dialogs.reports.ReportSelectionDialog;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;
import com.qualys.selenium.mds.pageobject.dialogs.reports.NewReport;
import com.qualys.selenium.mds.pageobject.dialogs.reports.SelectionDialog;

@Slf4j
public class SummarySelectionDialog extends SelectionDialog {
	int totalRows;
	int rowsInCurrentPage;
	int currentPage;

	public enum PageElements implements IPageElement {

		SELECTION_DIALOG_VERIFY("div[class*=selection-dialog]"),

		DIALOG_MASK("div[class*=frame-mask]"),

		FILTER_SETTINGS_DROPDOWN("div[class*=q-dialog] tr[class*=toolbar-right-row] td:nth-of-type(5) button[class*=icon-pager]"),
		FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]", IdentifiedBy.XPATH),
		SORT_BY_URL("li:nth-of-type(1)[class*=menu-list-item] a[class*=-menu-group-item] span[class*=menu-item-text]"),
		SORT_BY_SITE_NAME("li:nth-of-type(2)[class*=menu-list-item] a[class*=-menu-group-item] span[class*=menu-item-text]"),

		FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'view_menu') and not(contains(@class,' hide-offsets'))]//span[contains(text(),'Rows Shown')]"),
		ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

		PAGING_COMBO_LEFT_BTN("div[class*=q-dialog] table[class*=toolbar-right] .first:not(.x-item-disabled) button[class*=page-prev]"),
		PAGING_COMBO_RIGHT_BTN("div[class*=q-dialog] table[class*=toolbar-right] .last:not(.x-item-disabled) button[class*=page-next]"),
		PAGING_COMBO_CURRENT_RANGE(".q-dialog .q-datalist-tbar-noheader td[class*=-toolbar-right] tr[class*=-toolbar-right-row] td:nth-of-type(2) input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("div[class*=q-dialog] div[class*=datalist-tbar] td[class*=toolbar-right] input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER("//div[contains(@style,'visibility: visible')]//div[contains(@class,'combo-list-inner')]", IdentifiedBy.XPATH),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS("//div[contains(@style,'visibility: visible')]//div[contains(@class,'-combo-list-item')]", IdentifiedBy.XPATH),

		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM("div:last-of-type[class*=combo-list] div[class*=-combo-list-inner]"),

		ITEMS_ALL_ROWS("div[class*=selection-dialog] div[class*=scroller]"),

		EACH_URL_COLUMN_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-first]"),
		EACH_SITE_COLUMN_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-last]"),

		EACH_SITE_URL_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-first]"),
		EACH_SITE_NAME_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-last]");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	private NewReport callingPage;

	public SummarySelectionDialog(NewReport callingPage) throws ElementNotFoundException {
		this.callingPage = callingPage;
		if (!Utility.isElementPresent(PageElements.SELECTION_DIALOG_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Scans>Scan List page");
		}
	}

	/*
	 * public SelectionDialog waitForPageMasking() { try {
	 * log.info("Waiting for page to mask");
	 * Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY); }
	 * catch (Exception e) { log.error(e.getMessage()); } return this; }
	 * 
	 * private SelectionDialog waitForPageUnMasking() { try {
	 * log.info("Waiting for page to unmask");
	 * Utility.waitForElementPresent(PageElements
	 * .PAGE_LOADING_NOT_MASKED_VERIFY); } catch (Exception e) {
	 * log.error(e.getMessage()); } return this;
	 * 
	 * }
	 */

	public void waitForPageToUnMask() {
		log.info("waiting for New report dialog to unmask");
		Utility.waitUntilElementDissAppears(PageElements.DIALOG_MASK);

	}

	public SummarySelectionDialog clickFilterDropDown() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.FILTER_SETTINGS_DROPDOWN);
		Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
		return this;
	}

	public SummarySelectionDialog selectFilterSortBy() throws ElementNotFoundException {
		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);
		return this;
	}

	public SummarySelectionDialog selectFilterSortByFirstItem() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.moveToElementAndClick(PageElements.SORT_BY_URL);
		/*
		 * waitForPageMasking(); waitForPageUnMasking(); ;
		 */
		return this;
	}

	public SummarySelectionDialog selectFilterSortBySecondItem() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_SITE_NAME);
		Utility.moveToElementAndClick(PageElements.SORT_BY_SITE_NAME);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;

	}

	public SummarySelectionDialog selectFilterRowsShown() throws ElementNotFoundException {
		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);

		return this;
	}

	public SummarySelectionDialog selectFilterRowsShown20() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public SummarySelectionDialog selectFilterRowsShown50() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public SummarySelectionDialog selectFilterRowsShown100() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public SummarySelectionDialog selectFilterRowsShown200() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public SummarySelectionDialog clickPagingComboDropDown() throws ElementNotFoundException {

		waitForPageToUnMask();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		return this;
	}

	public String pageRange() throws ElementNotFoundException {
		// clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_CURRENT_RANGE);
		String pageRange = Utility.getValueOfPAgeObject(PageElements.PAGING_COMBO_CURRENT_RANGE);
		// clickPagingComboDropDown();
		return pageRange;

		/*
		 * String[] splitRange = pageRange.split("\\W"); totalRows =
		 * Integer.parseInt(splitRange[5]); rowsInCurrentPage =
		 * Integer.parseInt(splitRange[3]);
		 */
	}

	public boolean isOnFirstPage() throws ElementNotFoundException {
		boolean isOnFirstPage = false;
		String[] splitRange = pageRange().split("\\W");
		currentPage = Integer.parseInt(splitRange[0]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		if (currentPage == 1) {
			isOnFirstPage = true;
		} else {
			isOnFirstPage = false;
		}
		return isOnFirstPage;
	}

	public int getTotalRows() throws ElementNotFoundException {

		String[] splitRange = pageRange().split("\\W");
		totalRows = Integer.parseInt(splitRange[5]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		return totalRows;
	}

	public int getRowsInCurrentPage() throws ElementNotFoundException {
		String[] splitRange = pageRange().split("\\W");

		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		return rowsInCurrentPage;
	}

	public SummarySelectionDialog clickSettingsDownBtn() {

		Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
		return this;
	}

	public SummarySelectionDialog selectRowsShown(int totalRowsToShow) {
		if (totalRowsToShow <= 20) {
			Utility.click(PageElements.ROWS_SHOWN_20);
		} else if (totalRowsToShow >= 20 && totalRowsToShow <= 50) {
			Utility.click(PageElements.ROWS_SHOWN_50);

		} else if (totalRowsToShow >= 50 && totalRowsToShow <= 100) {
			Utility.click(PageElements.ROWS_SHOWN_100);

		} else if (totalRowsToShow >= 100 && totalRowsToShow <= 200) {
			Utility.click(PageElements.ROWS_SHOWN_200);
		} else if (totalRowsToShow >= 200) {

		}

		return this;
	}

	public SummarySelectionDialog clickrightPagingComboArrowButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN);
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);

			waitForPageToUnMask();
		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	// Scan Report --> Scan Date
	// Site/summery Report --> URL
	public SummarySelectionDialog selectURL(String searchForUrl) throws ElementNotFoundException {
		waitForPageToUnMask();

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);
		Utility.waitForElementPresent(PageElements.EACH_URL_COLUMN_ROWS);
		try {
			int totalRowsInDL = getTotalRows();
			int pagination = 0;
			List<WebElement> siteNames = new ArrayList<WebElement>();
			boolean containsInThisPage = false;
			while (pagination <= (totalRowsInDL / 20)) {
				siteNames = Utility.getRecordWebEements(PageElements.EACH_URL_COLUMN_ROWS, superElement);
				for (int i = 0; i < siteNames.size(); i++) {
					if (siteNames.get(i).getText().equals(searchForUrl)) {
						containsInThisPage = true;
						Utility.selectFromCombo(PageElements.EACH_URL_COLUMN_ROWS, superElement, searchForUrl);
						pagination = ((totalRowsInDL / 20) + 1);
						i = siteNames.size();

					} else {
						containsInThisPage = false;
					}
				}
				if (!containsInThisPage) {
					clickrightPagingComboArrowButton();
					siteNames.clear();
					pagination++;
				}

			}

		} catch (ElementNotFoundException e) {
			log.info("Summary URL was not found");
			Assert.fail(searchForUrl + " : Summary URL was not found");
		}
		return this;
	}

	public SummarySelectionDialog selectSiteName(String searchBySiteName) throws ElementNotFoundException {
		waitForPageToUnMask();

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);
		Utility.waitForElementPresent(PageElements.EACH_SITE_NAME_ROWS);
		try {
			int totalRowsInDL = getTotalRows();
			int pagination = 0;
			List<WebElement> siteNames = new ArrayList<WebElement>();
			boolean containsInThisPage = false;
			while (pagination <= (totalRowsInDL / 20)) {
				siteNames = Utility.getRecordWebEements(PageElements.EACH_SITE_NAME_ROWS, superElement);
				for (int i = 0; i < siteNames.size(); i++) {
					if (siteNames.get(i).getText().equals(searchBySiteName)) {
						containsInThisPage = true;
						Utility.selectFromCombo(PageElements.EACH_SITE_NAME_ROWS, superElement, searchBySiteName);
						pagination = ((totalRowsInDL / 20) + 1);
						i = siteNames.size();

					} else {
						containsInThisPage = false;
					}
				}
				if (!containsInThisPage) {
					clickrightPagingComboArrowButton();
					siteNames.clear();
					pagination++;
				}

			}

		} catch (ElementNotFoundException e) {
			log.info("Site Name was not found");
			Assert.fail(searchBySiteName + " : Site Name was not found");
		}
		return this;
	}

	public NewReport clickSelectBtn() throws ElementNotFoundException {
		Utility.waitForElementPresent(DialogCommonElements.SELECT_BTN);
		Utility.click(DialogCommonElements.SELECT_BTN);

		return callingPage;
	}

}
