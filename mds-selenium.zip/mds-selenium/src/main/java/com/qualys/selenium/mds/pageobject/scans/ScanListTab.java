package com.qualys.selenium.mds.pageobject.scans;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite.NewScanEntireSiteDialog;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite.TargetPageStep;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.singlepage.NewScanSinglePage;
import com.qualys.selenium.mds.pageobject.reports.ScanReportTab;

@Slf4j
public class ScanListTab extends ScansPage {

	int totalRows;
	int rowsInCurrentPage;
	String nameOfScan = "";

	public enum PageElements implements IPageElement {

		SCAN_LIST_TAB_VERIFY("#scan-history:not(.x-hide-display)"),
		PAGE_LOADING_NOT_MASKED_VERIFY("#scan-history:not(.x-hide-display) .tab-navigation-panel .q-datalist:not(.x-masked) .q-datalist-bwrap:not(.x-masked)"),
		PAGE_LOADING_MASKED_VERIFY("#scan-history:not(.x-hide-display) .tab-navigation-panel .q-datalist.x-masked .q-datalist-bwrap.x-masked"),

		NEW_SCAN_DOWN_BTN("//div[contains(@class,'content-panel')]//button[contains(text(),'New Scan')]", IdentifiedBy.XPATH),
		NEW_SCAN_ENTIRE_SITE("//div[contains(@class,'q-quick-menu')]//span[contains(text(),'Scan Entire Site')]", IdentifiedBy.XPATH),
		NEW_SCAN_SINGLE_PAGE("//div[contains(@class,'q-quick-menu')]//span[contains(text(),'Scan Single Page')]", IdentifiedBy.XPATH),

		REFRESH_PAGE_BTN("#scan-history:not(.x-hide-display) .content-panel table.refresh-btn"),
		// MDS_ScansPage_ScanListTab_AfterRefreshPage_WaitFor=.content-panel

		FILTER_SETTINGS_DROPDOWN("#scan-history:not(.x-hide-display) .x-small-editor .x-toolbar-right .dlist_view_btn"),
		FILTER_SETTINGS_DOWNLOAD(".q_view_menu .x-menu-list li:nth-child(1)"),
		FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]", IdentifiedBy.XPATH),
		SORT_BY_SCAN_TITLE("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		SORT_BY_SCAN_DATE("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		SORT_BY_SCANNED_PAGES("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		SORT_BY_STATUS("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),
		FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Rows Shown'"),
		ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

		PAGING_COMBO_LEFT_BTN("#scan-history:not(.x-hide-display) div[class*=datalist-tbar] div[class*=small-editor] td[class*=toolbar-right] .first:not(.x-item-disabled) button[class*=page-prev]"),
		PAGING_COMBO_RIGHT_BTN("#scan-history:not(.x-hide-display)  div[class*=datalist-tbar] div[class*=small-editor] td[class*=toolbar-right] .last:not(.x-item-disabled) button[class*=page-next]"),
		PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("#scan-history:not(.x-hide-display) div[class*=datalist-tbar] td[class*=toolbar-right] input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER(".x-combo-list"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS(".x-combo-list-item"),

		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM("div[class*=combo-list] div[class*=combo-list-inner] div:first-child[class*=combo-selected]"),

		LIST_HEADER_SCAN_TITLE("#scan-history:not(.x-hide-display) .tab-navigation-panel .x-grid3-header .x-grid3-td-title"),
		LIST_HEADER_SCAN_DATE("#scan-history:not(.x-hide-display) .tab-navigation-panel .x-grid3-header  .x-grid3-td-startDate"),
		LIST_HEADER_SCANNED_PAGES("#scan-history:not(.x-hide-display) .tab-navigation-panel .x-grid3-header  .x-grid3-td-scannedPages"),
		LIST_HEADER_STATUS("#scan-history:not(.x-hide-display) .tab-navigation-panel .x-grid3-header  .x-grid3-td-status"),
		LIST_HEADER_SEVERITY("#scan-history:not(.x-hide-display) .tab-navigation-panel .x-grid3-header  .x-grid3-cell-last"),

		ALL_SCANS_CHECKBOX("#scan-history:not(.x-hide-display) .content-panel .q-datalist-body table .x-grid3-hd-checker"),

		LEFT_PANEL_FILTER_CONTAINER("#scan-history:not(.x-hide-display) .left-navigation .x-panel-bwrap .data-view-filter .data-view-filter-list "), // SUPER
																																						// ELEMENT
		LEFT_PANEL_FILTER_SCAN_TITLE(".record .url"), // SUB ELEMENT
		LEFT_PANEL_FILTER_SCANS_PERFORMED(".record .desc"), // SUB ELEMENT

		// EACH_SCAN_ROWS("#scans:not(.x-hide-display) .content-panel .x-grid3-scroller"),

		// SUPER ELEMENT
		SCAN_DATALIST_ALL_ROWS("#scans:not(.x-hide-display) .content-panel div[class*=grid3-scroller]"),
		EACH_SCAN_TITLE(".scan-info div:nth-child(1).text-ellipsis "), // SUB
																		// ELEMENT
		EMPTY_REPORT_LIST("#scan-history:not(.x-hide-display) div[class*=grid-empty]"),
		EACH_SCAN_URL(".scan-info div:nth-child(2).dash-scan-link.text-ellipsis"), // SUB
																					// ELEMENT
		EACH_SCAN_DATE(".x-grid3-td-startDate .x-grid3-col-startDate .q-date"), // SUB
																				// ELEMENT
		EACH_SCANNED_PAGES(".x-grid3-td-scannedPages .x-grid3-col-scannedPages"), // SUB
																					// ELEMENT
		EACH_SCAN_STATUS(".x-grid3-td-status .x-grid3-col-status"), // SUB
																	// ELEMENT
		EACH_SCAN_SEVERITY(".x-grid3-cell-last .severity-level .severity-SAFE"), // SUB
																					// ELEMENT

		EACH_SCAN_CHECKBOX(".x-grid3-col-checker .x-grid3-row-checker"),

		ACTIONS_DOWN_BTN("#scan-history:not(.x-hide-display) .actionBtn:not(.x-item-disabled))"),
		ACTIONS_DOWN_VIEW_REPORT_ENABLED("//li[1][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View Report')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_VIEW_REPORT_DISABLED("//li[1][contains(@class,'x-item-disabled')]//span[contains(@class,'x-menu-item-text') and contains(text(),'View Report')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_VIEW("//li[2][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View')]"),
		ACTIONS_DOWN_CANCEL_SCAN_ENABLED("//li[4][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Cancel Scan')]"),
		ACTIONS_DOWN_CANCEL_SCAN_DISABLED("//li[4][contains(@class,'x-item-disabled')]//span[contains(@class,'x-menu-item-text') and contains(text(),'Cancel Scan')]"),
		ACTIONS_DOWN_SCAN_AGAIN("//li[5][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Scan Again')]"),

		QUICK_ACTIONS_DOWN_BTN("#scan-history:not(.x-hide-display) .q-quick-menu-column"),
		QUICK_ACTIONS_DOWN_QUICK_ACTIONS_LABEL("li.x-menu-list-item:not(.x-item-disabled):nth-child(1) "),
		QUICK_ACTIONS_DOWN_VIEW_REPORT_ENABLED("li.x-menu-list-item:not(.x-item-disabled):nth-child(2)"),
		QUICK_ACTIONS_DOWN_VIEW_REPORT_DISABLED("li.x-menu-list-item.x-item-disabled:nth-child(2)"),
		QUICK_ACTIONS_DOWN_VIEW("li.x-menu-list-item:not(.x-item-disabled):nth-child(3)"),
		QUICK_ACTIONS_DOWN_CANCEL_SCAN_ENABLED("li.x-menu-list-item:not(.x-item-disabled):nth-child(5)"),
		QUICK_ACTIONS_DOWN_CANCEL_SCAN_DISABLED("li.x-menu-list-item.x-item-disabled:nth-child(5)"),
		QUICK_ACTIONS_DOWN_SCAN_AGAIN("li.x-menu-list-item:not(.x-item-disabled):nth-child(6)"),

		CANCEL_SCAN_DIALOGE_CLOSE_CROSS_BTN(".dialog-confirm div.q-dialog-header div.x-close"),
		CANCEL_SCAN_DIALOGE_CANCEL_BTN(".dialog-confirm div.q-dialog-footer .q-btn-gray-light"),
		CANCEL_SCAN_DIALOGE_CONFIRM_BTN(".dialog-confirm div.q-dialog-footer .q-btn-blue-light"),

		// PENDING TO TEST NAVIGATION
		SHOW_FILTER("#scan-history:not(.x-hide-display) .filter-summary-panel .filter-buttons"),
		CLEAR_FILTER("#scan-history:not(.x-hide-display) .filter-summary-panel .filter-buttons .clear-filters-link"),
		HIDE_FILTER("#scan-history:not(.x-hide-display) .filter-summary-panel .filter-buttons .toggle-filter-link"),
		FILTER_APPLIED_NUMBER("#scan-history:not(.x-hide-display) .filter-summary-panel .filter-count span b"),

		// FILTER_EXPANDED_SEARCH_TEXT_FIELD("#scan-history:not(.x-hide-display) .filter-panel-expanded .filter-panel:not(.x-hide-display) .filter-column-panel-start .filter-hide-label input"),

		FILTER_EXPANDED_TAG_DROPDOWN("#scan-history:not(.x-hide-display) .tag-combo-box span>img:last-of-type"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN("div[class='x-layer']>div+div"),

		FILTER_EXPANDED_SCAN_URL_TEXT_FIELD("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) input"),
		FILTER_EXPANDED_SCAN_TITLE_TEXT_FIELD("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(2) input"),
		FILTER_EXPANDED_SCAN_DATE_DROPOWN_TRIGGER("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(3) input"),
		FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER(".q-superdate-menu"),
		SCAN_DATE_DROPOWN_CONTAINER_TODAY(".q-superdate-menu .x-menu-list .x-box-item li:nth-child(1)"),
		SCAN_DATE_DROPOWN_CONTAINER_LAST_WEEK(".q-superdate-menu .x-menu-list .x-box-item li:nth-child(3)"),
		SCAN_DATE_DROPOWN_CONTAINER_LAST_MONTH(".q-superdate-menu .x-menu-list .x-box-item li:nth-child(4)"),

		SCAN_DATE_DROPOWN_CONTAINER_SPECIFIC_DATE(".q-superdate-menu .x-menu-list .x-box-item li:nth-child(7)"),
		SCAN_DATE_DROPOWN_CONTAINER_ALL_DATES_BEFORE(".q-superdate-menu .x-menu-list .x-box-item li:nth-child(9)"),
		SCAN_DATE_DROPOWN_CONTAINER_ALL_DATES_AFTER(".q-superdate-menu .x-menu-list .x-box-item li:nth-child(11)"),
		SCAN_DATE_DROPOWN_CONTAINER_DATE_RANGE(".q-superdate-menu .x-menu-list .x-box-item li:nth-child(13)"),
		TRI_DATE_PICKER_CONTAINER(".q-superdate-menu .tridate-picker"),

		FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(4) div.x-hide-label input"),
		FILTER_EXPANDED_SITE_TYPE_WAS_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(4) div.x-hide-label:last-of-type input"),
		FILTER_EXPANDED_SHOW_DEACTIVATED_SITES_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(5) .x-form-checkbox"),

		FILTER_EXPANDED_HIGH_SEVERITY_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) div.x-hide-label:first-of-type input"),
		FILTER_EXPANDED_MEDUIUM_SEVERITY_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(2) input"),
		FILTER_EXPANDED_LOW_SEVERITY_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(3) input"),
		FILTER_EXPANDED_SAFE_SEVERITY_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(4) input"),

		FILTER_EXPANDED_SUBMITTED_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(1) input"),
		FILTER_EXPANDED_RUNNING_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(2) input"),
		FILTER_EXPANDED_FINISHED_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(3) input"),
		FILTER_EXPANDED_CANCELED_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(4) input"),
		FILTER_EXPANDED_ERROR_CHECKBOX("#scan-history:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(5) input"),
		FILTER_EXPANDED_HOST_NOT_ALIVE("#scan-history:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(6) input"),

		// Scan List schedule scans
		SCAN_DETECTIONS_BACK_TO_SCAN_LIST("#scan-history:not(.x-hide-display) .navigation-breadcrumbs .link"),
		SCAN_DETECTIONS_SEVERITY_DROP_DOWN_TRIGGER("#scan-history:not(.x-hide-display) .q-datalist td:nth-child(6).x-toolbar-cell input"),
		SCAN_DETECTIONS_SEVERITY_ALL(".x-combo-list-inner>div:nth-child(1)"),
		SCAN_DETECTIONS_SEVERITY_HIGH(".x-combo-list-inner>div:nth-child(2)"),
		SCAN_DETECTIONS_SEVERITY_MEDIUM(".x-combo-list-inner>div:nth-child(3)"),
		SCAN_DETECTIONS_SEVERITY_LOW(".x-combo-list-inner>div:nth-child(4)"),
		SCAN_DETECTIONS_SEVERITY_INFO(".x-combo-list-inner>div:nth-child(5)"),
		SCAN_DETECTIONS_SEVERITY_SAFE(".x-combo-list-inner>div:nth-child(6)");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public ScanListTab() throws ElementNotFoundException {
		
		waitForPageUnMasking();
		if (!Utility.isElementPresent(PageElements.SCAN_LIST_TAB_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Scans>Scan List page");
		}
	}

	public ScanListTab waitForPageMasking() {
		try {
			log.info("Waiting for page to mask");
			Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return this;
	}

	private ScanListTab waitForPageUnMasking() {
		try {
			log.info("Waiting for page to unmask");
			Utility.waitForElementPresent(PageElements.PAGE_LOADING_NOT_MASKED_VERIFY);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return this;

	}

	public ScanListTab clickNewScan() {
		Utility.click(PageElements.NEW_SCAN_DOWN_BTN);
		return this;
	}

	public NewScanEntireSiteDialog selectNewScanEntireSite() throws ElementNotFoundException {
		//clickNewScan();
		Utility.moveToElementAndClick(PageElements.NEW_SCAN_ENTIRE_SITE);
		return new NewScanEntireSiteDialog();
	}

	public NewScanSinglePage selectNewScanSinglePage() throws ElementNotFoundException {
		//clickNewScan();
		Utility.moveToElementAndClick(PageElements.NEW_SCAN_SINGLE_PAGE);
		return new NewScanSinglePage();
	}

	// TODO
	public ScanListTab selectAllScansCheckBox() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.ALL_SCANS_CHECKBOX);
		Utility.selectCheckBox(PageElements.ALL_SCANS_CHECKBOX);
		return this;
	}

	public ScanListTab selectSingleScanCheckBox(String scanName) {
		nameOfScan = scanName;
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		Utility.selectCheckBoxOfSingleRecord(PageElements.EACH_SCAN_TITLE, PageElements.EACH_SCAN_CHECKBOX, superElement, scanName);

		return this;
	}

	public ScanListTab clickQuickActionsDropDown(String scanName) throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_BTN);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		Utility.selectQuickActionsOfSingleRecord(PageElements.EACH_SCAN_TITLE, PageElements.QUICK_ACTIONS_DOWN_BTN, superElement, scanName);

		return this;
	}

	public ScanReportTab selectQuickActionsViewReport(String scanName) throws ElementNotFoundException {
		clickQuickActionsDropDown(scanName);
		if (getStatusTextOfScan(scanName).equalsIgnoreCase("finished")) {
			Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW_REPORT_ENABLED);
		} else if (!getStatusTextOfScan(scanName).equalsIgnoreCase("finished") || Utility.isElementPresent(PageElements.QUICK_ACTIONS_DOWN_VIEW_REPORT_DISABLED)) {
			throw new ElementNotVisibleException("Quick Actions View Report is disabled");
		}
		return new ScanReportTab();
	}

	public ScanListTab selectQuickActionsView(String scanName) throws ElementNotFoundException {
		clickQuickActionsDropDown(scanName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW);
		return this;
	}

	public ScanListTab selectQuickActionsCancelScan(String scanName) throws ElementNotFoundException {
		clickQuickActionsDropDown(scanName);

		if (getStatusTextOfScan(scanName).equalsIgnoreCase("running")) {
			Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_CANCEL_SCAN_ENABLED);
			Utility.click(PageElements.QUICK_ACTIONS_DOWN_CANCEL_SCAN_DISABLED);
		} else if (!getStatusTextOfScan(scanName).equalsIgnoreCase("running") || Utility.isElementPresent(PageElements.QUICK_ACTIONS_DOWN_CANCEL_SCAN_DISABLED)) {
			throw new ElementNotVisibleException("Quick Actions Cancel Scan is disabled and Scan status");

		}
		return new ScanListTab();
	}

	public ScanListTab clickCancelScanDialogueClose() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.CANCEL_SCAN_DIALOGE_CLOSE_CROSS_BTN);
		Utility.click(PageElements.CANCEL_SCAN_DIALOGE_CLOSE_CROSS_BTN);
		return this;
	}

	public ScanListTab clickCancelScanDialogueCancelButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.CANCEL_SCAN_DIALOGE_CANCEL_BTN);
		Utility.click(PageElements.CANCEL_SCAN_DIALOGE_CANCEL_BTN);
		return this;
	}

	public ScanListTab clickCancelScanDialogueConfirmButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.CANCEL_SCAN_DIALOGE_CONFIRM_BTN);
		Utility.click(PageElements.CANCEL_SCAN_DIALOGE_CONFIRM_BTN);
		return this;
	}

	public TargetPageStep selectQuickActionsScanAgain(String scanName) throws ElementNotFoundException {
		clickQuickActionsDropDown(scanName);
		Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_SCAN_AGAIN);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_SCAN_AGAIN);
		return new TargetPageStep();
	}

	public ScanListTab clickActionsDropDown() {

		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_BTN)) {
			/*
			 * Utility.showQuickAction(PAGE_CONSTANTS_STARTS_WITH +
			 * "Actions_Button_DropDownArrow_Navigation", IdentifiedBy.CSS);
			 */
			Utility.click(PageElements.ACTIONS_DOWN_BTN);

		} else {
			throw new IllegalStateException("Actions button is disabled");
		}
		return this;
	}

	public ScanListTab selectActionsViewReport() throws ElementNotFoundException {
		clickActionsDropDown();

		if (getStatusTextOfScan(nameOfScan).equalsIgnoreCase("finished")) {

			Utility.moveToElementAndClick(PageElements.ACTIONS_DOWN_CANCEL_SCAN_ENABLED);
		} else if (!getStatusTextOfScan(nameOfScan).equalsIgnoreCase("finished")) {
			throw new ElementNotVisibleException("Actions>view Report button is disabled");
		}
		return this;
	}

	public ScanListTab selectActionsView() {
		clickActionsDropDown();

		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_VIEW)) {
			Utility.moveToElementAndClick(PageElements.ACTIONS_DOWN_VIEW);

		} else {

			throw new IllegalStateException("Actions>view button is disabled");
		}
		return this;
	}

	public ScanListTab selectActionsCancelScan() throws ElementNotFoundException {
		clickActionsDropDown();

		if (getStatusTextOfScan(nameOfScan).equalsIgnoreCase("running")) {
			Utility.waitForElementPresent(PageElements.ACTIONS_DOWN_CANCEL_SCAN_ENABLED);
			Utility.moveToElementAndClick(PageElements.ACTIONS_DOWN_CANCEL_SCAN_DISABLED);
		}

		else if (!getStatusTextOfScan(nameOfScan).equalsIgnoreCase("running")) {
			throw new ElementNotVisibleException("Cancel scan is disabled");
		}

		return this;
	}

	public ScanListTab selectActionsScanAgian() {
		clickActionsDropDown();

		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_SCAN_AGAIN)) {
			Utility.moveToElementAndClick(PageElements.ACTIONS_DOWN_SCAN_AGAIN);

		} else {

			throw new IllegalStateException("Actions>Scan Again button is disabled");
		}
		return this;
	}

	public ScanListTab refreshScanListPage() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.REFRESH_PAGE_BTN);
		log.info("clicking on refresh button");
		Utility.click(PageElements.REFRESH_PAGE_BTN);
		
		waitForPageMasking();
		waitForPageUnMasking();

		return this;
	}

	public ScanListTab clickFilterDropDown() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.FILTER_SETTINGS_DROPDOWN);
		Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
		return this;
	}

	public ScanListTab selectFilterDownload() throws ElementNotFoundException {
		clickFilterDropDown();
		Utility.click(PageElements.FILTER_SETTINGS_DOWNLOAD);
		return this;
	}

	public ScanListTab selectFilterSortBy() throws ElementNotFoundException {
		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);
		return this;
	}

	public ScanListTab selectFilterSortByScanTitle() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.moveToElementAndClick(PageElements.SORT_BY_SCAN_TITLE);
		waitForPageMasking();
		waitForPageUnMasking();
		;
		return this;
	}

	public ScanListTab selectFilterSortByScanDate() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_SCAN_DATE);
		Utility.moveToElementAndClick(PageElements.SORT_BY_SCAN_DATE);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab selectFilterSortByScannedPages() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_SCANNED_PAGES);
		Utility.moveToElementAndClick(PageElements.SORT_BY_SCANNED_PAGES);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab selectFilterSortByStatus() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_STATUS);
		Utility.moveToElementAndClick(PageElements.SORT_BY_STATUS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab selectFilterRowsShown() throws ElementNotFoundException {
		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);

		return this;
	}

	public ScanListTab selectFilterRowsShown20() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab selectFilterRowsShown50() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab selectFilterRowsShown100() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab selectFilterRowsShown200() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab SortScanTitleFromHeader() {
		Utility.click(PageElements.LIST_HEADER_SCAN_TITLE);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab SortScanDateFromHeader()

	{
		Utility.click(PageElements.LIST_HEADER_SCAN_DATE);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab SortScannedPagesFromHeader() {
		Utility.click(PageElements.LIST_HEADER_SCANNED_PAGES);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab SortStatusFromHeader() {
		Utility.click(PageElements.LIST_HEADER_STATUS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab SortSeverityFromHeader() {
		Utility.click(PageElements.LIST_HEADER_SEVERITY);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab leftPagingComboArrowButton() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_LEFT_BTN);
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_LEFT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_LEFT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();

		} else {
			throw new IllegalStateException("Left button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public ScanListTab clickrightPagingComboArrowButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN);
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public ScanListTab clickPagingComboDropDown() {
		Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		return this;
	}

	public ScanListTab selectPagingComboRange(int start, int end) {

		clickPagingComboDropDown();
		WebElement superElelemnt = Utility.getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);

		Utility.selectFromCombo(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS, superElelemnt, start + " - " + end + " of " + end);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab clickLeftPanelScanssDataFilter(String scanName) {
		WebElement superElement = Utility.getElement(PageElements.LEFT_PANEL_FILTER_CONTAINER);

		Utility.selectFromCombo(PageElements.LEFT_PANEL_FILTER_SCAN_TITLE, superElement, scanName);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ScanListTab selectRowsShownEqualToLeftPanelScansPerformed(String scan) throws ElementNotFoundException {
		WebElement superElement = Utility.getElement(PageElements.LEFT_PANEL_FILTER_CONTAINER);
		String scannsFound = Utility.selectLeftPanelRecordFilterGetText(PageElements.LEFT_PANEL_FILTER_SCAN_TITLE, PageElements.LEFT_PANEL_FILTER_SCANS_PERFORMED, superElement, scan);
		String[] splitbyBrackets = scannsFound.split("\\W");
		int numberOfScansPerformed = Integer.parseInt(splitbyBrackets[3]);

		if (numberOfScansPerformed <= 20) {
			selectFilterRowsShown20();

		} else if (numberOfScansPerformed > 20 && numberOfScansPerformed <= 50) {
			selectFilterRowsShown50();
		} else if (numberOfScansPerformed > 50 && numberOfScansPerformed <= 100) {
			selectFilterRowsShown100();
		} else if (numberOfScansPerformed > 100 && numberOfScansPerformed <= 200) {
			selectFilterRowsShown200();
		}

		return this;
	}

	public void numberOfRows() throws ElementNotFoundException {
		clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);
		String pageRange = Utility.getTextOfPageObject(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);

		String[] splitRange = pageRange.split("\\W");
		totalRows = Integer.parseInt(splitRange[5]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
	}

	public int getTotalRows() throws ElementNotFoundException {

		numberOfRows();
		return totalRows;
	}

	public int getRowInCurrentPage() throws ElementNotFoundException {
		numberOfRows();
		return rowsInCurrentPage;

	}

	public void selectRows() throws ElementNotFoundException {

		clickPagingComboDropDown();
		if (getTotalRows() < 0 && getTotalRows() >= 50) {

		} else if (getTotalRows() > 20 && getTotalRows() <= 50) {
			selectFilterRowsShown50();
		}

		else if (getTotalRows() > 50 && getTotalRows() <= 100) {
			selectFilterRowsShown100();
		}

		else if (getTotalRows() > 100 && getTotalRows() <= 200) {
			selectFilterRowsShown200();
		}

		else if (getTotalRows() > 200) {
			selectFilterRowsShown200();
		}

	}

	public String getScanDateTextOfScan(String scanName) throws ElementNotFoundException {
		String dateOfScan = "";

		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_SCAN_DATE);
		dateOfScan = Utility.getTextOfRecordColumn(PageElements.EACH_SCAN_TITLE, PageElements.EACH_SCAN_DATE, superElement, scanName);

		return dateOfScan;

	}

	public String getScannedPagesTextOfScan(String scanName) throws ElementNotFoundException {
		String numberOfScannedPagesOfScan = "";

		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_SCAN_TITLE);
		numberOfScannedPagesOfScan = Utility.getTextOfRecordColumn(PageElements.EACH_SCAN_TITLE, PageElements.EACH_SCANNED_PAGES, superElement, scanName);

		return numberOfScannedPagesOfScan;
	}

	public String getStatusTextOfScan(String scanName) throws ElementNotFoundException {
		String statusOfScan = "";

		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);

		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_SCAN_TITLE);
		statusOfScan = Utility.getTextOfRecordColumn(PageElements.EACH_SCAN_TITLE, PageElements.EACH_SCAN_STATUS, superElement, scanName);

		return statusOfScan;
	}

	public boolean isScanLaunched(String scanName) throws ElementNotFoundException {
		boolean isScanLaunched = false;
		if (getStatusTextOfScan(scanName).equalsIgnoreCase("running") || getScanDateTextOfScan(scanName).equalsIgnoreCase("submitted")) {
			isScanLaunched = true;
		} else {
			isScanLaunched = false;
		}

		return isScanLaunched;
	}

	// TODO - Severity is an IMAGE
	public String getSeverityTextOfScan(String scanName) throws ElementNotFoundException {
		String severityOfScan = "";

		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_SCAN_TITLE);
		severityOfScan = Utility.getTextOfRecordColumn(PageElements.EACH_SCAN_TITLE, PageElements.EACH_SCAN_SEVERITY, superElement, scanName);
		if (severityOfScan.isEmpty()) {
			clickrightPagingComboArrowButton();
			getScanDateTextOfScan(scanName);
			if (!severityOfScan.isEmpty()) {
				return severityOfScan;
			} else if (rowsInCurrentPage == totalRows) {
				return severityOfScan;
			}
		}
		return severityOfScan;
	}

	public List<String> getAllScansTitleText() throws ElementNotFoundException {
		// selectRows();

		List<WebElement> scansTitlesWebElement = new ArrayList<WebElement>();
		List<String> allScansTitles = new ArrayList<String>();
		waitForPageUnMasking();
		try {
			Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
			WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

			int totalRowsInDL = getTotalRows();

			if (totalRowsInDL > 20) {
				// scansTitlesWebElement =
				// Utility.getRecordWebEements(PageElements.EACH_SCAN_TITLE,
				// superElement);
				int pagination = 0;
				while (pagination <= (totalRowsInDL / 20)) {
					scansTitlesWebElement = Utility.getRecordWebEements(PageElements.EACH_SCAN_TITLE, superElement);
					for (int scanTitleRow = 0; scanTitleRow < scansTitlesWebElement.size(); scanTitleRow++) {
						allScansTitles.add(scansTitlesWebElement.get(scanTitleRow).getText());
					}
					if (pagination != (totalRowsInDL / 20)) {
						clickrightPagingComboArrowButton();
					}
					pagination++;
				}

			} else if (totalRowsInDL <= 20) {
				scansTitlesWebElement = Utility.getRecordWebEements(PageElements.EACH_SCAN_TITLE, superElement);
				for (int scanTitleRow = 0; scanTitleRow < scansTitlesWebElement.size(); scanTitleRow++) {
					allScansTitles.add(scansTitlesWebElement.get(scanTitleRow).getText());
				}

			}

		} catch (ElementNotFoundException e) {
			// TODO Auto-generated catch block
			if (Utility.isElementPresent(PageElements.EMPTY_REPORT_LIST)) {
				log.error("There are no reports. DL is empty");
				org.testng.Assert.fail("Test case failed as there are no reports in report data list");
			} else {
				e.logException("Exception while getting all the scan title text ");
			}
		}
		return allScansTitles;

	}

	public StringBuffer getAllScannedURLText() throws ElementNotFoundException {
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		List<WebElement> scansDateWebElements = Utility.getRecordWebEements(PageElements.EACH_SCAN_URL, superElement);
		StringBuffer allscansDates = new StringBuffer();
		numberOfRows();
		if (totalRows > 20) {
			for (int scanDateRow = 0; scanDateRow < scansDateWebElements.size(); scanDateRow++) {
				allscansDates.append(scansDateWebElements.get(scanDateRow).getText() + "\n");
			}
		}
		return allscansDates;
	}

	public StringBuffer getAllScansDateText() throws ElementNotFoundException {
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		List<WebElement> scansDateWebElements = Utility.getRecordWebEements(PageElements.EACH_SCAN_DATE, superElement);
		StringBuffer allscansDates = new StringBuffer();
		for (int scanDateRow = 0; scanDateRow < scansDateWebElements.size(); scanDateRow++) {
			allscansDates.append(scansDateWebElements.get(scanDateRow).getText() + "\n");
		}
		return allscansDates;
	}

	public StringBuffer getAllScannedPagesText() throws ElementNotFoundException {
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		List<WebElement> scannedPagesWebElements = Utility.getRecordWebEements(PageElements.SCAN_DATALIST_ALL_ROWS, superElement);
		StringBuffer allscannnedPages = new StringBuffer();
		for (int scannedPagesRow = 0; scannedPagesRow < scannedPagesWebElements.size(); scannedPagesRow++) {
			allscannnedPages.append(scannedPagesWebElements.get(scannedPagesRow).getText() + "\n");
		}
		return allscannnedPages;
	}

	public StringBuffer getAllScansStatusText() throws ElementNotFoundException {
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.SCAN_DATALIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.SCAN_DATALIST_ALL_ROWS);

		List<WebElement> statusWebElements = Utility.getRecordWebEements(PageElements.EACH_SCAN_STATUS, superElement);
		StringBuffer allstatus = new StringBuffer();
		for (int statusRow = 0; statusRow < statusWebElements.size(); statusRow++) {
			allstatus.append(statusWebElements.get(statusRow).getText() + "\n");
		}
		return allstatus;
	}

	// FILTERS EXPANDED NAVIGATION(SHOW FILTERS)
	public ScanListTab clickShowFilters() {
		Utility.click(PageElements.SHOW_FILTER);
		return this;
	}

	public ScanListTab filterByTags(String tagName) throws ElementNotFoundException {

		Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		WebElement superElement = Utility.getElement(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS);

		Utility.selectMultipleValuesDoubleClick(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS, superElement, tagName);

		Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN);

		return this;
	}

	public ScanListTab filterByScanDateDropdown() throws ElementNotFoundException {
		Utility.click(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_TRIGGER);
		return this;
	}

	public ScanListTab filterByTodayScanDate() throws ElementNotFoundException {
		filterByScanDateDropdown();
		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER);
		Utility.click(PageElements.SCAN_DATE_DROPOWN_CONTAINER_TODAY);
		return this;
	}

	public ScanListTab filterByLastWeekScanDate() throws ElementNotFoundException {
		filterByScanDateDropdown();
		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER);
		Utility.click(PageElements.SCAN_DATE_DROPOWN_CONTAINER_LAST_WEEK);
		return this;
	}

	public ScanListTab filterByLastMonthScanDate() throws ElementNotFoundException {
		filterByScanDateDropdown();
		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER);
		Utility.click(PageElements.SCAN_DATE_DROPOWN_CONTAINER_LAST_MONTH);
		return this;
	}

	// TODO
	public ScanListTab filterBySpecificDateScanDate(String date) throws ElementNotFoundException {
		filterByScanDateDropdown();
		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER);
		Utility.click(PageElements.SCAN_DATE_DROPOWN_CONTAINER_SPECIFIC_DATE);
		return this;
	}

	public ScanListTab filterByAllDatesBeforeScanDate() throws ElementNotFoundException {
		filterByScanDateDropdown();
		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER);
		Utility.click(PageElements.SCAN_DATE_DROPOWN_CONTAINER_ALL_DATES_BEFORE);
		return this;
	}

	public ScanListTab filterByAllDatesAfterScanDate() throws ElementNotFoundException {
		filterByScanDateDropdown();
		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER);
		Utility.click(PageElements.SCAN_DATE_DROPOWN_CONTAINER_ALL_DATES_AFTER);
		return this;
	}

	public ScanListTab filterByAllDateRangeScanDate() throws ElementNotFoundException {
		filterByScanDateDropdown();
		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_SCAN_DATE_DROPOWN_CONTAINER);
		Utility.click(PageElements.SCAN_DATE_DROPOWN_CONTAINER_DATE_RANGE);
		return this;
	}

	public ScanListTab filterByScanURL(String scanURL) {
		Utility.typeInEditBox(PageElements.FILTER_EXPANDED_SCAN_URL_TEXT_FIELD, scanURL);
		return this;
	}

	public ScanListTab typeScanTitletoFilter(String scanTitle) {
		Utility.typeInEditBox(PageElements.FILTER_EXPANDED_SCAN_TITLE_TEXT_FIELD, scanTitle);
		return this;
	}

	public ScanListTab filterBySiteTypeCheckbox(String mdsORwas) {
		if (mdsORwas.equalsIgnoreCase("MDS")) {
			Utility.click(PageElements.FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX);
		} else if (mdsORwas.equalsIgnoreCase("WAS")) {
			Utility.click(PageElements.FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX);
		}
		return this;
	}

	public ScanListTab filterBySeverity(String highORmediumORlowORsafe) {
		if (highORmediumORlowORsafe.equalsIgnoreCase("high")) {
			Utility.click(PageElements.FILTER_EXPANDED_HIGH_SEVERITY_CHECKBOX);
		} else if (highORmediumORlowORsafe.equalsIgnoreCase("medium")) {
			Utility.click(PageElements.FILTER_EXPANDED_MEDUIUM_SEVERITY_CHECKBOX);
		} else if (highORmediumORlowORsafe.equalsIgnoreCase("low")) {
			Utility.click(PageElements.FILTER_EXPANDED_LOW_SEVERITY_CHECKBOX);
		} else if (highORmediumORlowORsafe.equalsIgnoreCase("safe")) {
			Utility.click(PageElements.FILTER_EXPANDED_SAFE_SEVERITY_CHECKBOX);
		}
		return this;
	}

	public ScanListTab filterByScanStatus(String statusOfScan) {
		if (statusOfScan.equalsIgnoreCase("submitted")) {
			Utility.click(PageElements.FILTER_EXPANDED_SUBMITTED_CHECKBOX);
		} else if (statusOfScan.equalsIgnoreCase("running")) {
			Utility.click(PageElements.FILTER_EXPANDED_RUNNING_CHECKBOX);
		} else if (statusOfScan.equalsIgnoreCase("finished")) {
			Utility.click(PageElements.FILTER_EXPANDED_FINISHED_CHECKBOX);
		} else if (statusOfScan.equalsIgnoreCase("cancelled")) {
			Utility.click(PageElements.FILTER_EXPANDED_CANCELED_CHECKBOX);
		} else if (statusOfScan.equalsIgnoreCase("error")) {
			Utility.click(PageElements.FILTER_EXPANDED_ERROR_CHECKBOX);
		} else if (statusOfScan.equalsIgnoreCase("host not alive")) {
			Utility.click(PageElements.FILTER_EXPANDED_HOST_NOT_ALIVE);
		}
		return this;
	}

	public ScanListTab clickHideFilters() {
		Utility.click(PageElements.HIDE_FILTER);
		return this;
	}

	public ScanListTab clickClearFilters() {
		Utility.click(PageElements.CLEAR_FILTER);
		return this;
	}
}
