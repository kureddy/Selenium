package com.qualys.selenium.core.pageobject;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.MalwarePage.MalwareLandingPage;
import com.qualys.selenium.mds.pageobject.assets.AssetsPage;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog;
import com.qualys.selenium.mds.pageobject.knowledgebase.KnowledgeBasePage;
import com.qualys.selenium.mds.pageobject.reports.ReportsPage;
import com.qualys.selenium.mds.pageobject.scans.ScansPage;

@Slf4j
public abstract class AbstractFrame extends AbstractDialog {

	public enum PageElements implements IPageElement {

		SELECT_MDS_MODULE_FROM_WELCOME_PAGE(".module.MALWARE_SCANNING"),
		SELECT_MDS_MODULE_FROM_MODULE_DROP_DOWN(
				"//div[contains(@class,'module-menu')]//div[contains(@class,'module-item-list')]//div[contains(@id,'module_item')]//div[text()='Malware Detection Service']",
				IdentifiedBy.XPATH),

		MODULES_FRAME_MENU("#FrameMenu table tr:nth-child(2) button[type=button]"),
		HELP_FRAME_MENU("#FrameMenu table:nth-child(5) tr:nth-child(2) button[type='button']"),
		USER_PROFILE_FRAME_MENU("#FrameMenu table:nth-child(6) tr:nth-child(2) button[type='button']"),

		HELP_ONLINE_HELP("div.x-menu li:nth-child(1)"),
		HELP_CONTRACT_SUPPORT("div.x-menu li:nth-child(2)"),
		HELP_ACCOUNT_INFO("div.x-menu li:nth-child(4)"),
		HELP_TRAINING("div.x-menu li:nth-child(5)"),
		HELP_COMMUNITY("div.x-menu li:nth-child(6)"),
		HELP_ABOUT("div.x-menu li:nth-child(8)"),
		USER_PROFILE_DROPDOWN("Menu.MyProfile"),

		LOG_OUT_LINK_FRAME_MENU("#FrameMenu table:nth-child(7) button");

		String locator;
		IdentifiedBy identifiedBy;

		PageElements(String locator, IdentifiedBy identifiedBy) {
			this.locator = locator;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String locator) {
			this(locator, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.locator;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	// Clicking on drop downs(Module,Help,User)
	// Click on Module dropdown
	public WelcomeHomePage clickmoduleDropdown() throws ElementNotFoundException {
		Utility.click(PageElements.MODULES_FRAME_MENU);
		log.debug("");
		return new WelcomeHomePage();
	}

	// **********************************************************************************************************
	/*
	 * Click on Help dropdown from MDS module Note:MDS module Help has
	 * "Online Help" extra in dropdown which is absent in LandingPage Help
	 * dropdown
	 */
	public MalwarePage clickHelpDropDownFromMDS(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {
		// Click on MDS Module
		selectMDSFromModuleDropdown();
		Utility.getElement(PageElements.HELP_FRAME_MENU).click();
		switch (malwareLandingPage) {
		case DASHBOARD:
			return new DashboardPage();

		case SCANS:
			return new ScansPage();

		case REPORTS:
			return new ReportsPage();

		case ASSETS:
			return new AssetsPage();

		case KNOWLEDGEBASE:
			return new KnowledgeBasePage(MalwareLandingPage.KNOWLEDGEBASE);

		default:
			throw new RuntimeException("Please select the page you are landing on");
			
		}

	}

	// Click on user dropdown(It is same for both landing page and MDS page )
	public WelcomeHomePage clickUserDropDown() throws ElementNotFoundException {
		Utility.getElement(PageElements.USER_PROFILE_FRAME_MENU).click();
		return new WelcomeHomePage();
	}

	// **********************************************************************************************************

	// Click on logout to logout from application
	public LoginPage clicklogout() throws ElementNotFoundException {
		Utility.getElement(PageElements.LOG_OUT_LINK_FRAME_MENU).click();
		return new LoginPage();
	}

	// **********************************************************************************************************

	// Launching MDS application from Modules drop down

	// Click on MDS from Module drop down list
	public MalwarePage selectMDSFromModuleDropdown() throws ElementNotFoundException {
		// Click on Module dropdown
		clickmoduleDropdown();
		// Click on MDS module
		Utility.getElement(PageElements.SELECT_MDS_MODULE_FROM_MODULE_DROP_DOWN).click();
		return new MalwarePage(MalwareLandingPage.DASHBOARD);
	}

	// **********************************************************************************************************

	// Clicking on each element of Help dropdown

	/* Click on OnlineHelp from MDS Help dropdown */
	public void selectOnlineHelpFromMDSHelpDropdown(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {

		// Click on help dropdown
		clickHelpDropDownFromMDS(malwareLandingPage);
		Actions builder = new Actions(Utility.getDriver());
		WebElement ele = Utility.getElement(PageElements.HELP_ONLINE_HELP);
		builder.moveToElement(ele);
		builder.click().build().perform();

	}

	/* Click on Contact Support from MDS Help dropdown */
	public void selectContactSupportFromMDSHelpDropdown(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {

		// Click on help dropdown
		clickHelpDropDownFromMDS(malwareLandingPage);
		Actions builder = new Actions(Utility.getDriver());
		WebElement ele = Utility.getElement(PageElements.HELP_CONTRACT_SUPPORT);
		builder.moveToElement(ele);
		builder.click().build().perform();

	}

	/* Click on AccountInfo from MDS Help dropdown */
	public void selectAccountInfoFromMDSHelpDropdown(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {

		// Click on help dropdown
		clickHelpDropDownFromMDS(malwareLandingPage);
		Actions builder = new Actions(Utility.getDriver());
		WebElement element = Utility.getElement(PageElements.HELP_ACCOUNT_INFO);
		builder.moveToElement(element);
		builder.click().build().perform();

	}

	/* Click on Training from MDS Help dropdown */
	public void selectTrainingFromMDSHelpDropdown(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {

		// Click on help dropdown
		clickHelpDropDownFromMDS(malwareLandingPage);
		Actions builder = new Actions(Utility.getDriver());
		WebElement ele = Utility.getElement(PageElements.HELP_TRAINING);
		builder.moveToElement(ele);
		builder.click().build().perform();

	}

	/* Click on Community from MDS Help dropdown */
	public void selectCommunityFromMDSHelpDropdown(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {

		// Click on help dropdown
		clickHelpDropDownFromMDS(malwareLandingPage);
		Actions builder = new Actions(Utility.getDriver());
		WebElement ele = Utility.getElement(PageElements.HELP_COMMUNITY);
		builder.moveToElement(ele);
		builder.click().build().perform();

	}

	/* Click on About from MDS Help dropdown */
	public void selectAboutFromMDSHelpDropdown(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {

		// Click on help dropdown
		clickHelpDropDownFromMDS(malwareLandingPage);
		Actions builder = new Actions(Utility.getDriver());
		WebElement ele = Utility.getElement(PageElements.HELP_ABOUT);
		builder.moveToElement(ele);
		builder.click().build().perform();

	}

	// **********************************************************************************************************

	// Clicking on UserProfile
	public void selectUserProfileFromUserDropDown() throws ElementNotFoundException {

		clickUserDropDown();
		Actions builder = new Actions(Utility.getDriver());
		WebElement ele = Utility.getElement(PageElements.USER_PROFILE_DROPDOWN);
		builder.moveToElement(ele);
		builder.click().build().perform();
	}

}
