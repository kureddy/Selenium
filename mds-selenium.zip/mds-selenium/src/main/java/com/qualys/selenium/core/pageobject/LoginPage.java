package com.qualys.selenium.core.pageobject;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.PropertyReader;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;

@Slf4j
public class LoginPage {
	
	public enum PageElements implements IPageElement{
    	LOGIN_BUTTON("td:last-child>table>tbody:last-child table table tr:nth-child(2) td:nth-child(2) button[type=button]"),
		USERNAME_TXTFIELD("input[type=text]"),
		PASSWORD_TXTFIELD("input[type=password]");
    	
		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}
		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}
		
		@Override
		public String getLocator() {
			return this.key;
		}
		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}
	
	public LoginPage() throws ElementNotFoundException{
		Utility.waitForElementPresent(PageElements.LOGIN_BUTTON);
		if (!Utility.getCurrentUrl().endsWith("portal-front/")) {
			log.error("Not in the login page");
			throw new RuntimeException("Not on the login page ");			
		}
	}

	public LoginPage enterUserName(String environment) {
		Utility.typeInEditBox(PageElements.USERNAME_TXTFIELD, PropertyReader.getConfigProperty("username_"+environment));
		return this;
	}

	public LoginPage enterPassword(String environment) {
		Utility.typeInEditBox(PageElements.PASSWORD_TXTFIELD, PropertyReader.getConfigProperty("password_"+environment));
		return this;
	}

	public WelcomeHomePage clickLogin() throws ElementNotFoundException {
		Utility.click(PageElements.LOGIN_BUTTON);
		return new WelcomeHomePage();
	}

	public WelcomeHomePage portalLogin(String environment) throws ElementNotFoundException{
		enterUserName(environment).enterPassword(environment).clickLogin();
		return new WelcomeHomePage();
	}
	
}