package com.qualys.selenium.mds.pageobject.dialogs;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;

@Slf4j
public class AbstractDialog {

	public enum DialogCommonElements implements IPageElement {

		CONTINUE_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-dark')]//button[text()='Continue']"),
		CANCEL_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'q-btn-gray-light')]//button[text()='Cancel']"),
		CLOSE_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'q-btn-gray-light')]//button[text()='Close']"),
		CANCEL_BTN_PAGE_SCAN_DIALOGUE("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-footer')]//table[contains(@class,'q-btn-gray-light')]"),
		// SCAN_BTN_PAGE_SCAN_DIALOGUE("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-footer')]//table[contains(@class,'q-btn-blue-dark')]"),
		SCAN_BTN_PAGE_SCAN_DIALOGUE("div[class*=-dialog] div[class*=-dialog-footer] table:not(.x-item-disabled)[class*=-btn-blue-dark]",IdentifiedBy.CSS),
		PREVIOUS_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-dark')]//button[text()='Previous']"),
		PREVIOUS_BTN_REVIEW_AND_CONFIRM("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-light')]//button[text()='Previous']"),
		SAVE_BTN("//div[contains(@class,'send-reports-dialog')]//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-dark')]//button[text()='Save']"),
		SAVE_AS_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-light')]//button[text()='Save As']"),
		FINISH_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-dark')]//button[text()='Finish']"),
		SAVE_AND_SCAN_NOW_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-dark')]//button[text()='Save & Scan Now']"),

		SELECT_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-dark')]//button[text()='Select']"),
		CREATE_BTN("//td[not(contains(@class,'x-hide-display'))]/table[contains(@class,'x-btn q-btn-blue-dark')]//button[text()='Create']");

		String key;
		IdentifiedBy identifiedBy;

		DialogCommonElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		DialogCommonElements(String key) {
			this(key, IdentifiedBy.XPATH);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}

	public AbstractDialog() {
		log.info(Utility.getCurrentUrl());
	}

	public AbstractStep[] steps;
}
