package com.qualys.selenium.mds.pageobject.dialogs.reports.saveReport.summaryReport;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog;
import com.qualys.selenium.mds.pageobject.reports.ReportsPage;
import com.qualys.selenium.mds.pageobject.reports.ScanReportTab;
import com.qualys.selenium.mds.pageobject.reports.SummaryReportTab;


@Slf4j
public class PortableDocFormatPdfSummaryReport extends AbstractDialog {

	public enum PageElements implements IPageElement {

		PORTABLE_DOC_FORMAT_REPORT_DIALOG_VERIFY("div[class*=send-reports-dialog] div[class*=dialog-bwrap]"),

		TAGS_COMBO_DOWN_ARROW_TRIGGER(".send-reports-dialog .tag-combo-box span[class*=form-twin-triggers] img:nth-of-type(2)"),
		TAGS_COMBO_DOWN_CONTAINER("//div[contains(@style,'visibility: visible')]//div[contains(@class,'basic-tag-tree')]//div[contains(@class,'-tree-root-node')]",IdentifiedBy.XPATH),
		TAGS_COMBO_DOWN_CONTAINER_ITEMS(".basic-tag-tree li[class*=tree-node]"),

		REPORT_NAME_TEXT_BOX("div[class*=send-reports-dialog] div[class*=object-panel] div[class*=section-panel-bwrap] input[name=title]"),

		// REPORT_DOWNLOAD_DIALOG("div[class*=combo-list] div[class*=combo-list-inner]"),
		REPORT_DOWNLOAD_PROGRESS_BAR("div[class*=dialog] div[class*=progress-wrap] div[class*=progress-inner]  div[class*=progress-text]"),
		GENERATING_REPORT_DIALOG("div[class*=-dialog] div[class*=-mask-loading]"),
		RUNNING_REPORT_PERCENTAGE(".q-dialog div[class*=-progress-wrap] div[class*=-progress-inner] div[class*=-progress-text] div"),
		// REPORT_DOWNLOAD_DIALOG("//div[not(contains(@class,'send-reports-dialog'))]//div[contains(@class,'dialog-header')]//span[contains(text(),'Report Download')]",
		// IdentifiedBy.XPATH),
		REPORT_DOWNLOAD_DIALOG("//div[contains(@style,'visibility: visible')]//div[contains(@class,'dialog-header')]//span[contains(text(),'Report Download')]", IdentifiedBy.XPATH),
		DIALOG_MASK_WHILE_GENERATING_REPORT("div[class*=el-mask]");
		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public PortableDocFormatPdfSummaryReport() throws ElementNotFoundException {
		if (!Utility.isElementPresent(PageElements.PORTABLE_DOC_FORMAT_REPORT_DIALOG_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Scans>Scan List page");
		}
	}

	public void waitForDialogMask() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.DIALOG_MASK_WHILE_GENERATING_REPORT);
	}

	public ReportsPage handleReportDownloadDialog() throws ElementNotFoundException {
		try {

			waitForDialogMask();
			log.info("Handling report download dialog");
			for (int sec = 0; sec < 60; sec++) {
				System.out.println(sec);
				Utility.waitUntilElementDissAppears(PageElements.GENERATING_REPORT_DIALOG);
				if (Utility.isElementPresent(PageElements.REPORT_DOWNLOAD_DIALOG)) {
					sec = 60;
					log.info("Report Download dialog is available on Screen");
					for (int wait = 0; wait < 60; wait++) {

						//if (!Utility.isElementPresent(PageElements.REPORT_DOWNLOAD_DIALOG)) {
							if(Utility.getTextOfPageObject(PageElements.RUNNING_REPORT_PERCENTAGE).equalsIgnoreCase("Complete (100% done)"))
							{
							wait = 60;
							log.info("Report Download dialog dissappeard on screen");
							if (Utility.isElementPresent(ScanReportTab.PageElements.SCAN_REPORT_TAB_VERIFY)) {
								log.info("Landed on page Scan Report Tab");
								return new ScanReportTab();
							} else {
								throw new ElementNotFoundException(" SCAN_REPORT_TAB_VERIFY not found");
							}
						} else if (wait == 59) {
							wait = 0;
						}
					}
				} else if (sec == 59) {
					System.out.println("in else loop");
					sec = 0;
				}

			}
			return new ScanReportTab();
		} catch (ElementNotFoundException e) {
			e.logException("Exception while handline Scan report");
			return null;
		}
	}

	public PortableDocFormatPdfSummaryReport waitForGeneratingReportDialog() throws ElementNotFoundException {
		try {
			waitForDialogMask();
			Utility.waitForElementPresent(PageElements.GENERATING_REPORT_DIALOG);
		} catch (ElementNotFoundException e) {
			e.logException("Exception while generating report dialog of scan report");
		}

		return this;
	}

	public SummaryReportTab clickSaveBtn() throws ElementNotFoundException {

		Utility.waitForElementPresent(DialogCommonElements.SAVE_BTN);
		log.info("Element is present on screen");
		Utility.click(DialogCommonElements.SAVE_BTN);
		log.info("Clicked on save button");

		handleReportDownloadDialog();
		return new SummaryReportTab();
	}

	public PortableDocFormatPdfSummaryReport addTagsToReport(String selectTag) throws ElementNotFoundException, InterruptedException {

		if (!selectTag.equalsIgnoreCase("none")) {

			try {

				Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_ARROW_TRIGGER);
				Utility.click(PageElements.TAGS_COMBO_DOWN_ARROW_TRIGGER);
				log.info("Clicking on  Element TAGS_COMBO_DOWN_ARROW_TRIGGER");
			} catch (Exception e) {
				log.error("Error while Clicking on TAGS_COMBO_DOWN_ARROW_TRIGGER");
				e.printStackTrace();
			}

			try {

				Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_CONTAINER);

				log.info("Waiting for Element Element TAGS_COMBO_DOWN_CONTAINER");

			} catch (Exception e) {
				log.error("Error while waiting for TAGS_COMBO_DOWN_CONTAINER");
				e.printStackTrace();
			}

			WebElement superElement = Utility.getElement(PageElements.TAGS_COMBO_DOWN_CONTAINER);
			Thread.sleep(100);
			// System.out.println("tags are: " + superElement.getText());
			System.out.println("tags are: " + superElement.getText());
			if (!superElement.getText().equals("")) {
				try {
					Utility.waitForElementPresent(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS);

					log.info("Waiting for Element Element TAGS_COMBO_DOWN_CONTAINER_ITEMS");

				} catch (Exception e) {
					log.error("Error while waiting for TAGS_COMBO_DOWN_CONTAINER_ITEMS");
					e.printStackTrace();
				}
				if (selectTag.contains("-")) {

					String[] splitEachTag = selectTag.split("-");
					for (String eachTag : splitEachTag) {
						System.out.println(eachTag);
						try {
							Utility.selectMultipleValuesDoubleClick(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS, superElement, eachTag);
							log.info("Selecting and double clicking on  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + eachTag);
						} catch (Exception e) {
							log.error("Error while selecting  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + eachTag);
							e.printStackTrace();
						}
					}
				} else {
					try {
						Utility.selectMultipleValuesDoubleClick(PageElements.TAGS_COMBO_DOWN_CONTAINER_ITEMS, superElement, selectTag);
						log.info("Selecting and double clicking on  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + selectTag);
					} catch (Exception e) {
						log.error("Error while selecting  TAGS_COMBO_DOWN_CONTAINER_ITEMS - " + selectTag);
						e.printStackTrace();
					}

				}

				return this;
			} else {
				log.warn("User do not have any tags to select");
				return this;
			}
		} else {
			log.info("selectTag = " + selectTag + " so not selecting any tags");
			return this;
		}
	}

}
