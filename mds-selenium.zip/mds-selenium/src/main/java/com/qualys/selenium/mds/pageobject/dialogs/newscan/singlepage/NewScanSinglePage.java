package com.qualys.selenium.mds.pageobject.dialogs.newscan.singlepage;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog;
import com.qualys.selenium.mds.pageobject.scans.ScanListTab;

@Slf4j
public class NewScanSinglePage extends AbstractDialog {
	public static final String PAGE_CONSTANTS_STARTS_WITH = "MDS_NewScan_SinglePage_";

	public enum PageElements implements IPageElement {

		NEW_SINGLE_SCAN_PAGE_VERIFY(".q-dialog .q-dialog-body"),

		SINGLE_PAGE_URL_TEXT_FIELD("div[class*=-dialog] div[class*=object-panel] div[class*=section-edit-panel] input[name=pageurl]"),
		SINGLE_PAGE_URL_INVALID_ERROR_MESSAGE("div[class*=-dialog] div[class*=object-panel] div[class*=section-edit-panel] div[class*=-form-invalid-msg]"),

		// LABELS
		NEW_SINGLE_SCAN_PAGE_HEADER_DESCRIPTION_LABEL(".q-dialog  .page-info"),
		PAGE_URL_LABEL(".q-dialog  .section-panel-body div"),
		REQUIRED_FIELDS_NOTICE_LABEL(".q-dialog  .notice-required"),

		// help tips
		WINDOW_CLOSE_BUTTON(".q-dialog  .x-close"),
		PAGE_SCAN_DIALOGUE_HEADER_LABEL(".q-dialog  .q-dialog-header-text"),
		TURN_HELP_TIPS_ON_OFF_LABEL(".scan-object-window .q-window-header div.help-on"), // TODO
																							// :
																							// no
																							// such
																							// element
																							// exception
		LAUNCH_HELP_LABEL(".q-dialog  .launch-help"),

		HELP_TIPS_ON(".q-dialog  .help-toggle-on"),
		HELP_TIPS_OFF(".q-dialog  .help-toggle-off");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}

	public NewScanSinglePage() throws ElementNotFoundException {
		
		if (!Utility.isElementPresent(PageElements.NEW_SINGLE_SCAN_PAGE_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Dashboard>New Scan Single page");
		}
	}

	public NewScanSinglePage typePageURL(String singlePageURL) throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.SINGLE_PAGE_URL_TEXT_FIELD);
		Utility.typeInEditBox(PageElements.SINGLE_PAGE_URL_TEXT_FIELD, singlePageURL);
		return this;
	}

	

	public ScanListTab clickScanBtn() throws ElementNotFoundException {
		Utility.waitForElementPresent(DialogCommonElements.SCAN_BTN_PAGE_SCAN_DIALOGUE);
		Utility.click(DialogCommonElements.SCAN_BTN_PAGE_SCAN_DIALOGUE);
		return new ScanListTab();
	}

	public DashboardPage clickCancel() throws ElementNotFoundException {
		Utility.click(DialogCommonElements.CANCEL_BTN_PAGE_SCAN_DIALOGUE);

		return new DashboardPage();
	}

	public NewScanSinglePage verifyNewScanSinglePageStaticText() {
		CustomVerification customVerification = new CustomVerification();

		// customVerification.verifyEquals("Target step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help ");
		// //TODO : no such element exception
		customVerification.verifyEquals("New Scan Single Page LAUNCH_HELP_", Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL), "Launch help");
		customVerification.verifyEquals("New Scan Single Page HELP_TIPS_ON ", Utility.getTextOfPageObject(PageElements.HELP_TIPS_ON), "On");
		customVerification.verifyEquals("New Scan Single Page HELP_TIPS_OFF ", Utility.getTextOfPageObject(PageElements.HELP_TIPS_OFF), "Off");

		customVerification.verifyEquals("New Scan Single Page NEW_SINGLE_SCAN_PAGE_HEADER_DESCRIPTION_", Utility.getTextOfPageObject(PageElements.NEW_SINGLE_SCAN_PAGE_HEADER_DESCRIPTION_LABEL),
				"Scan a single page of a site already in your account. Enter the page you would like to scan below.");
		customVerification.verifyEquals("New Scan Single Page PAGE_URL_", Utility.getTextOfPageObject(PageElements.PAGE_URL_LABEL), "Page URL*");
		customVerification.verifyEquals("New Scan Single Page REQUIRED_FIELDS_NOTICE_", Utility.getTextOfPageObject(PageElements.REQUIRED_FIELDS_NOTICE_LABEL), "(*) REQUIRED FIELDS");

		customVerification.verifyEquals("New Scan Single Page CANCEL_BTN_PAGE_SCAN_DIALOGUE ", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN_PAGE_SCAN_DIALOGUE), "      Cancel\n     ");
		customVerification.verifyEquals("New Scan Single Page SCAN_BTN_PAGE_SCAN_DIALOGUE ", Utility.getTextOfPageObject(DialogCommonElements.SCAN_BTN_PAGE_SCAN_DIALOGUE), "      Scan\n     ");

		return this;

	}
}
