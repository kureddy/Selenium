package com.qualys.selenium.mds.pageobject.reports;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.reports.saveReport.scanReport.CompressedHTMLScanReport;
import com.qualys.selenium.mds.pageobject.dialogs.reports.saveReport.scanReport.EncryptedPortableDocumentPdfScanReport;
import com.qualys.selenium.mds.pageobject.dialogs.reports.saveReport.scanReport.PortableDocFormatPdfScanReport;

@Slf4j
public class ScanReportTab extends ReportsPage {

	public enum PageElements implements IPageElement {
		SCAN_REPORT_TAB_VERIFY("div[id*=report-scan]"),

		SAVE_REPORT_BTN("div:not(.x-hide-display)[id*=report-scan] div[class*=report-header] div[class*=small-editor] td[class*=toolbar-right] table[class*=blue-dark] button[class*=btn-text]"),
		// COMPRESSED_HTML_PAGES("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(1)"),
		COMPRESSED_HTML_PAGES("div:not(.x-hide-offsets)[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(1)"),
		PORTABLE_DOCUMENT_FORMAT("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(2)"),
		ENCRYPTED_PORTABLE_DOCUMENT("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(3)"),
		SCANE_REPORT_TAB_MASK("div[class*=el-mask]"),

		SCAN_REPORT_TITLE_CHANGE_BTN_LINK("div:not(.x-hide-display)[id*=report-scan] div[class*=form-composite] table:nth-of-type(1):not(.x-hide-display)[class*=action] button"),
		SCAN_REPORT_TITLE_SAVE_BTN_LINK("div:not(.x-hide-display)[id*=report-scan] div[class*=form-composite] table:nth-of-type(2):not(.x-hide-display)[class*=action] button"),
		SCAN_REPORT_TITLE_CANCEL_BTN_LINK("div:not(.x-hide-display)[id*=report-scan] div[class*=form-composite] table:nth-of-type(3):not(.x-hide-display)[class*=action] button"),

		SCAN_REPORT_CLOSE(
				"div[id=FrameModuleCardPanel] div:not(x-hide-display)[id=reporting] div[class*=tab-container-header-panel] div[class*=section-tabs-tab-selected] span[title='Scan report']+span[class*='-close']"),

		SCAN_REPORT_TITLE_TEXTBOX("div:not(.x-hide-display)[id*=report-scan] div[class*=report-header-title] input[class*=edit-field]");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public ScanReportTab() throws ElementNotFoundException {
		
		waitForPageToUnMask();
		if(!Utility.isElementPresent(PageElements.SCAN_REPORT_TAB_VERIFY))
		{
		log.info("Currently at url : {}", Utility.getCurrentUrl());  
		throw new IllegalStateException("This is not the MDS > Scan Respot Tab page");
		}
		
	}

	public ScanReportTab waitForPageToMask() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.SCANE_REPORT_TAB_MASK);
		return this;
	}

	public ScanReportTab waitForPageToUnMask() {
		Utility.waitUntilElementDissAppears(PageElements.SCANE_REPORT_TAB_MASK);
		return this;
	}

	

	public ScanReportTab clickOnSaveReportDropDownBtn() {
		Utility.click(PageElements.SAVE_REPORT_BTN);
		return this;
	}

	public CompressedHTMLScanReport selectCompressedHTML() throws ElementNotFoundException {
		clickOnSaveReportDropDownBtn();
		Utility.click(PageElements.COMPRESSED_HTML_PAGES);
		return new CompressedHTMLScanReport();
	}

	public PortableDocFormatPdfScanReport selectPortableDocFormatPDF() throws ElementNotFoundException {
		clickOnSaveReportDropDownBtn();
		Utility.click(PageElements.PORTABLE_DOCUMENT_FORMAT);
		return new PortableDocFormatPdfScanReport();
	}

	public EncryptedPortableDocumentPdfScanReport selectEncryptedDocFormatPDF() throws ElementNotFoundException {
		clickOnSaveReportDropDownBtn();
		Utility.click(PageElements.ENCRYPTED_PORTABLE_DOCUMENT);
		return new EncryptedPortableDocumentPdfScanReport();
	}

	public ScanReportTab clickChangeBtnLink() {
		Utility.click(PageElements.SCAN_REPORT_TITLE_CHANGE_BTN_LINK);
		return this;
	}

	public ScanReportTab clickSaveBtnLink() {
		Utility.click(PageElements.SCAN_REPORT_TITLE_SAVE_BTN_LINK);
		return this;
	}

	public ScanReportTab clickCancelBtnLink() {
		Utility.click(PageElements.SCAN_REPORT_TITLE_CANCEL_BTN_LINK);
		return this;
	}

	public ScanReportTab editAndSaveScanReportTitle(String scanTitle) {
		clickChangeBtnLink();
		log.info("Clicked on CHANGE link to rename scan title");
		Utility.typeInEditBox(PageElements.SCAN_REPORT_TITLE_TEXTBOX, scanTitle);
		log.info("Renamed scan title to : " + scanTitle);
		clickSaveBtnLink();
		log.info("Clicked on save button.Scan title name has changed");
		return this;
	}

	public ReportListTab closeScanReport() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.SCAN_REPORT_TAB_VERIFY);
		Utility.click(PageElements.SCAN_REPORT_CLOSE);

		return new ReportListTab();
	}
}
