package com.qualys.selenium.mds.dataobject;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(of={"title","siteName","maximumPages","intensity"})
public class NewScanData {
	public String title;
	public String siteName;
	public int maximumPages;
	public String intensity;
}
