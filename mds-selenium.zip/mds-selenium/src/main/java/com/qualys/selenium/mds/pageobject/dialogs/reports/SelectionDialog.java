package com.qualys.selenium.mds.pageobject.dialogs.reports;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;

@Slf4j
public class SelectionDialog extends NewReport {
	public enum PageElements implements IPageElement {

		SELECTION_DIALOG_VERIFY("div[class*=selection-dialog]"),

		FILTER_SETTINGS_DROPDOWN("div[class*=q-dialog] tr[class*=toolbar-right-row] td:nth-of-type(5) button[class*=icon-pager]"),
		FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]", IdentifiedBy.XPATH),
		SORT_BY_URL("li:nth-of-type(1)[class*=menu-list-item] a[class*=-menu-group-item] span[class*=menu-item-text]"),
		SORT_BY_SITE_NAME("li:nth-of-type(2)[class*=menu-list-item] a[class*=-menu-group-item] span[class*=menu-item-text]"),

		FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'view_menu') and not(contains(@class,' hide-offsets'))]//span[contains(text(),'Rows Shown')]"),
		ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

		PAGING_COMBO_LEFT_BTN("div[class*=q-dialog] table[class*=toolbar-right] .first:not(.x-item-disabled) button[class*=page-prev]"),
		PAGING_COMBO_RIGHT_BTN("div[class*=q-dialog] table[class*=toolbar-right] .last:not(.x-item-disabled) button[class*=page-next]"),
		PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("div[class*=q-dialog] div[class*=datalist-tbar] td[class*=toolbar-right] input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER(".x-combo-list"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS(".x-combo-list-item"),

		ITEMS_ALL_ROWS("div[class*=selection-dialog] div[class*=scroller]"),

		EACH_URL_COLUMN_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-first]"),
		EACH_SITE_COLUMN_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-last]"),

		EACH_SITE_URL_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-first]"),
		EACH_SITE_NAME_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-last]");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	

	public SelectionDialog() throws ElementNotFoundException {
		
		//this.callingPage = callingPage;
		if (!Utility.isElementPresent(PageElements.SELECTION_DIALOG_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Scans>Scan List page");
		}
	}

}
