package com.qualys.selenium.mds.pageobject.knowledgebase;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;

@Slf4j
public class KnowledgeBasePage extends MalwarePage {

	public enum PageElements implements IPageElement {

		KB_PAGE_VERIFY("#malware-kb:not(.x-hide-display)"),
		KB_TAB("#malware-kb .section-tabs-wrap div[ref=datalist-kb]");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public KnowledgeBasePage(MalwareLandingPage malwareLandingPage) throws ElementNotFoundException {
		super(malwareLandingPage);
		if (!Utility.isElementPresent(PageElements.KB_PAGE_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the MDS>KnowledgeBasePag page");
		}
	}

	public KnowledgeBaseTab clickKBTab() throws ElementNotFoundException {
		Utility.click(PageElements.KB_TAB);
		return new KnowledgeBaseTab();
	}
}
