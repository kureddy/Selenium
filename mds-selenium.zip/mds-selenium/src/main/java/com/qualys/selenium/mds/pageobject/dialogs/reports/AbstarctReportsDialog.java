package com.qualys.selenium.mds.pageobject.dialogs.reports;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;

@Slf4j
public class AbstarctReportsDialog {
	public enum reportDialogElements implements IPageElement {
		
		
		SAVE_REPORT_BTN("div[id*=report-asset] div[class*=report-header] div[class*=small-editor] td[class*=toolbar-right] table[class*=blue-dark] button[class*=btn-text]"),
		COMPRESSED_HTML_PAGES("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(1)"),
		PORTABLE_DOCUMENT_FORMAT("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(2)"),
		ENCRYPTED_PORTABLE_DOCUMENT("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(3)");

		
		String key;
		IdentifiedBy identifiedBy;

		reportDialogElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		reportDialogElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}
	
	public AbstarctReportsDialog() {
		log.info(Utility.getCurrentUrl());
	}

	
}
