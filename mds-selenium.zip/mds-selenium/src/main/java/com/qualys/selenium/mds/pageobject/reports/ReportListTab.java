package com.qualys.selenium.mds.pageobject.reports;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite.NewScanEntireSiteDialog;
import com.qualys.selenium.mds.pageobject.dialogs.reports.NewReport;

@Slf4j
public class ReportListTab extends ReportsPage {
	int totalRows;
	int rowsInCurrentPage;

	public enum PageElements implements IPageElement {
		REPORT_LIST_TAB_VERIFY("#reporting:not(.x-hide-display)"),
		PAGE_LOADING_MASKED_VERIFY("#reporting:not(.x-hide-display) #datalist-reports div[class*=datalist-container] div[class*=multi-selection] div[class*=frame-mask]"),
		PAGE_LOADING_NOT_MASKED_VERIFY("#reporting:not(.x-hide-display) .q-datalist:not(.x-masked) .q-datalist-bwrap:not(.x-masked)"),

		// NEW_REPORT_BTN("//div[@id='datalist-sites']//td//button[contains(text(),'New Schedule')]"),
		NEW_REPORT_BTN("//div[@id='reporting']//div[@id='datalist-reports']//div[contains(@class,'datalist-container')]//button[contains(text(),'New Report')]", IdentifiedBy.XPATH),

		REFRESH_PAGE_BTN("#reporting:not(.x-hide-display) .x-small-editor .x-toolbar-right .x-tbar-loading"),
		// MDS_AssetsPage_SitesTab_AfterRefreshPage_WaitFor=.content-panel

		FILTER_SETTINGS_DROPDOWN("#reporting:not(.x-hide-display) .x-small-editor .x-toolbar-right .dlist_view_btn"),
		FILTER_SETTINGS_DOWNLOAD(".q_view_menu .x-menu-list li:nth-child(1)"),
		FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]", IdentifiedBy.XPATH),
		SORT_BY_NAME("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		SORT_BY_FORMAT("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		SORT_BY_TYPE("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		SORT_BY_STATUS("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),
		SORT_BY_GENERATION_DATE("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(5)"),
		FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Rows Shown')]", IdentifiedBy.XPATH),
		ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

		PAGING_COMBO_LEFT_BTN("#reporting:not(.x-hide-display) div[class*=datalist-tbar] div[class*=small-editor] td[class*=toolbar-right] .first:not(.x-item-disabled) button[class*=page-prev]"),
		PAGING_COMBO_RIGHT_BTN("#reporting:not(.x-hide-display) div[class*=datalist-tbar] div[class*=small-editor] td[class*=toolbar-right] .last:not(.x-item-disabled) button[class*=page-next]"),
		PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("#reporting:not(.x-hide-display) div[class*=datalist-tbar] td[class*=toolbar-right] input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER("div[class*=combo-list]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS("div[class*=combo-list-item]"),

		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM("div[class*=combo-list] div[class*=combo-list-inner] div:first-child[class*=combo-selected]"),

		ALL_REPORT_CHECKBOX("#reporting:not(.x-hide-display) .datalist-container .q-datalist-body .x-grid3-header table .x-grid3-hd-checker"),

		REPORT_DATA_LIST_ALL_ROWS("#reporting .datalist-container div[class*=grid-panel] div[class*=datalist-body] div[class*=scroller]"), // SUPER
																																			// ELEMENT
		EACH_REPORT_TITLE("#reporting #datalist-reports div:nth-child(1)[class*=col-reportTitle]"), // SUB
																									// Element
		EMPTY_REPORT_LIST("#reporting #datalist-reports div[class*=grid-empty]"),
		EACH_REPORT_FORMAT("//div[contains(@class,'viewport')]//div[2]//td[contains(@class,'reportType')]/div[contains(@class,'col-reportType')]", IdentifiedBy.XPATH), // SUB
																																										// ELEMENT
		EACH_REPORT_TYPE("//div[contains(@class,'viewport')]//div[2]//td[contains(@class,'reportDefType')]/div[contains(@class,'col-reportDefType')]", IdentifiedBy.XPATH), // SUB
																																											// ELEMENT
		EACH_REPORT_STATUS("//div[contains(@class,'viewport')]//div[2]//td[contains(@class,'reportStatus')]/div[contains(@class,'col-reportStatus')]", IdentifiedBy.XPATH), // SUB
																																											// ELEMENT
		EACH_REPORT_GENERATION_DATE("//div[contains(@class,'viewport')]//div[2]//td[contains(@class,'creationDate')]/div[contains(@class,'col-creationDate')]", IdentifiedBy.XPATH), // SUB
																																														// ELEMENT

		EACH_REPORT_CHECKBOX("#reporting:not(.x-hide-display) .datalist-container .x-grid3-scroller .x-grid3-td-checker.x-grid3-cell-first"),

		ACTIONS_DOWN_BTN("#reporting:not(.x-hide-display) .actionBtn:not(.x-item-disabled)"),
		ACTIONS_DOWN_VIEW("//li[1][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_DOWNLOAD("//li[2][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Edit')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_SEND_REPORT_ENABLED("//li[3][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Add Tags')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_SEND_REPORT_DISABLED("//li[3][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Add Tags')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_ADD_TAGS("//li[5][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Scan')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_DELETE("//li[5][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Scan')]", IdentifiedBy.XPATH),

		QUICK_ACTIONS_DOWN_BTN("#reporting:not(.x-hide-display) .q-quick-menu-column"),
		QUICK_ACTIONS_DOWN_QUICK_ACTIONS_LABEL("li.x-menu-list-item:not(.x-item-disabled):nth-child(1) "),
		QUICK_ACTIONS_DOWN_VIEW("li.x-menu-list-item:not(.x-item-disabled):nth-child(2) "),
		QUICK_ACTIONS_DOWN_DOWNLOAD("li.x-menu-list-item:not(.x-item-disabled):nth-child(3) "),
		QUICK_ACTIONS_DOWN_SEND_REPORT_ENABLED("li.x-menu-list-item:not(.x-item-disabled):nth-child(4)"),
		QUICK_ACTIONS_DOWN_SEND_REPORT_("li.x-menu-list-item:not(.x-item-disabled):nth-child(4)"),
		QUICK_ACTIONS_DOWN_ADD_TAGS("li.x-menu-list-item:not(.x-item-disabled):nth-child(6)"),
		QUICK_ACTIONS_DOWN_DELETE("li.x-menu-list-item:not(.x-item-disabled):nth-child(8)"),

		// PENDING TO TEST NAVIGATION
		SHOW_FILTER("#reporting:not(.x-hide-display) .filter-summary-panel .filter-buttons"),
		CLEAR_FILTER("#reporting:not(.x-hide-display) .filter-summary-panel .filter-buttons .clear-filters-link"),
		HIDE_FILTER("#reporting:not(.x-hide-display) .filter-summary-panel .filter-buttons .toggle-filter-link"),
		FILTER_APPLIED_NUMBER("#reporting:not(.x-hide-display) .filter-summary-panel .filter-count span b"),

		// FILTER_EXPANDED_SEARCH_TEXT_FIELD("#reporting:not(.x-hide-display) .filter-panel-expanded .filter-panel:not(.x-hide-display) .filter-column-panel-start .filter-hide-label input"),

		FILTER_EXPANDED_TAG_DROPDOWN("#reporting:not(.x-hide-display) .tag-combo-box span>img:last-of-type"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN("div[class='x-layer']>div+div"),

		FILTER_EXPANDED_REPORT_NAME_TEXT_FIELD("#reporting:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) input"),

		FILTER_EXPANDED_COMPLETE_CHECKBOX("#reporting:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:first-of-type input"),
		FILTER_EXPANDED_RUNNING_CHECKBOX("#reporting:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(2) input"),
		FILTER_EXPANDED_ERROR_CHECKBOX("#reporting:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(3) input");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public ReportListTab() throws ElementNotFoundException {
		if(!Utility.isElementPresent(PageElements.REPORT_LIST_TAB_VERIFY))
		{
			log.info("Currently at url : {}", Utility.getCurrentUrl());  
			throw new IllegalStateException("This is not the MDS > Respots List page");
		}
		
	}

	public void waitForPageToMask() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY);
	}

	public ReportListTab clickShowFilters() {
		Utility.click(PageElements.SHOW_FILTER);
		return this;
	}

	public ReportListTab waitForPageMasking() {
		try {
			log.info("waiting for page to mask");
			Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY);
		} catch (ElementNotFoundException e) {
			e.logException("Exception while waititng for page to mask on Reports Tab");
		}
		return this;
	}

	private ReportListTab waitForPageUnMasking() {
		try {
			log.info("waiting for page to unmask");
			Utility.waitForElementPresent(PageElements.PAGE_LOADING_NOT_MASKED_VERIFY);
			// Utility.waitUntilElementDissAppears(PageElements.PAGE_LOADING_MASKED_VERIFY);
		} catch (ElementNotFoundException e) {
			e.logException("Exception while waititng for page to unmask on Reports Tab");
		}
		return this;

	}

	// TODO Passing but not clicking.
	public ReportListTab selectAllSitesCheckBox() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.ALL_REPORT_CHECKBOX);
		if (Utility.isElementPresent(PageElements.ALL_REPORT_CHECKBOX)) {

			Utility.selectCheckBox(PageElements.ALL_REPORT_CHECKBOX);

		} else {
			throw new NoSuchElementException("All Sites checkbox is not present");
		}

		return this;
	}

	// TODO Passing but not clicking.
	public ReportListTab selectSingleScheduleCheckBox(String reportName) throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		Utility.selectCheckBoxOfSingleRecord(PageElements.EACH_REPORT_TITLE, PageElements.EACH_REPORT_CHECKBOX, superElement, reportName);

		return this;
	}

	public ReportListTab clickQuickActionsDropDown(String reportName) throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_BTN);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		Utility.selectQuickActionsOfSingleRecord(PageElements.EACH_REPORT_TITLE, PageElements.QUICK_ACTIONS_DOWN_BTN, superElement, reportName);

		return this;

	}

	// TODO return type schedule View dialog
	public ReportListTab selectQuickActionsView(String reportName) throws ElementNotFoundException {

		clickQuickActionsDropDown(reportName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW);
		return this;
	}

	public NewScanEntireSiteDialog selectQuickActionsSendReport(String reportName) throws ElementNotFoundException {
		clickQuickActionsDropDown(reportName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_SEND_REPORT_ENABLED);
		return new NewScanEntireSiteDialog();
	}

	public NewScanEntireSiteDialog selectQuickActionsAddTag(String reportName) throws ElementNotFoundException {
		clickQuickActionsDropDown(reportName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_ADD_TAGS);
		return new NewScanEntireSiteDialog();
	}

	public NewScanEntireSiteDialog selectQuickActionsViewReport(String reportName) throws ElementNotFoundException {
		clickQuickActionsDropDown(reportName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_DELETE);
		return new NewScanEntireSiteDialog();
	}

	public ReportListTab refreshNewReportsPage() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.REFRESH_PAGE_BTN);
		Utility.click(PageElements.REFRESH_PAGE_BTN);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab clickActionsDropDown() {
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_BTN)) {
			Utility.click(PageElements.ACTIONS_DOWN_BTN);
		} else {
			throw new NoSuchElementException("Actions button is either disabled or not present on the page");
		}

		return this;
	}

	public ReportListTab selectActionsView() {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_VIEW)) {
			Utility.click(PageElements.ACTIONS_DOWN_VIEW);
		} else {
			throw new NoSuchElementException("Actions>view button is either disabled or not present on the page");
		}

		return this;
	}

	public ReportListTab selectActionsDownload() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_DOWNLOAD)) {
			Utility.click(PageElements.ACTIONS_DOWN_DOWNLOAD);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Edit button is either disabled or not present on the page");
		}
		return this;
	}

	public ReportListTab selectActionSendReport() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_SEND_REPORT_ENABLED)) {
			Utility.click(PageElements.ACTIONS_DOWN_SEND_REPORT_ENABLED);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Add Tags button is either disabled or not present on the page");
		}
		return this;
	}

	public ReportListTab selectActionsAddTags() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_ADD_TAGS)) {
			Utility.click(PageElements.ACTIONS_DOWN_ADD_TAGS);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Actions_ViewReport_Enabled_DropDown_Navigation_XPATH");
		}
		return this;
	}

	public ReportListTab selectActionsDelete() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_DELETE)) {
			Utility.click(PageElements.ACTIONS_DOWN_DELETE);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Scan button is either disabled or not present on the page");
		}
		return this;
	}

	public ReportListTab clickFilterDropDown() {

		Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
		return this;
	}

	public ReportListTab selectFilterDownload() {
		clickFilterDropDown();
		Utility.click(PageElements.FILTER_SETTINGS_DOWNLOAD);
		return this;
	}

	public ReportListTab selectFilterSortBy() {

		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);

		return this;
	}

	public ReportListTab selectFilterSortByName() throws ElementNotFoundException {

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_NAME);
		Utility.moveToElementAndClick(PageElements.SORT_BY_NAME);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterSortByFormat() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_FORMAT);
		Utility.moveToElementAndClick(PageElements.SORT_BY_FORMAT);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterSortByType() throws ElementNotFoundException {

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_TYPE);
		Utility.moveToElementAndClick(PageElements.SORT_BY_TYPE);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterSortByStatus() throws ElementNotFoundException {

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_STATUS);
		Utility.moveToElementAndClick(PageElements.SORT_BY_STATUS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterSortByGenerationDate() throws ElementNotFoundException {

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_GENERATION_DATE);
		Utility.moveToElementAndClick(PageElements.SORT_BY_GENERATION_DATE);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterRowsShown() {

		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);
		return this;
	}

	public ReportListTab selectFilterRowsShown20() throws ElementNotFoundException {

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterRowsShown50() throws ElementNotFoundException {

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterRowsShown100() throws ElementNotFoundException {

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab selectFilterRowsShown200() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public ReportListTab leftPagingComboArrowButton() throws ElementNotFoundException {
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_LEFT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_LEFT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();

		} else {
			throw new IllegalStateException("Left button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public ReportListTab rightPagingComboArrowButton() throws ElementNotFoundException {

		if (Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN) != null) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();

		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public ReportListTab clickPagingComboDropDown() throws ElementNotFoundException {
		//waitForPageMasking();
		waitForPageUnMasking();

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		return this;
	}

	// need waitforpageload
	public ReportListTab selectPagingComboRange(int start, int end) throws ElementNotFoundException {

		clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);
		WebElement superElelemnt = Utility.getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);

		Utility.selectFromCombo(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS, superElelemnt, start + " - " + end + " of " + end);
		System.out.println(start + " - " + end + " of " + end);
		return this;
	}

	/*
	 * public void selectRows() {
	 * 
	 * clickPagingComboDropDown(); waitForPageUnMasking();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_Middle_PagingCombo_FirstRange_Navigation", IdentifiedBy.CSS);
	 * String pageRange = Utility.getTextOfPageObject(
	 * PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_Middle_PagingCombo_FirstRange_Navigation", IdentifiedBy.CSS);
	 * 
	 * String[] splitRange = pageRange.split("\\W"); int totalSites =
	 * Integer.parseInt(splitRange[5]);
	 * 
	 * if (totalSites > 20 && totalSites <= 50) { selectFilterRowsShown50();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS); }
	 * 
	 * else if (totalSites > 50 && totalSites <= 100) {
	 * selectFilterRowsShown100();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS); }
	 * 
	 * else if (totalSites > 100 && totalSites <= 200) {
	 * selectFilterRowsShown200();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS); }
	 * 
	 * }
	 */

	public NewReport clickNewReportBtn() throws ElementNotFoundException {
		Utility.click(PageElements.NEW_REPORT_BTN);
		return new NewReport();
	}

	public void numberOfRows() throws ElementNotFoundException {
		clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);
		String pageRange = Utility.getTextOfPageObject(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);

		String[] splitRange = pageRange.split("\\W");
		totalRows = Integer.parseInt(splitRange[5]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		clickPagingComboDropDown();
	}

	public String getFormatOfReport(String reportName) throws ElementNotFoundException {

		String formatOfReport;

		// Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);
		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		formatOfReport = Utility.getTextOfRecordColumn(PageElements.EACH_REPORT_TITLE, PageElements.EACH_REPORT_FORMAT, superElement, reportName);
		return formatOfReport;
	}

	public String getTypeOfReport(String reportName) throws ElementNotFoundException {
		String typeOfReport;

		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		typeOfReport = Utility.getTextOfRecordColumn(PageElements.EACH_REPORT_TITLE, PageElements.EACH_REPORT_TYPE, superElement, reportName);
		return typeOfReport;

	}

	public String getStatusOfReport(String reportName) throws ElementNotFoundException {

		String siteURLOfAsset;

		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		siteURLOfAsset = Utility.getTextOfRecordColumn(PageElements.EACH_REPORT_TITLE, PageElements.EACH_REPORT_STATUS, superElement, reportName);
		return siteURLOfAsset;
	}

	// TODO Workssome times.
	public String getGenerationDateOfReport(String reportName) throws ElementNotFoundException {

		String tagOfAsset;

		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		tagOfAsset = Utility.getTextOfRecordColumn(PageElements.EACH_REPORT_TITLE, PageElements.EACH_REPORT_GENERATION_DATE, superElement, reportName);
		return tagOfAsset;
	}

	public int getTotalRows() throws ElementNotFoundException {

		numberOfRows();
		return totalRows;
	}

	public ReportListTab clickrightPagingComboArrowButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN);
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public List<String> getAllReportsText() throws ElementNotFoundException {
		List<String> allReportNames = new ArrayList<String>();
		List<WebElement> assetSiteURLWebElement = new ArrayList<WebElement>();
		// waitForPageUnMasking();
		try {
			Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
			WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);
			int totalRowsInDL = getTotalRows();

			if (totalRowsInDL > 20) {
				// scansTitlesWebElement =
				// Utility.getRecordWebEements(PageElements.EACH_SCAN_TITLE,
				// superElement);
				int pagination = 0;
				while (pagination <= (totalRowsInDL / 20)) {
					assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_REPORT_TITLE, superElement);
					for (int scanTitleRow = 0; scanTitleRow < assetSiteURLWebElement.size(); scanTitleRow++) {
						allReportNames.add(assetSiteURLWebElement.get(scanTitleRow).getText());
					}
					if (pagination != (totalRowsInDL / 20)) {
						clickrightPagingComboArrowButton();
					}
					pagination++;
				}

			} else if (totalRowsInDL <= 20) {
				assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_REPORT_TITLE, superElement);
				for (int scanTitleRow = 0; scanTitleRow < assetSiteURLWebElement.size(); scanTitleRow++) {
					allReportNames.add(assetSiteURLWebElement.get(scanTitleRow).getText());
				}

			}
		} catch (ElementNotFoundException e) {
			// TODO Auto-generated catch block
			if (Utility.isElementPresent(PageElements.EMPTY_REPORT_LIST)) {
				log.error("There are no reports. DL is empty");
				org.testng.Assert.fail("Test case failed as there are no reports in report data list");
			} else {
				e.logException("Exception while getting reprots text.");
			}
		}
		return allReportNames;
	}

	public boolean verifyIfReportIsListed(String reportName) {
		boolean isReportPresent = false;

		List<WebElement> assetSiteURLWebElement = new ArrayList<WebElement>();
		try {
			Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
			WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);
			int totalRowsInDL = getTotalRows();

			if (totalRowsInDL > 20) {
				// scansTitlesWebElement =
				// Utility.getRecordWebEements(PageElements.EACH_SCAN_TITLE,
				// superElement);
				int pagination = 0;
				while (pagination <= (totalRowsInDL / 20)) {
					assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_REPORT_TITLE, superElement);
					for (int scanTitleRow = 0; scanTitleRow < assetSiteURLWebElement.size(); scanTitleRow++) {
						if (assetSiteURLWebElement.get(scanTitleRow).getText().equals(reportName)) {
							isReportPresent = true;
							scanTitleRow = assetSiteURLWebElement.size();
						} else {
							isReportPresent = false;
						}
					}
					if (!isReportPresent && pagination != (totalRowsInDL / 20)) {
						clickrightPagingComboArrowButton();
					} else if (isReportPresent) {
						pagination = (totalRowsInDL / 20) + 1;
					} else {
						pagination++;
					}
				}

			} else if (totalRowsInDL <= 20) {
				assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_REPORT_TITLE, superElement);
				for (int scanTitleRow = 0; scanTitleRow < assetSiteURLWebElement.size(); scanTitleRow++) {
					if (assetSiteURLWebElement.get(scanTitleRow).getText().equals(reportName)) {
						isReportPresent = true;
						scanTitleRow = assetSiteURLWebElement.size();
					} else {
						log.error("Failed to create report : " + reportName);
						isReportPresent = false;
					}
				}

			}
		} catch (ElementNotFoundException e) {
			// TODO Auto-generated catch block
			if (Utility.isElementPresent(PageElements.EMPTY_REPORT_LIST)) {
				log.error("There are no reports. DL is empty");
				org.testng.Assert.fail("Test case failed as there are no reports in report data list");
			} else {
				e.logException("Exception while performing verifyIfReportIsListed");
			}
		}

		return isReportPresent;
	}

	public boolean verifyFormatOfReport(String reportName, String expectedValue) throws ElementNotFoundException {
		String actualValue = getFormatOfReport(reportName);

		if (actualValue.equals(expectedValue)) {
			log.info("Format verification passed. Actual :" + actualValue + ", Expected :" + expectedValue);
			return true;
		} else {
			log.error("Format verification failed coz, Expected : " + expectedValue + " Actual : " + actualValue);
			return false;
		}
	}

	public boolean verifyStatuseOfReport(String reportName) throws ElementNotFoundException {
		String actualValue = getStatusOfReport(reportName);

		if (actualValue.equals("Complete") || actualValue.equals("Running")) {
			log.info("Status verification passed. Actual :" + actualValue + ", Expected : Complete or Running");
			return true;
		} else {
			log.error("Status verification failed coz, Expected : Complete or Running , Actual : " + actualValue);
			return false;
		}
	}

	public boolean verifyTypeOfReport(String reportName, String expectedValue) throws ElementNotFoundException {
		String actualValue = getTypeOfReport(reportName);
		if (actualValue.equals(expectedValue)) {
			log.info("Report type verification passed. Actual :" + actualValue + ", Expected :" + expectedValue);
			return true;
		} else {
			log.error("Report type verification failed coz, Expected : " + expectedValue + " Actual : " + actualValue);
			return false;
		}
	}

	public StringBuffer getAllFormatText() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_REPORT_TITLE);
		List<WebElement> assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_REPORT_FORMAT, superElement);
		StringBuffer allFormats = new StringBuffer();
		for (int siteTitleRow = 0; siteTitleRow < assetSiteURLWebElement.size(); siteTitleRow++) {
			allFormats.append(assetSiteURLWebElement.get(siteTitleRow).getText() + "\n");
		}
		return allFormats;
	}

	public StringBuffer getAllTypeOfScanText() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_REPORT_TITLE);
		List<WebElement> assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_REPORT_TYPE, superElement);
		StringBuffer allTypeOfScan = new StringBuffer();
		for (int siteTitleRow = 0; siteTitleRow < assetSiteURLWebElement.size(); siteTitleRow++) {
			allTypeOfScan.append(assetSiteURLWebElement.get(siteTitleRow).getText() + "\n");
		}
		return allTypeOfScan;
	}

	public StringBuffer getAllGenerationDateText() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.REPORT_DATA_LIST_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.REPORT_DATA_LIST_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_REPORT_GENERATION_DATE);
		List<WebElement> assetTagsWebElements = Utility.getRecordWebEements(PageElements.EACH_REPORT_GENERATION_DATE, superElement);
		StringBuffer allGenerationDates = new StringBuffer();
		for (int assetTagRow = 0; assetTagRow < assetTagsWebElements.size(); assetTagRow++) {
			allGenerationDates.append(assetTagsWebElements.get(assetTagRow).getText() + "\n");
		}
		return allGenerationDates;
	}

	// FILTERS EXPANDED NAVIGATION(SHOW FILTERS)
	public ReportListTab filterByTags(String tagName) throws ElementNotFoundException {

		Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		WebElement superElement = Utility.getElement(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS);

		Utility.selectMultipleValuesDoubleClick(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS, superElement, tagName);

		Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN);

		return this;
	}

	public ReportListTab filterByScanStatus(String statusOfScan) {
		if (statusOfScan.equalsIgnoreCase("complete")) {
			Utility.click(PageElements.FILTER_EXPANDED_COMPLETE_CHECKBOX);
		} else if (statusOfScan.equalsIgnoreCase("running")) {
			Utility.click(PageElements.FILTER_EXPANDED_RUNNING_CHECKBOX);
		} else if (statusOfScan.equalsIgnoreCase("error")) {
			Utility.click(PageElements.FILTER_EXPANDED_ERROR_CHECKBOX);
		}

		return this;
	}

	public ReportListTab clickHideFilters() {
		Utility.click(PageElements.HIDE_FILTER);
		return this;
	}

	public ReportListTab clickClearFilters() {
		Utility.click(PageElements.CLEAR_FILTER);
		return this;
	}
}
