package com.qualys.selenium.mds.pageobject.dialogs.schedule;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;

@Slf4j
public class ScheduleDialogue {

	public enum PageElements implements IPageElement {

		STEP_VERIFY_CREATE_MODE(".schedule-object-window .mode-create"),
		STEP_VERIFY_EDIT_MODE(".schedule-object-window .mode-edit"),
		STEP_VERIFY_VIEW_MODE(".schedule-object-window .mode-view"),

		TARGET_STEP(".schedule-object-window .step-basic"),
		SCHEDULES_STEP(".schedule-object-window .step-scheduling"),
		REVIEW_AND_CONFIRM_STEP(".schedule-object-window .step-review"),

		TASK_DETAILS_SIDEBAR_STEP_LABEL(".schedule-object-window .object-window-body .step-basic .value-bwrap-name"),
		SCHEDULING_OPTIONS_SIDEBAR_STEP_LABEL(".schedule-object-window .object-window-body .step-scheduling .value-bwrap-name"),
		REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL(".schedule-object-window .object-window-body .step-review .value-bwrap-name");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public String scheduleDialogMode = "";

	public ScheduleDialogue(String mode) {
		scheduleDialogMode = mode;

		if (mode.equalsIgnoreCase("create")) {
			if (!Utility.isElementPresent(PageElements.STEP_VERIFY_CREATE_MODE)) {
				log.info("Currently at url : {}", Utility.getCurrentUrl());
				throw new IllegalStateException("This is not the AddSite>Site Details List page");
			}
		} else if (mode.equalsIgnoreCase("edit")) {
			if (!Utility.isElementPresent(PageElements.STEP_VERIFY_EDIT_MODE)) {
				log.info("Currently at url : {}", Utility.getCurrentUrl());
				throw new IllegalStateException("This is not the AddSite>Site Details List page");
			}
		} else if (mode.equalsIgnoreCase("view")) {
			if (!Utility.isElementPresent(PageElements.STEP_VERIFY_VIEW_MODE)) {
				log.info("Currently at url : {}", Utility.getCurrentUrl());
				throw new IllegalStateException("This is not the AddSite>Site Details List page");
			}
		}
	}

	public String getDialogueMode() {
		return scheduleDialogMode;
	}

	public TaskDetails goToTaskDetails() {
		Utility.click(PageElements.TARGET_STEP);
		return new TaskDetails(scheduleDialogMode);
	}

	public SchedulingOptions goToSchedulingOptions() {
		Utility.click(PageElements.SCHEDULES_STEP);
		return new SchedulingOptions("create");
	}

	public ReviewAndConfirm goToReviewAndConfim() {
		Utility.click(PageElements.REVIEW_AND_CONFIRM_STEP);
		return new ReviewAndConfirm();
	}

	public void verifySideBarStepsStaticText() {

		CustomVerification customVerification = new CustomVerification();
		customVerification.verifyEquals("New Schedule TASK_DETAILS_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.TASK_DETAILS_SIDEBAR_STEP_LABEL), "Task details");
		customVerification.verifyEquals("New Schedule SCHEDULING_OPTIONS_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.SCHEDULING_OPTIONS_SIDEBAR_STEP_LABEL), "Scheduling options");
		customVerification.verifyEquals("New Schedule REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL), "Review and Confirm");

	}

}
