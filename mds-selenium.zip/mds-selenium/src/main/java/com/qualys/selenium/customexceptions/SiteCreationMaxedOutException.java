package com.qualys.selenium.customexceptions;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SuppressWarnings("serial")
public class SiteCreationMaxedOutException extends Exception {

	String errorOnPage;

	public SiteCreationMaxedOutException(String errorMessage) {
		errorOnPage = errorMessage;
	}

	public String myMessage() {
		return "Total allowed sites maxed out..!! " + errorOnPage + ".Exception is caught and will be handled by clicking OK button on Site creation error dialog ";
	}

	public void logException() {
		log.error(myMessage());
	}

	/*
	 * @SuppressWarnings("static-access") public AddSiteDialog
	 * SiteCreationMaxedOutException() { try { DashboardPage dashboardPage = new
	 * DashboardPage(); if (!dashboardPage.verifySiteCreationError()) ; { return
	 * new AddSiteDialog("create"); } } catch (SiteCreationMaxedOutException e)
	 * {
	 * 
	 * } }
	 */
}
