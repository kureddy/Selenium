package com.qualys.selenium.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JDBConnection {
	public static Connection db_connection = null;
	private static JDBConnection instance;

	public synchronized static JDBConnection getInstance() {
		if (instance == null) {
			instance = new JDBConnection();
		}
		return instance;
	}

	public static void startDB() {
		if (db_connection == null) {

			/*
			 * String driver_JDBCname = "oracle.jdbc.driver.OracleDriver";
			 * 
			 * String db_url =
			 * "jdbc:oracle:thin:@qdb.p03.eng.qualys.com:1521:qweb";
			 * 
			 * String userN = "grc_user";
			 * 
			 * String passcode = "grc2010!";
			 */

			try {
				// Register JDBC driver
				// Class.forName(driver_JDBCname);
				if(PropertyReader.getConfigProperty("environment").equalsIgnoreCase("pod3"))
				{
					Class.forName(PropertyReader.getJDBCProperties("pod3_driver__JDBCname"));
					// Connect to the DataBase
					db_connection = DriverManager.getConnection(PropertyReader.getJDBCProperties("pod3_db_url"), PropertyReader.getJDBCProperties("pod3_userN"), PropertyReader.getJDBCProperties("pod3_passcode"));
				}else if(PropertyReader.getConfigProperty("environment").equalsIgnoreCase("pod4"))
				{
					Class.forName(PropertyReader.getJDBCProperties("pod4_driver__JDBCname"));
					// Connect to the DataBase
					db_connection = DriverManager.getConnection(PropertyReader.getJDBCProperties("pod4_db_url"), PropertyReader.getJDBCProperties("pod4_userN"), PropertyReader.getJDBCProperties("pod4_passcode"));
				}else if(PropertyReader.getConfigProperty("environment").equalsIgnoreCase("pod4"))
				{
					Class.forName(PropertyReader.getJDBCProperties("platd_driver_JDBCname"));
					// Connect to the DataBase
					db_connection = DriverManager.getConnection(PropertyReader.getJDBCProperties("platd_db_url"), PropertyReader.getJDBCProperties("platd_userN"), PropertyReader.getJDBCProperties("platd_passcode"));
				}
			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public static Connection getDB() {
		startDB();
		return db_connection;
	}

	public static void stopDB() {
		if (db_connection == null) {
			try {
				db_connection.close();
				db_connection = null;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static ResultSet getResultSet(String query) {
		ResultSet rs = null;

		Connection conn = JDBConnection.getDB();
		try {

			Statement stmt = conn.createStatement();
			rs = stmt.executeQuery(query);

		} catch (Exception e) {
			log.error("Error: {}", e);
		}
		return rs;
	}

}
