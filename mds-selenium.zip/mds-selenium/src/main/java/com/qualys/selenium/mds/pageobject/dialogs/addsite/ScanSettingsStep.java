package com.qualys.selenium.mds.pageobject.dialogs.addsite;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;

@Slf4j
public class ScanSettingsStep extends AddSiteDialog {

	public enum PageElements implements IPageElement {

		STEP_VERIFY_BEFORE_FILLING(".step-scanSettings:not(.middle-inactive)"),
		STEP_VERIFY_AFTER_FILLING(".step-scanSettings:not(.middle-inactive).middle-passed"),

		SCAN_SETTINGS_STEP_HEADER_LABEL(".malware-site-object-window .q-step-header .object-panel div"),
		SCAN_OPTIONS_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(2) .section-panel-header-text"),
		SCAN_OPTIONS_DESCRIPTION_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(2) .notice"),
		REQUIRED_FIELDS_NOTICE_LABEL(".malware-site-object-window .q-scroller:nth-of-type(2) .notice-required div"),
		MAX_PAGES_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(2)  .section-panel-body  .x-form-item:nth-of-type(1) label"),
		SCAN_INTENSITY_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(2)  .section-panel-body  .x-form-item:nth-of-type(2) label"),
		HEADER_INJECTION_HEADER_LABEL(".malware-site-object-window .q-scroller:nth-of-type(2) .section-edit-panel:nth-of-type(3) .section-panel-header-text"),
		HEADER_INJECTION_DESCRIPTION_LABEL(".malware-site-object-window .q-scroller:nth-of-type(2) .section-edit-panel:nth-of-type(3) .notice"),
		HEADER_INJECTION_LABEL(".malware-site-object-window .q-scroller:nth-of-type(2) .section-edit-panel:nth-of-type(3) .x-form-item label"),
		HEADER_INJECTION_EXAMPLE_LABEL(".malware-site-object-window .q-scroller:nth-of-type(2) .section-edit-panel:nth-of-type(3) .example"),

		// help tips
		TURN_HELP_TIPS_ON_OFF_LABEL(".malware-site-object-window .q-window-header div.help-on"), // TODO
																									// :
																									// no
																									// such
																									// element
																									// exception
		LAUNCH_HELP_LABEL(".malware-site-object-window .q-window-header div.launch-help"),

		HELP_TIPS_ON(".malware-site-object-window .q-window-header div.help-on .help-toggle-on"),
		HELP_TIPS_OFF(".malware-site-object-window .q-window-header div.help-on .help-toggle-off"),

		MAX_PAGES_TEXT_FIELD(".malware-site-object-window input[name=max-pages]"),

		SCAN_INTENSITY_TEXT_FIELD(".malware-site-object-window input[name=intensity]"),
		SCAN_INTENSITY_DOWN_CONTAINER_MAXIMUM("div.x-combo-list-item:nth-child(1)"),
		SCAN_INTENSITY_DOWN_CONTAINER_HIGH("div.x-combo-list-item:nth-child(2)"),
		SCAN_INTENSITY_DOWN_CONTAINER_MEDIUM("div.x-combo-list-item:nth-child(3)"),
		SCAN_INTENSITY_DOWN_CONTAINER_LOW("div.x-combo-list-item:nth-child(4)"),
		SCAN_INTENSITY_DOWN_CONTAINER_MINIMUM("div.x-combo-list-item:nth-child(5)"),

		HEADER_INJECTION_TEXTFIELD(".malware-site-object-window div:nth-of-type(2):not(.x-hide-display)[class=q-scroller] div:nth-of-type(3)[class*=section-edit-panel] div[class*=-element] textarea[name=headers] ");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public ScanSettingsStep(AddSiteDialogMode mode) throws SiteCreationMaxedOutException, ElementNotFoundException {
		super(mode);
		if (!Utility.isElementPresent(PageElements.STEP_VERIFY_BEFORE_FILLING)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the AddSite>Scan Settings page");
		}
	}

	public ScanSettingsStep(AddSiteDialogMode mode, String Previous) throws SiteCreationMaxedOutException, ElementNotFoundException {
		super(mode);
		if (!Utility.isElementPresent(PageElements.STEP_VERIFY_AFTER_FILLING)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the AddSite > Scan Settings List page");
		}
	}

	public ScanSettingsStep typeMaximumPages(String numnerOfPages) {
		if (numnerOfPages.equalsIgnoreCase("none")) {
			try {
				Utility.typeInEditBox(PageElements.MAX_PAGES_TEXT_FIELD, numnerOfPages);
				log.info("typing in ScanSettingsStep > MaximumPages" + numnerOfPages);
			} catch (Exception e) {
				log.error("Error while typing ScanSettingsStep > MaximumPages" + numnerOfPages);
				e.printStackTrace();
			}
			return this;
		} else {
			log.info("numnerOfPages = " + numnerOfPages + "So not typing max pages");
			return this;
		}
	}

	public ScanSettingsStep selectScanIntensity(String intensityLevel) {
		if (!intensityLevel.equalsIgnoreCase("none")) {

			Utility.click(PageElements.SCAN_INTENSITY_TEXT_FIELD);

			if (intensityLevel.equalsIgnoreCase("Maximum")) {
				try {
					Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_MAXIMUM);
					log.info("Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_MAXIMUM " + intensityLevel);
				} catch (Exception e) {
					log.error("Error while Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_MAXIMUM = " + intensityLevel);
					e.printStackTrace();
				}

			} else if (intensityLevel.equalsIgnoreCase("High")) {
				try {
					Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_HIGH);
					log.info("Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_HIGH" + intensityLevel);
				} catch (Exception e) {
					log.error("Error while Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_HIGH = " + intensityLevel);
					e.printStackTrace();
				}
			} else if (intensityLevel.equalsIgnoreCase("Medium")) {
				try {
					Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_MEDIUM);
					log.info("Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_MEDIUM" + intensityLevel);
				} catch (Exception e) {
					log.error("Error while Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_MEDIUM = " + intensityLevel);
					e.printStackTrace();
				}
			} else if (intensityLevel.equalsIgnoreCase("Low")) {
				try {
					Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_LOW);
					log.info("Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_LOW " + intensityLevel);
				} catch (Exception e) {
					log.error("Error while Clicking on ScanSettingsStep > SCAN_INTENSITY_DOWN_CONTAINER_LOW = " + intensityLevel);
					e.printStackTrace();
				}

			} else if (intensityLevel.equalsIgnoreCase("Minimum")) {
				Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_MINIMUM);
			}
			return this;
		} else {
			log.info("intensityLevel = " + intensityLevel + "So not typing Intensity level");
			return this;
		}
	}

	public ScanSettingsStep typeInHeaderInjection(String headerToImpersonateWebBrowser) {
		
		if (!headerToImpersonateWebBrowser.equalsIgnoreCase("none")) {
			Utility.typeInEditBox(PageElements.HEADER_INJECTION_TEXTFIELD, headerToImpersonateWebBrowser);
			if(!Utility.getTextOfPageObject(PageElements.HEADER_INJECTION_TEXTFIELD).equals(headerToImpersonateWebBrowser))
			{
				Utility.typeInEditBox(PageElements.HEADER_INJECTION_TEXTFIELD, headerToImpersonateWebBrowser);
			}
			log.info("Typed Site title in SiteDetailsStep " + headerToImpersonateWebBrowser);

			return this;
		} else {
			log.info("header Injection = " + headerToImpersonateWebBrowser + "So not typing in header injection field");
			return this;
		}
	}

	public ScanSettingsStep oNHelpTips() {
		Utility.click(PageElements.HELP_TIPS_ON);
		return this;
	}

	public ScanSettingsStep oFFHelpTips() {
		Utility.click(PageElements.HELP_TIPS_OFF);
		return this;
	}

	public ScanSettingsStep launchHelp() {
		Utility.click(PageElements.LAUNCH_HELP_LABEL);
		return this;
	}

	public CrawlExclusionListsStep clickContinue() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(DialogCommonElements.CONTINUE_BTN);

		return new CrawlExclusionListsStep(siteDialogueMode);
	}

	public DashboardPage clickCancel() throws ElementNotFoundException {

		Utility.click(DialogCommonElements.CANCEL_BTN);
		return new DashboardPage();
	}

	public SiteDetailsStep clickPrevious() throws SiteCreationMaxedOutException, ElementNotFoundException {
		Utility.click(DialogCommonElements.PREVIOUS_BTN);
		return new SiteDetailsStep(AddSiteDialogMode.CREATE);
	}

	public ScanSettingsStep verifyScanSettingsStepStaticText() {
		CustomVerification customVerification = new CustomVerification();

		// customVerification.verifyEquals("Site Details step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help ");
		// //TODO : no such element exception
		customVerification.verifyEquals("Site Details step LAUNCH_HELP_", Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL), "Launch help");

		customVerification.verifyEquals("Scan settings step  SCAN_SETTINGS_STEP_HEADER_LABEL   ", Utility.getTextOfPageObject(PageElements.SCAN_SETTINGS_STEP_HEADER_LABEL),
				"Please choose a default scan setting for the web application");
		customVerification.verifyEquals("Scan settings step  SCAN_OPTIONS_HEADER_LABEL    ", Utility.getTextOfPageObject(PageElements.SCAN_OPTIONS_HEADER_LABEL), "Scan options");
		customVerification.verifyEquals("Scan settings step  REQUIRED_FIELDS_NOTICE_LABEL   ", Utility.getTextOfPageObject(PageElements.REQUIRED_FIELDS_NOTICE_LABEL), "(*) REQUIRED FIELDS");
		customVerification.verifyEquals("Scan settings step  SCAN_OPTIONS_DESCRIPTION_LABEL    ", Utility.getTextOfPageObject(PageElements.SCAN_OPTIONS_DESCRIPTION_LABEL),
				"High level is recommended for high bandwidth usage.");
		customVerification.verifyEquals("Scan settings step  MAX_PAGES_LABEL    ", Utility.getTextOfPageObject(PageElements.MAX_PAGES_LABEL), "Maximum Pages (1 - 25)*");
		customVerification.verifyEquals("Scan settings step  SCAN_INTENSITY_LABEL    ", Utility.getTextOfPageObject(PageElements.SCAN_INTENSITY_LABEL), "Scan Intensity*");

		customVerification.verifyEquals("Scan settings step  HEADER_INJECTION_HEADER_LABEL    ", Utility.getTextOfPageObject(PageElements.HEADER_INJECTION_HEADER_LABEL), "Header Injection");
		customVerification.verifyEquals("Scan settings step  HEADER_INJECTION_DESCRIPTION_LABEL    ", Utility.getTextOfPageObject(PageElements.HEADER_INJECTION_DESCRIPTION_LABEL),
				"This is intended for situations where a workaround is needed for complex authentication schemes or to impersonate a web browser.");
		customVerification.verifyEquals("Scan settings step  HEADER_INJECTION_LABEL    ", Utility.getTextOfPageObject(PageElements.HEADER_INJECTION_LABEL), "Headers");
		customVerification.verifyEquals("Scan settings step  HEADER_INJECTION_EXAMPLE_LABEL    ", Utility.getTextOfPageObject(PageElements.HEADER_INJECTION_EXAMPLE_LABEL),
				"Example: Cookie: ASP.NET_SessionId=yw13b045nq1zluvxp4vi4o55; .ASPXFORMSAU");

		customVerification.verifyEquals("Scan settings step  CONTINUE_BTN    ", Utility.getTextOfPageObject(DialogCommonElements.CONTINUE_BTN), "Continue");
		customVerification.verifyEquals("Scan settings step  CANCEL_BTN   ", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN), "Cancel");

		return this;

	}
}
