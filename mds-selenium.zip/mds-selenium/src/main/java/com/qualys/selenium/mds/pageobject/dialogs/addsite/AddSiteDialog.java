package com.qualys.selenium.mds.pageobject.dialogs.addsite;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog;

@Slf4j
public class AddSiteDialog extends AbstractDialog {
	public enum AddSiteDialogMode {

		CREATE("create"),
		EDIT("edit"),
		VIEW("view");

		String uiValue;

		AddSiteDialogMode(String uiValue) {
			this.uiValue = uiValue;
		}

		public String getUiValue() {
			return this.uiValue;
		}
	}

	

	public enum PageElements implements IPageElement {

		STEP_VERIFY_CREATE_MODE(".malware-site-object-window.q-window .mode-create"),
		STEP_VERIFY_EDIT_MODE(".malware-site-object-window.q-window .mode-edit"),
		STEP_VERIFY_VIEW_MODE(".malware-site-object-window.q-window .mode-view"),

		// continue,finish,cancel,SAVE&SCAN NOW buttons are included in
		// abstractDialog class

		SITES_DETAILS_SIDEBAR_STEP_LABEL(".malware-site-object-window .step-basic .value-bwrap-name"),
		SCAN_SETTINGS_SIDEBAR_STEP_LABEL(".malware-site-object-window .step-scanSettings .value-bwrap-name"),
		CRAWL_EXCLUSION_SIDEBAR_LISTS_STEP_LABEL(".malware-site-object-window .step-url .value-bwrap-name"),
		SCHEDULING_SIDEBAR_STEP_LABEL(".malware-site-object-window .step-scheduling .value-bwrap-name"),
		REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL(".malware-site-object-window .step-review .value-bwrap-name"),

		SITES_DETAILS_SIDEBAR_STEP_NUMBER_LABEL(".malware-site-object-window .step-basic .stepNb"),
		SCAN_SETTINGS_SIDEBAR_STEP_NUMBER_LABEL(".malware-site-object-window .step-scanSettings .stepNb"),
		CRAWL_EXCLUSION_SIDEBAR_STEP_NUMBER_LABEL(".malware-site-object-window .step-url .stepNb"),
		SCHEDULING_SIDEBAR_STEP_NUMBER_LABEL(".malware-site-object-window .step-scheduling .stepNb"),
		REVIEW_AND_CONFIRM_SIDEBAR_STEP_NUMBER_LABEL(".malware-site-object-window .step-review .stepNb"),

		SITE_DETAILS_STEP(".malware-site-object-window .step-basic"),
		SCAN_SETTINGS_STEP(".malware-site-object-window .step-scanSettings"),
		CRAWL_EXCLUSION_LISTES(".malware-site-object-window .step-url"),
		SCHEDULING(".malware-site-object-window .step-scheduling"),
		REVIEW_AND_CONFIRM(".malware-site-object-window .step-review"),

		ADD_SITE_DIALOG_CLOSE_CROSS_BTN("//div[contains(@class,'malware-site-object-window')]//div[contains(@class,'q-window-header')]//div[@title='Close']", IdentifiedBy.XPATH);

		String locator;
		IdentifiedBy identifiedBy;

		PageElements(String locator, IdentifiedBy identifiedBy) {
			this.locator = locator;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String locator) {
			this(locator, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.locator;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public AddSiteDialogMode siteDialogueMode;

	public AddSiteDialog(AddSiteDialogMode mode) throws SiteCreationMaxedOutException, ElementNotFoundException {
		siteDialogueMode = mode;
		switch (siteDialogueMode)

		{
		case CREATE:
			
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			if (!Utility.isElementPresent(PageElements.STEP_VERIFY_CREATE_MODE)) {
				if (MalwarePage.isSiteCreationErrorPresent()) {
					throw new SiteCreationMaxedOutException("Error while verifying Add site dialog launch");
				} else {
					throw new IllegalStateException("This is not the AddSite>Site Details List page");
				}
			}break;
		case EDIT:
			
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			if (!Utility.isElementPresent(PageElements.STEP_VERIFY_EDIT_MODE)) {
				throw new IllegalStateException("This is not the AddSite>Site Details List page");
			}break;
		case VIEW:

			log.info("Currently at url : {}", Utility.getCurrentUrl());
			if (!Utility.isElementPresent(PageElements.STEP_VERIFY_VIEW_MODE)) {
				throw new IllegalStateException("This is not the MDS>Add Site page");
			}break;
		default:
			throw new RuntimeException("Add site dialog mode is not selected.It should be either create,edit or view");
		}

	}

	public SiteDetailsStep goToSiteDetails() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(PageElements.SITE_DETAILS_STEP);

		/*
		 * Utility.click(PAGE_CONSTANTS_STARTS_WITH +
		 * "SiteDetails_Step_Navigation", IdentifiedBy.CSS);
		 */
		return new SiteDetailsStep(siteDialogueMode);
	}

	public ScanSettingsStep goToScanSettings() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(PageElements.SCAN_SETTINGS_STEP);

		/*
		 * Utility.click(PAGE_CONSTANTS_STARTS_WITH +
		 * "ScanSettings_Step_Navigation", IdentifiedBy.CSS);
		 */
		return new ScanSettingsStep(siteDialogueMode);
	}

	public CrawlExclusionListsStep goToCrawlExclusionLists() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(PageElements.CRAWL_EXCLUSION_LISTES);

		/*
		 * Utility.click(PAGE_CONSTANTS_STARTS_WITH +
		 * "CrawlExclusionLists_Step_Navigation", IdentifiedBy.CSS);
		 */
		return new CrawlExclusionListsStep(siteDialogueMode);
	}

	public SchedulingStep goToScheduling() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(PageElements.SCHEDULING);

		/*
		 * Utility.click( PAGE_CONSTANTS_STARTS_WITH +
		 * "Scheduling_Step_Navigation", IdentifiedBy.CSS);
		 */
		return new SchedulingStep(siteDialogueMode);
	}

	public ReviewAndConfimStepAddSite goToReviewAndConfirm() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(PageElements.REVIEW_AND_CONFIRM);

		/*
		 * Utility.click(PAGE_CONSTANTS_STARTS_WITH +
		 * "ReviewAndConfirm_Step_Navigation", IdentifiedBy.CSS);
		 */
		return new ReviewAndConfimStepAddSite(siteDialogueMode);
	}

	public AddSiteDialog closeDialog() {
		Utility.click(PageElements.ADD_SITE_DIALOG_CLOSE_CROSS_BTN);

		return this;

	}

	public void verifySideBarStepsStaticText() {

		CustomVerification customVerification = new CustomVerification();

		customVerification.verifyEquals("Add site step SITES_DETAILS_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.SITES_DETAILS_SIDEBAR_STEP_LABEL), "Site Details");

		customVerification.verifyEquals("Add site step SCAN_SETTINGS_SIDEBAR_STEP_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_SETTINGS_SIDEBAR_STEP_LABEL), "Scan settings");

		customVerification.verifyEquals("Add site step CRAWL_EXCLUSION_SIDEBAR_LISTS_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.CRAWL_EXCLUSION_SIDEBAR_LISTS_STEP_LABEL),
				"Crawl exclusion lists");

		customVerification.verifyEquals("Add site step SCHEDULING_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.SCHEDULING_SIDEBAR_STEP_LABEL), "Scheduling");

		customVerification.verifyEquals("Add site step REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL), "Review and Confirm");

		customVerification.verifyEquals("Add site step SITES_DETAILS_SIDEBAR_STEP_NUMBER_LABEL  ", Utility.getTextOfPageObject(PageElements.SITES_DETAILS_SIDEBAR_STEP_NUMBER_LABEL), "1");

		customVerification.verifyEquals("Add site step SCAN_SETTINGS_SIDEBAR_STEP_NUMBER_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_SETTINGS_SIDEBAR_STEP_NUMBER_LABEL), "2");

		customVerification.verifyEquals("Add site step CRAWL_EXCLUSION_SIDEBAR_STEP_NUMBER_LABEL_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.CRAWL_EXCLUSION_SIDEBAR_STEP_NUMBER_LABEL),
				"3");

		customVerification.verifyEquals("Add site step SCHEDULING_SIDEBAR_STEP_NUMBER_LABEL  ", Utility.getTextOfPageObject(PageElements.SCHEDULING_SIDEBAR_STEP_NUMBER_LABEL), "4");

		customVerification.verifyEquals("Add site step REVIEW_AND_CONFIRM_SIDEBAR_STEP_NUMBER_LABEL  ", Utility.getTextOfPageObject(PageElements.REVIEW_AND_CONFIRM_SIDEBAR_STEP_NUMBER_LABEL), "5");

	}

}
