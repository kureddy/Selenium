package com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog;

@Slf4j
public class NewScanEntireSiteDialog extends AbstractDialog {

	public enum PageElements implements IPageElement {

		LAUNCH_NEW_SCAN_DIALOG_VERIFY(".scan-object-window .object-window-body"),
		
		TARGET_SIDEBAR_STEP_LABEL(".scan-object-window .step-basic .value-bwrap-name"),
		REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL(".scan-object-window .step-review .value-bwrap-name"),

		TARGET_SIDEBAR_STEP_NUMBER_LABEL(".scan-object-window .step-basic .stepNb"),
		REVIEW_AND_CONFIRM_SIDEBAR_STEP_NUMBER_LABEL(".scan-object-window .step-review .stepNb"),

		SCAN_TITLE_TEXT_AREA(".scan-object-window div:not(.x-hide-display)[class=q-scroller] input[name=scan-name]"),
		SCAN_TITLE_DROP_DOWN_ARROW_TRIGGER(".scan-object-window div:not(.x-hide-display)[class=q-scroller] div[class*=form-field-trigger-wrap] img[class*=-form-arrow-trigger]"),
		SCAN_TITLE_DROP_DOWN_CONTAINER("div[class*=combobox] "),
		SCAN_TITLE_DROP_DOWN_CONTAINER_ITEMS("div[class*=-combo-list-inner] div[class*=combobox-item]"),

		PAGE_LOADING_CHECK(".scan-object-window.q-window .mode-create"),
		TARGET_STEP(".scan-object-window .step-basic"),
		REVIEW_CONFIRM_STEP(".scan-object-window .step-review.last-active");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}
public String launchScanDialogeMode = "";

	// scans can be created and viewd.Can not edit.
	public NewScanEntireSiteDialog() throws ElementNotFoundException {
		log.info("New Scan Entire Site Page");
		
		//Utility.waitUntilElementDissAppears(PageElements.PAGE_LOADING_CHECK);
		if(!Utility.isElementPresent(PageElements.LAUNCH_NEW_SCAN_DIALOG_VERIFY))
		{
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Launch New Scan dialog");
		}
		
	}

	public NewScanEntireSiteDialog typeScanTitle(String title) throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.SCAN_TITLE_TEXT_AREA);
		Utility.typeInEditBox(PageElements.SCAN_TITLE_TEXT_AREA, title);
		return this;
	}

	
	public NewScanEntireSiteDialog selectScanTitleFromDopDown(String scanTitle) throws InterruptedException {
		if (!scanTitle.equalsIgnoreCase("none")) {
		
			try {
				Utility.click(PageElements.SCAN_TITLE_DROP_DOWN_ARROW_TRIGGER);
				log.info("Clicking on  Element SCAN_TITLE_DROP_DOWN_ARROW_TRIGGER");
			} catch (Exception e) {
				log.error("Error while Clicking on SCAN_TITLE_DROP_DOWN_ARROW_TRIGGER");
				e.printStackTrace();
			}

			try {
				Utility.waitForElementPresent(PageElements.SCAN_TITLE_DROP_DOWN_CONTAINER);
				log.info("Waiting for Element Element TAGS_COMBO_DOWN_CONTAINER");

			} catch (Exception e) {
				log.error("Error while waiting for SCAN_TITLE_DROP_DOWN_CONTAINER");
				e.printStackTrace();
			}

			WebElement superElement = Utility.getElement(PageElements.SCAN_TITLE_DROP_DOWN_CONTAINER);
			Thread.sleep(100);
			if (!superElement.getText().equals("")) {
				try {
					Utility.waitForElementPresent(PageElements.SCAN_TITLE_DROP_DOWN_CONTAINER_ITEMS);
					log.info("Waiting for Element Element SCAN_TITLE_DROP_DOWN_CONTAINER_ITEMS");

				} catch (Exception e) {
					log.error("Error while waiting for SCAN_TITLE_DROP_DOWN_CONTAINER_ITEMS");
					e.printStackTrace();
				}
				
					try {
						
						Utility.selectFromCombo(PageElements.SCAN_TITLE_DROP_DOWN_CONTAINER_ITEMS, superElement, scanTitle);
						log.info("Selecting and double clicking on  SCAN_TITLE_DROP_DOWN_CONTAINER_ITEMS - " + scanTitle);
					} catch (Exception e) {
						log.error("Error while selecting  SCAN_TITLE_DROP_DOWN_CONTAINER_ITEMS - " + scanTitle);
						e.printStackTrace();
					}

				

				return this;
			} else {
				log.warn("User do not have any scan Titles to select");
				return this;
			}
		} else {
			log.info("scan Title = " + scanTitle + " so not selecting any tags");
			return this;
		}
	}
	
	
	public TargetPageStep goToTargetStep() throws ElementNotFoundException {
		Utility.click(PageElements.TARGET_STEP);
		return new TargetPageStep();
	}

	public ReviewAndConfirmStepScanLaunch goToReviewAndConfim() throws ElementNotFoundException {
		Utility.click(DialogCommonElements.CONTINUE_BTN);
		return new ReviewAndConfirmStepScanLaunch();
	}

	public void verifySideBarStepsStaticText() {

		CustomVerification customVerification = new CustomVerification();
		customVerification.verifyEquals("New scan entire site dialog TARGET_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.TARGET_SIDEBAR_STEP_LABEL), "Target");
		customVerification.verifyEquals("New scan entire site dialog REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL  ", Utility.getTextOfPageObject(PageElements.REVIEW_AND_CONFIRM_SIDEBAR_STEP_LABEL),
				"Review and Confirm");

		customVerification.verifyEquals("New scan entire site dialog TARGET_SIDEBAR_STEP_NUMBER_LABEL  ", Utility.getTextOfPageObject(PageElements.TARGET_SIDEBAR_STEP_NUMBER_LABEL), "1");
		customVerification.verifyEquals("New scan entire site dialog REVIEW_AND_CONFIRM_SIDEBAR_STEP_NUMBER_LABEL  ",
				Utility.getTextOfPageObject(PageElements.REVIEW_AND_CONFIRM_SIDEBAR_STEP_NUMBER_LABEL), "2");

	}
}
