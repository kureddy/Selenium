package com.qualys.selenium.mds.dataobject;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(of = { "note", "title", "url", "chooseTag", "maxPages", "chooseIntensity", "headers", "urlWL", "regExpWL", "urlBL", "regExpBL", "enableSchedule", "chooseRecurrenceMode", "enableRecurrenceEndsAfter", "recurrenceOccurrences", "every_X_Days",
		"every_X_Weeks", "enableXDayXOfEveryMonth", "enableXDayofXWeekXthMonth", "recurrenceOnDays", "daysInNumber", "monthNumberA", "dayNumberInWords", "dayName", "monthNumberB", "chooseDate", "chooseTime", "chooseTimeZone","addSiteOrScan" })

public class AddSiteData {
	public String note;
	public String title;
	public String url;
	public String chooseTag;
	public String maxPages;
	public String chooseIntensity;
	public String headers;
	public String urlWL;
	public String regExpWL;
	public String urlBL;
	public String regExpBL;
	public String enableSchedule;
	public String chooseRecurrenceMode;
	public String enableRecurrenceEndsAfter;
	public String recurrenceOccurrences;
	public String every_X_Days;
	public String every_X_Weeks;
	public String enableXDayXOfEveryMonth;
	public String enableXDayofXWeekXthMonth;
	public String recurrenceOnDays;
	public String daysInNumber;
	public String monthNumberA;
	public String dayNumberInWords;
	public String dayName;
	public String monthNumberB;
	public String chooseDate;
	public String chooseTime;
	public String chooseTimeZone;
	public String addSiteOrScan;

}
