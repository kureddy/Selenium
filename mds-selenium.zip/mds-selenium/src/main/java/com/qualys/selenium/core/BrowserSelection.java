/**
 * This class will initialize WebDriver with all browser drivers and provides methods to close browser after tests are executed
 * testng framework is being used for this project.
 * 
 * @author Arun Kadari
 * 
 */

package com.qualys.selenium.core;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
@Slf4j
public class BrowserSelection {
	protected WebDriver driver;

	@BeforeClass(alwaysRun = true)
	@Parameters("browser")
	public void launchBrowser(@Optional("chrome") String browser) {

		if (browser.equalsIgnoreCase("Firefox")) {
			FirefoxProfile profile = new FirefoxProfile();
			profile.setEnableNativeEvents(true);
			driver = new FirefoxDriver();
		} else if (browser.equalsIgnoreCase("chrome")) {
			log.info("Launching chrome browser");
			System.setProperty("webdriver.chrome.driver",
					PropertyReader.getConfigProperty("ChromeDriver"));
			driver = new ChromeDriver();
			//driver.manage().window().maximize();
		} else if (browser.equalsIgnoreCase("InternetExplorer")) {
			System.setProperty("webdriver.ie.driver",
					PropertyReader.getConfigProperty("IEDriverServer"));
			DesiredCapabilities capabilities = DesiredCapabilities
					.internetExplorer();
			capabilities
					.setCapability(
							InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
							true);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability("ensureCleanSession", true);
			capabilities.setJavascriptEnabled(true);
			driver = new InternetExplorerDriver(capabilities);
		}

	}

	@AfterClass(alwaysRun = true)
	public void killBrowser() {
		log.info("Closing browser");
		driver.close();
		log.info("Quiting browser");
		driver.quit();
	}
  }
