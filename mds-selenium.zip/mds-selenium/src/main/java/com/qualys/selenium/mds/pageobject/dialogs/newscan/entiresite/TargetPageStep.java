package com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog;

@Slf4j
public class TargetPageStep extends AbstractDialog {

	public enum PageElements implements IPageElement {
		PAGE_LOADING_CHECK(".step-basic"),
		STEP_VERIFY_BEFORE_FILLING(".scan-object-window .step-basic.first-passed:not(first-active)"),
		STEP_VERIFY_AFTER_FILLING(".scan-object-window .step-basic.first-active:not(.first-passed)"),

		TARGET_STEP_HEADER_LABEL(".scan-object-window .q-step-header .object-panel .q-content-header"),
		DEFINITION_HEADER_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//span[contains(text(),'Definition')]", IdentifiedBy.XPATH),
		SCAN_TITLE_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//label[contains(text(),'Scan Title')]", IdentifiedBy.XPATH),
		REQUIRED_FIELDS_NOTICE_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//div[contains(text(),'Required Fields')]", IdentifiedBy.XPATH),
		SITE_TITLE_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//label[contains(text(),'Site Title')]", IdentifiedBy.XPATH),
		SITE_URL_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//label[contains(text(),'Site URL')]", IdentifiedBy.XPATH),
		SCAN_OPTIONS_HEADER_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//span[contains(text(),'Scan options')]", IdentifiedBy.XPATH),
		SCAN_OPTIONS_DESCRIPTION_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//div[contains(text(),'Select maximum pages to be')]", IdentifiedBy.XPATH),
		MAXIMUM_PAGES_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//label[contains(text(),'Maximum Pages')]", IdentifiedBy.XPATH),
		SCAN_INTENSITY_LABEL("//div[contains(@class,'scan-object-window')]//div[1][contains(@class,'q-scroller')]//label[contains(text(),'Scan intensity')]", IdentifiedBy.XPATH),

		// help tips
		TURN_HELP_TIPS_ON_OFF_LABEL(".scan-object-window .q-window-header div.help-on"), // TODO
																							// :
																							// no
																							// such
																							// element
																							// exception
		LAUNCH_HELP_LABEL(".scan-object-window .q-window-header div.launch-help"),

		HELP_TIPS_ON(".scan-object-window .q-window-header div.help-on .help-toggle-on"),
		HELP_TIPS_OFF(".scan-object-window .q-window-header div.help-on .help-toggle-off"),

		SCAN_TITLE(".scan-object-window input[name=scan-name]"),
		// SITE_TITLE_COMBO_DOWN_ARROW_TRIGGER(".scan-object-window div.x-form-field-trigger-wrap>input.malware-domain-combobox+img.x-form-arrow-trigger"),
		SITE_TITLE_COMBO_DOWN_ARROW_TRIGGER(".q-step-content div:nth-of-type(2)[class*=section-edit-panel] .section-panel-bwrap div[class*=item]:nth-of-type(2) img"),
		SITE_TITLE_COMBO_DOWN_CONTAINER(".combobox .x-combo-list-inner"),
		SITE_TITLE_COMBO_DOWN_CONTAINER_ITEMS(".combobox-item"),
		SITE_TITLE_COMBO("input[name=malware-domain]"),
		SITE_TITLE_COMBO_ERROR_MSG("input[name=malware-domain].x-form-invalid"),

		SITE_URL_DISABLED(".q-step-content div:nth-of-type(2)[class*=section-edit-panel] .section-panel-bwrap div[class*=item]:nth-of-type(3) input[name=url]"),

		MAX_PAGES("input[name=max-pages]"),

		SCAN_INTENSITY_COMBO_BOX("input[name=scanIntensity]"),
		SCAN_INTENSITY_MAXMIMUM("div.x-combo-list-item:nth-child(1)"),
		SCAN_INTENSITY_HIGH("div.x-combo-list-item:nth-child(2)"),
		SCAN_INTENSITY_MEDIUM("div.x-combo-list-item:nth-child(3)"),
		SCAN_INTENSITY_LOW("div.x-combo-list-item:nth-child(4)"),
		SCAN_INTENSITY_MINIMUM("div.x-combo-list-item:nth-child(5)"),

		COMBO_LIST_ELEMENTS_CONTAINER(".combobox .x-combo-list-inner"),
		SITE_COMBO_SITE_TITLE(".combobox-item .title");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}

	public TargetPageStep() throws ElementNotFoundException{
		
		Utility.waitForElementPresent(PageElements.PAGE_LOADING_CHECK);
		if (Utility.waitForElementPresent(PageElements.STEP_VERIFY_AFTER_FILLING) == null) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the New Scan Entire site  > Target stept page");
		}
	}

	
	public TargetPageStep typeTargetScanTitle(String scanTitleName) {
		Utility.typeInEditBox(PageElements.SCAN_TITLE, scanTitleName);
		return this;
	}

	public TargetPageStep selectTargetSiteTitle(String siteTitleName) throws ElementNotFoundException{

		// TODO: should remove these but for now tests are failing
		Utility.waitForElementPresent(PageElements.SITE_TITLE_COMBO_ERROR_MSG);
		Utility.typeInEditBox(PageElements.SITE_TITLE_COMBO, siteTitleName);
		// Utility.click(PageElements.SITE_TITLE_COMBO_DOWN_ARROW_TRIGGER);

		WebElement comboElementsContainer = Utility.waitForElementPresent(PageElements.COMBO_LIST_ELEMENTS_CONTAINER);
		Utility.waitForElementPresent(PageElements.SITE_COMBO_SITE_TITLE);
		Utility.selectFromCombo(PageElements.SITE_COMBO_SITE_TITLE, comboElementsContainer, siteTitleName);

		return this;

	}

	public TargetPageStep clickSiteTitleDropDown() throws ElementNotFoundException{
		Utility.waitForElementPresent(PageElements.SITE_TITLE_COMBO_ERROR_MSG);
		Utility.click(PageElements.SITE_TITLE_COMBO_DOWN_ARROW_TRIGGER);
		return this;
	}

	public List<String> getSiteTitleDL() {
		return Utility.getDL(PageElements.SITE_TITLE_COMBO_DOWN_CONTAINER.getLocator());

	}

	public String getSiteURLAttribute() {
		return Utility.getDisabledAttribute(PageElements.SITE_URL_DISABLED, "disabled");

	}

	public TargetPageStep typeTargetMaximumPages(String numberOfPages) throws ElementNotFoundException{
		Utility.waitForElementPresent(PageElements.MAX_PAGES);
		Utility.typeInEditBox(PageElements.MAX_PAGES, numberOfPages);
		return this;
	}

	public TargetPageStep selectTargetScanIntensity(String intensityLevel) throws ElementNotFoundException{
		Utility.click(PageElements.SCAN_INTENSITY_COMBO_BOX);

		Utility.waitForElementPresent(PageElements.SCAN_INTENSITY_MAXMIMUM);
		if (intensityLevel.equalsIgnoreCase("Maximum")) {
			Utility.click(PageElements.SCAN_INTENSITY_MAXMIMUM);
		} else if (intensityLevel.equalsIgnoreCase("High")) {
			Utility.click(PageElements.SCAN_INTENSITY_HIGH);
		} else if (intensityLevel.equalsIgnoreCase("Medium")) {
			Utility.click(PageElements.SCAN_INTENSITY_MEDIUM);
		} else if (intensityLevel.equalsIgnoreCase("Low")) {
			Utility.click(PageElements.SCAN_INTENSITY_LOW);
		} else if (intensityLevel.equalsIgnoreCase("Minimum")) {
			Utility.click(PageElements.SCAN_INTENSITY_MINIMUM);
		}
		return this;
	}

	public ReviewAndConfirmStepScanLaunch clickContinue() throws ElementNotFoundException{
		Utility.click(DialogCommonElements.CONTINUE_BTN);
		log.info("clicking on continue button of Target page");
		return new ReviewAndConfirmStepScanLaunch();
	}

	// TODO--> Can return to Dashboard/scans/assets
	public DashboardPage clickCancel() throws ElementNotFoundException{
		Utility.click(DialogCommonElements.CANCEL_BTN);
		return new DashboardPage();
	}

	public TargetPageStep verifyTargetStepStaticText() {
		CustomVerification customVerification = new CustomVerification();

		// customVerification.verifyEquals("Target step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help ");
		// //TODO : no such element exception
		customVerification.verifyEquals("Target step LAUNCH_HELP_", Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL), "Launch help");

		customVerification.verifyEquals("Target step  TARGET_STEP_STEP_HEADER_LABEL   ", Utility.getTextOfPageObject(PageElements.TARGET_STEP_HEADER_LABEL),
				"Provide a title for your scan and set scan options");
		customVerification.verifyEquals("Target step  DEFINITION_HEADER_LABEL    ", Utility.getTextOfPageObject(PageElements.DEFINITION_HEADER_LABEL), "Definition");
		customVerification.verifyEquals("Target step  REQUIRED_FIELDS_NOTICE_LABEL   ", Utility.getTextOfPageObject(PageElements.REQUIRED_FIELDS_NOTICE_LABEL), "(*) REQUIRED FIELDS");
		customVerification.verifyEquals("Target step  SCAN_TITLE_LABEL   ", Utility.getTextOfPageObject(PageElements.SCAN_TITLE_LABEL), "Scan Title*");
		customVerification.verifyEquals("Target step  SITE_TITLE_LABEL    ", Utility.getTextOfPageObject(PageElements.SITE_TITLE_LABEL), "Site Title*");
		customVerification.verifyEquals("Target step  SITE_URL_LABEL    ", Utility.getTextOfPageObject(PageElements.SITE_URL_LABEL), "Site URL");

		customVerification.verifyEquals("Target step  SCAN_OPTIONS_HEADER_LABEL    ", Utility.getTextOfPageObject(PageElements.SCAN_OPTIONS_HEADER_LABEL), "Scan options");
		customVerification.verifyEquals("Target step  SCAN_OPTIONS_DESCRIPTION_LABEL    ", Utility.getTextOfPageObject(PageElements.SCAN_OPTIONS_DESCRIPTION_LABEL),
				"Select maximum pages to be scanned and scan intensity.");
		customVerification.verifyEquals("Target step  MAXIMUM_PAGES_LABEL    ", Utility.getTextOfPageObject(PageElements.MAXIMUM_PAGES_LABEL), "Maximum Pages*");
		customVerification.verifyEquals("Target step  SCAN_INTENSITY_LABEL    ", Utility.getTextOfPageObject(PageElements.SCAN_INTENSITY_LABEL), "Scan intensity*");

		customVerification.verifyEquals("Target step  CONTINUE_BTN    ", Utility.getTextOfPageObject(DialogCommonElements.CONTINUE_BTN), "Continue");
		customVerification.verifyEquals("Target step  CANCEL_BTN   ", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN), "Cancel");

		return this;

	}
}