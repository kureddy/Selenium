package com.qualys.selenium.mds.permissions;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.JDBConnection;
import com.qualys.selenium.mds.dataobject.UserData;

@Slf4j
public class QueryDB {

	public static UserData getUserPermission(String username) {
		UserData userData = new UserData(username);
		// 1. User Account Info
		String sql = "select ID,QG_ACCOUNT_ID, USERNAME,CUSTOMER_ID,FIRST_NAME,LAST_NAME,ACCESS_ALL_ASSETS,IS_SUPERUSER from grc.user_local where username='" + username + "'";
		ResultSet userLocal = JDBConnection.getResultSet(sql);
		try {
			if (userLocal.next()) {
				userData.setUserId(String.valueOf(userLocal.getInt("ID")));
				userData.setQGAccountID(String.valueOf(userLocal.getInt("QG_ACCOUNT_ID")));
				userData.setUserName(userLocal.getString("USERNAME"));
				userData.setCustomerId(String.valueOf(userLocal.getInt("CUSTOMER_ID")));
				userData.setFirstName(userLocal.getString("FIRST_NAME"));
				userData.setLastName(userLocal.getString("LAST_NAME"));
				userData.setCanAccessAllAssets(userLocal.getInt("ACCESS_ALL_ASSETS"));
				userData.setIsSuperUser(userLocal.getInt("IS_SUPERUSER"));
			}
		} catch (SQLException e) {
			log.error("Error: {}", e);
		}
		// 2. if not a super user, read the permissions
		if (userData.getIsSuperUser() == 0) {
			ArrayList<String> permissions = new ArrayList<String>();
			sql = "select  distinct a.permission_name as name from grc.security_permission a,grc.security_role_permission b,grc.user_security_role c "
					+ "where b.security_permission_id=a.id and b.security_role_id=c.security_role_id and c.user_id=" + userData.getUserId();
			ResultSet userPermission = JDBConnection.getResultSet(sql);
			try {
				while (userPermission.next()) {
					permissions.add(userPermission.getString("name"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			userData.setPermissions(permissions);
			userData.setProducts(getCustomerProducts(userData.getCustomerId()));
		} else {
			userData.setProducts(getCustomerProducts(userData.getCustomerId()));
		}

		JDBConnection.stopDB();
		return userData;
	}

	public static List<String> getCustomerProducts(String customerId) {
		List<String> products = new ArrayList<String>();
		String sql = "select p.UPC from grc.product p inner join grc.customer_product c on p.ID=c.PRODUCT_ID where c.CUSTOMER_ID=" + customerId;
		ResultSet userProduct = JDBConnection.getResultSet(sql);
		try {
			while (userProduct.next()) {
				products.add(userProduct.getString("UPC"));
			}
		} catch (SQLException e) {
			log.error("Error: {}", e);
		}
		return products;
	}

	public static List<String> executeQuery(String query, String columnName) {
		List<String> queryOutPut = new ArrayList<String>();
		ResultSet rs = JDBConnection.getResultSet(query);
		try {
			while (rs.next()) {
				queryOutPut.add(rs.getString(columnName));
			}
		} catch (SQLException e) {
			log.error("Error: {}", e);

		}
		return queryOutPut;
	}
}
