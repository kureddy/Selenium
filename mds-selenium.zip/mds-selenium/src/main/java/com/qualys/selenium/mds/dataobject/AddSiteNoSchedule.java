package com.qualys.selenium.mds.dataobject;
import lombok.Data;
import lombok.ToString;

@Data
@ToString(of = { "note", "title", "url", "chooseTag", "maxPages", "chooseIntensity", "headers", "urlWL", "regExpWL", "urlBL", "regExpBL", "comments" })

public class AddSiteNoSchedule {
	
	public String note;
	public String title;
	public String url;
	public String chooseTag;
	public String maxPages;
	public String chooseIntensity;
	public String headers;
	public String urlWL;
	public String regExpWL;
	public String urlBL;
	public String regExpBL;
	public String comments;

}
