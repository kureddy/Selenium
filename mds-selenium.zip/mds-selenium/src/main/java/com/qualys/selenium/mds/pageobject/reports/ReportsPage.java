package com.qualys.selenium.mds.pageobject.reports;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.dialogs.reports.NewReport;

@Slf4j
public class ReportsPage extends MalwarePage {

	public enum PageElements implements IPageElement {

		REPORTS_PAGE_VERIFY("#reporting:not(.x-hide-display)"),
		NEW_REPORT_TAB("#reporting .section-tabs-wrap div[ref=datalist-new-report]"),
		REPORT_LIST_TAB("#reporting .section-tabs-wrap div[ref=datalist-reports]"),
		SCANS_REPORT_TAB("//div[contains(@class,'section-tabs-wrap')]//div[contains(@class,'section-tabs-tab') and contains(@class,'report-tab') and contains(@ref,'report-scan')]", IdentifiedBy.XPATH),
		SITE_REPORT_TAB(""),
		SUMMERY_REPORT_TAB("");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public ReportsPage() throws ElementNotFoundException {
		super(MalwareLandingPage.REPORTS);
		
	}
		// go to each tab on Reports module in MDS(Scan List,Detections,Schedules)

	public ReportListTab goToReportList() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.REPORT_LIST_TAB);
		Utility.click(PageElements.REPORT_LIST_TAB);
		
		log.info("Landed on Reports List tab");
		return new ReportListTab();
	}

	public NewReport goToNewReport() throws ElementNotFoundException {
		
		Utility.getElement(PageElements.NEW_REPORT_TAB).click();
		
		return new NewReport();
	}

}
