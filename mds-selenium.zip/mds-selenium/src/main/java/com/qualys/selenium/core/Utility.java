/**
 * This Utility class provides all static methods find web elements, sleep, reading files etc
 * 
 * @author Udaya Kondapalli
 * 
 */
package com.qualys.selenium.core;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.google.common.base.Function;
import com.qualys.selenium.customexceptions.ElementNotFoundException;

@Slf4j
public class Utility {
	public static WebDriver driver;

	public interface IPageElement {
		String getLocator();

		IdentifiedBy getIdentifiedBy();
	}

	public enum IdentifiedBy {
		CSS,
		TAGNAME,
		ID,
		XPATH,
		LINKTEXT,
		NAME
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public interface IPermissionService {
		String getPermission();
	}

	/*
	 * public static WebElement getObjectByKey1(String cssKey){ return
	 * driver.findElement(By.cssSelector(PropertyReader.getORProperty(cssKey)));
	 * }
	 */
	public static void gotoURL(String appURL) {
		driver.get(PropertyReader.getConfigProperty(appURL));
	}

	public static String getDate() {
		DateFormat dateFormat = new SimpleDateFormat();
		Date date = new Date();
		return dateFormat.format(date);
	}

	public static long getTime() {
		// SimpleDateFormat df = new
		// SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");
		Date date = new Date();

		long epoch = date.getTime();
		return epoch;
	}

	public static String getUUID() {
		final String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		System.out.println("uuid = " + uuid);
		return uuid;
	}

	private static List<WebElement> getAllObjectsByKey(String locator, IdentifiedBy identifyBy, WebElement superElement) {

		try {
			switch (identifyBy) {
			case CSS:
				return superElement.findElements(By.cssSelector(locator));

			case ID:
				return superElement.findElements(By.id(locator));
			case LINKTEXT:
				return superElement.findElements(By.linkText(locator));
			case TAGNAME:
				return superElement.findElements(By.tagName(locator));
			case XPATH:
				return superElement.findElements(By.xpath(locator));
			case NAME:
				return superElement.findElements(By.name(locator));
			default:
				return null;
			}
		} catch (NoSuchElementException e) {
			Reporter.log("Object with CSS Key \'" + locator + "\' not found ");
			log.error("Error : {}" + e);
			throw e;
		}

	}

	private static List<WebElement> getAllObjectsByKey(String locator, IdentifiedBy identifyBy) {

		try {
			switch (identifyBy) {
			case CSS:
				return driver.findElements(By.cssSelector(locator));
			case ID:
				return driver.findElements(By.id(locator));
			case LINKTEXT:
				return driver.findElements(By.linkText(locator));
			case TAGNAME:
				return driver.findElements(By.tagName(locator));
			case XPATH:
				return driver.findElements(By.xpath(locator));
			case NAME:
				return driver.findElements(By.name(locator));
			default:
				return null;
			}
		} catch (NoSuchElementException e) {
			Reporter.log("Object with CSS Key \'" + locator + "\' not found ");
			log.error("Error : {}" + e);
			throw e;
		}

	}

	/*
	 * public static boolean isElementPresent(String locator, IdentifiedBy
	 * identifyBy) { WebElement webElement = getElement(locator, identifyBy); if
	 * (webElement != null && webElement.isDisplayed()) { return true; } else {
	 * return false; } }
	 */

	private static boolean isElementPresent(String locator, IdentifiedBy identifyBy) {
		try {
			Utility.waitForElementPresent(locator, identifyBy);
			return true;
		} catch (ElementNotFoundException e) {
			e.logException("Exception while check if element present");
			return false;
		}
	}

	public static boolean isElementPresent(IPageElement iPageElement) {

		return isElementPresent(iPageElement.getLocator(), iPageElement.getIdentifiedBy());

	}

	private static boolean isElementNotPresent(String locator, IdentifiedBy identifyBy) {
		boolean present = false;
		for (int sec = 0; sec <= 60; sec++) {
			if (sec >= 5) {
				break;
			}
			if (!isVisible(locator, identifyBy)) {
				present = true;
				break;
			}
		}
		return present;
	}

	private static boolean isVisible(String locator, IdentifiedBy identifyBy) {
		WebElement element = getElement(locator, identifyBy);
		boolean value = false;
		if (isElementNotPresent(locator, identifyBy)) {
			value = element.isDisplayed();
		}
		return value;
	}

	public static WebElement getElement(String locator, IdentifiedBy identifyBy) {
		switch (identifyBy) {
		case CSS:
			return Utility.getObjectByCSSKey(locator);
		case ID:
			return Utility.getObjectByID(locator);
		case LINKTEXT:
			return Utility.getObjectByLink(locator);
		case TAGNAME:
			return Utility.getObjectByTagName(locator);
		case XPATH:
			return Utility.getObjectByXpath(locator);
		case NAME:
			return Utility.getObjectByString(locator);
		default:
			return null;
		}
	}

	private static ExpectedCondition<Boolean> getInvisibilityOfElement(String locator, IdentifiedBy identifyBy) {
		switch (identifyBy) {
		case CSS:
			return Utility.invisibilityOfElementBycssSKey(locator);
		case ID:
			return Utility.invisibilityOfElementByXPATHSKey(locator);
		case LINKTEXT:
			return Utility.invisibilityOfElementByLinkKey(locator);
		case TAGNAME:
			return Utility.invisibilityOfElementByNameKey(locator);
		case XPATH:
			return Utility.invisibilityOfElementByTagNameKey(locator);
		case NAME:
			return Utility.invisibilityOfElementByIdKey(locator);
		default:
			return null;
		}
	}

	public static void switchToDialog() {
		String handler = driver.getWindowHandle();
		driver.switchTo().window(handler);

	}

	public static WebElement getElement(IPageElement ipageElement) {
		return getElement(ipageElement.getLocator(), ipageElement.getIdentifiedBy());
	}

	private static void click(String locator, IdentifiedBy identifyBy) {
		WebElement webElement = getElement(locator, identifyBy);
		if (webElement == null) {
			throw new RuntimeException("No Element found");
		}
		webElement.click();
	}

	public static void click(IPageElement iPageElement) {

		try {
			click(iPageElement.getLocator(), iPageElement.getIdentifiedBy());
			log.info("Clicking on " + iPageElement);
		} catch (Exception e) {
			Reporter.log(iPageElement + "\' not found ");
			log.error("Error : {}", e);
			e.printStackTrace();
		}
	}

	private static void moveToElement(String locator, IdentifiedBy identifyBy) {
		Actions builder = new Actions(driver);
		WebElement webElement = getElement(locator, identifyBy);
		if (webElement == null) {
			throw new RuntimeException("No Element found");
		}
		builder.moveToElement(webElement).build().perform();
	}

	public static void moveToElement(IPageElement iPageElement) {

		moveToElement(iPageElement.getLocator(), iPageElement.getIdentifiedBy());
	}

	private static void moveToElementAndClick(String locator, IdentifiedBy identifyBy) {
		Actions builder = new Actions(driver);
		WebElement webElement = getElement(locator, identifyBy);
		if (webElement == null) {
			throw new RuntimeException("No Element found");
		}
		builder.moveToElement(webElement);
		builder.click().build().perform();
	}

	public static void moveToElementAndClick(IPageElement iPageElement) {
		moveToElementAndClick(iPageElement.getLocator(), iPageElement.getIdentifiedBy());
	}

	private static void typeInEditBox(String locator, IdentifiedBy identifyBy, String valueToType) {
		WebElement webElement = getElement(locator, identifyBy);
		if (webElement == null) {
			throw new RuntimeException("No Element found");
		} else {
			webElement.click();

			if (!webElement.getAttribute("value").equalsIgnoreCase("")) {
				webElement.clear();

				if (!webElement.getAttribute("value").equalsIgnoreCase("")) {
					System.out.println(webElement.getAttribute("value"));
					webElement.clear();
					webElement.click();
					webElement.sendKeys(valueToType);
					// ((JavascriptExecutor)driver).executeScript("arguments[0].value = arguments[1];",
					// webElement, valueToType);
				} else {
					webElement.click();
					webElement.sendKeys(valueToType);
					// ((JavascriptExecutor)driver).executeScript("arguments[0].value = arguments[1];",
					// webElement, valueToType);
				}

			} else {
				webElement.click();
				webElement.sendKeys(valueToType);
				// ((JavascriptExecutor)driver).executeScript("arguments[0].value = arguments[1];",
				// webElement, valueToType);
			}
		}

	}

	public static void typeInEditBox(IPageElement iPageElement, String value) {
		try {
			typeInEditBox(iPageElement.getLocator(), iPageElement.getIdentifiedBy(), value);
			// log.info("Typing in " + iPageElement);
		} catch (Exception e) {

			Reporter.log(iPageElement + "\' not found ");
			log.error("Could not type in edit box. Given value is : " + value);
		}

	}

	public static String getDisabledAttribute(String locator, IdentifiedBy identifyBy, String valueToType) {
		WebElement webElement = getElement(locator, identifyBy);
		return webElement.getAttribute(valueToType);
	}

	public static String getDisabledAttribute(IPageElement iPageElement, String value) {
		return getDisabledAttribute(iPageElement.getLocator(), iPageElement.getIdentifiedBy(), value);

	}

	private static void selectCheckBox(String locator, IdentifiedBy identifyBy) {
		WebElement webElement = getElement(locator, identifyBy);
		if (webElement == null) {
			throw new RuntimeException("No Element found");
		}
		if (!webElement.isSelected()) {
			webElement.click();
			log.info("Clicking on detections checkbox ");
		}
	}

	public static void selectCheckBox(IPageElement iPageElement) {
		selectCheckBox(iPageElement.getLocator(), iPageElement.getIdentifiedBy());
	}

	private static void selectRadioButton(String locator, IdentifiedBy identifyBy) {
		WebElement webElement = getElement(locator, identifyBy);
		if (webElement == null) {
			throw new RuntimeException("No Element found");
		}
		webElement.click();
	}

	public static void selectRadioButton(IPageElement iPageElement) {
		selectRadioButton(iPageElement.getLocator(), iPageElement.getIdentifiedBy());
	}

	private static boolean isRadioButtonSelected(String locator, IdentifiedBy identifyBy) {
		WebElement webElement = getElement(locator, identifyBy);
		boolean isSelected = false;
		if (webElement == null) {
			throw new RuntimeException("No Element found");
		}
		if (!webElement.isSelected()) {
			isSelected = false;
		} else if (webElement.isSelected()) {
			isSelected = true;
		} else {
			log.info("Some thing is wrong near radio button");
		}
		return isSelected;
	}

	public static boolean isRadioButtonSelected(IPageElement iPageElement) {
		return isRadioButtonSelected(iPageElement.getLocator(), iPageElement.getIdentifiedBy());
	}

	private static void selectFromCombo(String locator, IdentifiedBy identifyBy, WebElement superElement, String requiredValue) {
		List<WebElement> resultList = getAllObjectsByKey(locator, identifyBy, superElement);

		for (int i = 0; i < resultList.size(); i++) {
			System.out.println(resultList.get(i).getText());
			// System.out.printf("%s : %s \n ",resultList.get(i).getText(),requiredValue);
			if (resultList.get(i).getText().equalsIgnoreCase(requiredValue)) {
				resultList.get(i).click();
				i = resultList.size();
			}
		}

	}

	public static void selectFromCombo(IPageElement iPageElement, WebElement comboContainer, String value) {
		selectFromCombo(iPageElement.getLocator(), iPageElement.getIdentifiedBy(), comboContainer, value);
	}

	public static boolean selectMultipleValuesDoubleClick(IPageElement iPageElement, WebElement comboContainer, String value) {
		return selectMultipleValuesDoubleClick(iPageElement.getLocator(), iPageElement.getIdentifiedBy(), comboContainer, value);
	}

	private static boolean selectMultipleValuesDoubleClick(String locator, IdentifiedBy identifyBy, WebElement comboContainer, String value) {
		boolean valueAvailable = false;
		List<WebElement> resultList = getAllObjectsByKey(locator, identifyBy, comboContainer);

		for (int i = 0; i < resultList.size(); i++) {

			if (resultList.get(i).getText().toLowerCase().contains(value.toLowerCase())) {
				Actions action = new Actions(driver);
				action.doubleClick(resultList.get(i));
				action.perform();
				i = resultList.size();
				valueAvailable = true;

			}
		}
		return valueAvailable;
	}

	private static String selectLeftPanelRecordFilterGetText(String locatorOfURL, IdentifiedBy identifyByOFURL, String locatorOfScansPerformed, IdentifiedBy identifyByOFScansPerformed,
			WebElement superElement, String requiredValue) {
		List<WebElement> resultURL = getAllObjectsByKey(locatorOfURL, identifyByOFURL, superElement);

		List<WebElement> resultScansPerformed = getAllObjectsByKey(locatorOfScansPerformed, identifyByOFScansPerformed, superElement);
		String value = "";
		int temp = 0;
		for (int searchURL = 0; searchURL < resultURL.size(); searchURL++) {
			if (resultURL.get(searchURL).getText().equalsIgnoreCase(requiredValue)) {
				temp = searchURL;
				searchURL = resultURL.size();
			}
			if (searchURL == resultURL.size()) {
				value = resultScansPerformed.get(temp).getText();
			}

		}
		return value;
	}

	public static String selectLeftPanelRecordFilterGetText(IPageElement ipageElementOfURL, IPageElement IPageElementOfScansPerformed, WebElement superElement, String requiredValue) {
		return selectLeftPanelRecordFilterGetText(ipageElementOfURL.getLocator(), ipageElementOfURL.getIdentifiedBy(), IPageElementOfScansPerformed.getLocator(),
				IPageElementOfScansPerformed.getIdentifiedBy(), superElement, requiredValue);

	}

	private static List<WebElement> getRecordWebEements(String locator, IdentifiedBy identifyBy, WebElement superElement) {

		List<WebElement> scanTitle = getAllObjectsByKey(locator, identifyBy, superElement);
		return scanTitle;
	}

	public static void selectCheckBoxOfSingleRecord(String locatorOfRecord, IdentifiedBy identifyByRecordName, String locatorOfCheckBox, IdentifiedBy identifyByCheckBox, WebElement superElement,
			String nameOfRecord) {

		List<WebElement> record = getAllObjectsByKey(locatorOfRecord, identifyByRecordName, superElement);

		List<WebElement> elementCheckBox = getAllObjectsByKey(locatorOfCheckBox, identifyByCheckBox);

		int temp = 0;

		for (int searchRecord = 0; searchRecord < record.size(); searchRecord = searchRecord + 1) {
			if (record.get(searchRecord).getText().equalsIgnoreCase(nameOfRecord)) {
				temp = searchRecord;
				searchRecord = record.size();
			}
			if (searchRecord == record.size()) {

				elementCheckBox.get(temp).click();
				temp = elementCheckBox.size();

			}
		}
		if (record.size() == 0) {
			log.info("Could not find any such record in Data List");
		}
	}

	public static List<WebElement> getRecordWebEements(IPageElement ipageElement, WebElement superElement) {

		return getRecordWebEements(ipageElement.getLocator(), ipageElement.getIdentifiedBy(), superElement);
	}

	public static void selectCheckBoxOfSingleRecord(IPageElement ipageElementOfRecord, IPageElement ipageElemenOfCheckBox, WebElement superElement, String nameOfRecord) {
		selectCheckBoxOfSingleRecord(ipageElementOfRecord.getLocator(), ipageElementOfRecord.getIdentifiedBy(), ipageElemenOfCheckBox.getLocator(), ipageElemenOfCheckBox.getIdentifiedBy(),
				superElement, nameOfRecord);
	}

	// Get text of Scan date,number of scanned pages,status,severity
	public static String getTextOfRecordColumn(String locatorOfRecord, IdentifiedBy identifyByRecordName, String locatorOfDescription, IdentifiedBy identifyByDescription, WebElement superElement,
			String nameOfRecord) {

		List<WebElement> record = getAllObjectsByKey(locatorOfRecord, identifyByRecordName, superElement);

		List<WebElement> elementDescription = getAllObjectsByKey(locatorOfDescription, identifyByDescription, superElement);

		String description = "";
		int temp = 0;
		for (int searchRecord = 0; searchRecord < record.size(); searchRecord++) {
			if (record.get(searchRecord).getText().equalsIgnoreCase(nameOfRecord)) {
				temp = searchRecord;
				searchRecord = record.size();
			}
			if (searchRecord == record.size()) {

				description = elementDescription.get(temp).getText();

			}
		}
		return description;

	}

	public static String getTextOfRecordColumn(IPageElement ipageElementOfRecord, IPageElement ipageElementOfDescription, WebElement superElement, String nameOfRecord) {

		return getTextOfRecordColumn(ipageElementOfRecord.getLocator(), ipageElementOfRecord.getIdentifiedBy(), ipageElementOfDescription.getLocator(), ipageElementOfDescription.getIdentifiedBy(),
				superElement, nameOfRecord);
	}

	public static boolean selectQuickActionsOfSingleRecord(String locatorOfRecord, IdentifiedBy identifyByRecordName, String locatorOfQuickActions, IdentifiedBy identifyByQuickActions,
			WebElement superElement, String nameOfRecord) {
		boolean isRecordFound = false;
		List<WebElement> record = getAllObjectsByKey(locatorOfRecord, identifyByRecordName, superElement);
		List<WebElement> elementQuickActions = driver.findElements(By.cssSelector(locatorOfQuickActions));

		int temp = 0;
		for (int searchRecord = 0; searchRecord < record.size(); searchRecord = searchRecord + 1) {
			log.info("searching for " + nameOfRecord);
			if (record.get(searchRecord).getText().equalsIgnoreCase(nameOfRecord)) {
				temp = searchRecord;
				searchRecord = record.size();
			}
			if (searchRecord == record.size()) {
				for (int searchQuickActions = temp; searchQuickActions < elementQuickActions.size(); searchQuickActions++) {
					log.info("Found : " + nameOfRecord);
					long offsetHeight = elementQuickActions.get(searchQuickActions).getSize().height;
					long offsetWidth = elementQuickActions.get(searchQuickActions).getSize().width;

					Actions builderForQuickAction = new Actions(driver);

					builderForQuickAction.moveToElement(elementQuickActions.get(searchQuickActions), Math.round(offsetWidth - 5), Math.round(offsetHeight / 2));
					log.info("Clicking on Quick actions button of :" + nameOfRecord);
					builderForQuickAction.click().build().perform();
					searchQuickActions = elementQuickActions.size();
					isRecordFound = true;

				}
			}
		}
		return isRecordFound;
	}

	public static boolean selectQuickActionsOfSingleRecord(IPageElement ipageElementOfRecord, IPageElement ipageElementOfQuickActions, WebElement superElement, String nameOfRecord) {
		return selectQuickActionsOfSingleRecord(ipageElementOfRecord.getLocator(), ipageElementOfRecord.getIdentifiedBy(), ipageElementOfQuickActions.getLocator(),
				ipageElementOfQuickActions.getIdentifiedBy(), superElement, nameOfRecord);
	}

	private static String getTextOfPageObject(String locator, IdentifiedBy identifyBy) {
		WebElement element = getElement(locator, identifyBy);
		if (element == null) {
			throw new RuntimeException("No Element found");
		}
		return element.getText();
	}
	
	
	private static String getValueOfPageObject(String locator, IdentifiedBy identifyBy) {
		WebElement element = getElement(locator, identifyBy);
		if (element == null) {
			throw new RuntimeException("No Element found");
		}
		return element.getAttribute("value");
	}

	private static WebElement waitForElementPresent(String locator, IdentifiedBy identifyBy) throws ElementNotFoundException {
		switch (identifyBy) {
		case CSS:
			return fluentWaitByCssKey(locator);
		case ID:
			return fluentWaitById(locator);
		case LINKTEXT:
			// TODO : missing link text wait for element
			return null;
		case TAGNAME:
			return fluentWaitByTagName(locator);
		case XPATH:
			return fluentWaitByXPATHKey(locator);
		case NAME:
			return fluentWaitByStringName(locator);
		default:
			return null;
		}
	}

	public static WebElement waitForElementPresent(IPageElement ipPageElement) throws ElementNotFoundException {
		return waitForElementPresent(ipPageElement.getLocator(), ipPageElement.getIdentifiedBy());
	}

	private static void waitUntilElementDissApears(String locator, IdentifiedBy identifyBy) {

		WebDriverWait wait = new WebDriverWait(driver, 60);
		ExpectedCondition<Boolean> invisibleContition = getInvisibilityOfElement(locator, identifyBy);

		wait.until((invisibleContition));
		log.info("waiting for " + locator + "to dissappear");

	}

	public static void waitUntilElementDissAppears(IPageElement iPageElement) {

		waitUntilElementDissApears(iPageElement.getLocator(), iPageElement.getIdentifiedBy());
	}

	public static boolean isElementDissapeard(IPageElement iPageElement) {

		waitUntilElementDissApears(iPageElement.getLocator(), iPageElement.getIdentifiedBy());

		return true;
	}

	public static String getTextOfPageObject(IPageElement ipageElementlocator) {

		return getTextOfPageObject(ipageElementlocator.getLocator(), ipageElementlocator.getIdentifiedBy());

	}

	public static String getValueOfPAgeObject(IPageElement ipageElementlocator) {

		return getValueOfPageObject(ipageElementlocator.getLocator(), ipageElementlocator.getIdentifiedBy());

	}
	
	public static List<String> getDL(String locator) {
		List<WebElement> element = driver.findElements(By.cssSelector(locator));

		List<String> test = new ArrayList<String>();

		for (WebElement e : element) {
			test.add(e.getText());
		}
		return test;

	}

	public static WebElement getObjectByKey(String key) {
		if (key.endsWith("_XPATH")) {
			return getObjectByXpath(key);
		} else if (key.endsWith("_ID")) {
			return getObjectByID(key);
		} else {
			return getObjectByCSSKey(key);
		}
	}

	public WebElement fluentWaitByKey(String key) throws ElementNotFoundException {
		if (key.endsWith("_XPATH")) {
			return fluentWaitByXPATHKey(key);
		} else {
			return fluentWaitByCssKey(key);
		}
	}

	private static WebElement getObjectByCSSKey(String cssKey) {
		try {
			return driver.findElement(By.cssSelector(cssKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with CSS Key \'" + cssKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	private static WebElement getObjectByXpath(String xpathKey) {
		try {
			return driver.findElement(By.xpath(xpathKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + xpathKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	private static WebElement getObjectByLink(String linkText) {
		try {
			return driver.findElement(By.linkText(linkText));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + linkText + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	public static ExpectedCondition<Boolean> invisibilityOfElementBycssSKey(String cssKey) {
		try {
			return ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(cssKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + cssKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	public static ExpectedCondition<Boolean> invisibilityOfElementByXPATHSKey(String xPathKey) {
		try {
			return ExpectedConditions.invisibilityOfElementLocated(By.xpath(xPathKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + xPathKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	public static ExpectedCondition<Boolean> invisibilityOfElementByLinkKey(String linkKey) {
		try {
			return ExpectedConditions.invisibilityOfElementLocated(By.xpath(linkKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + linkKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	public static ExpectedCondition<Boolean> invisibilityOfElementByTagNameKey(String tagNameKey) {
		try {
			return ExpectedConditions.invisibilityOfElementLocated(By.xpath(tagNameKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + tagNameKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	public static ExpectedCondition<Boolean> invisibilityOfElementByIdKey(String idKey) {
		try {
			return ExpectedConditions.invisibilityOfElementLocated(By.xpath(idKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + idKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	public static ExpectedCondition<Boolean> invisibilityOfElementByNameKey(String nameKey) {
		try {
			return ExpectedConditions.invisibilityOfElementLocated(By.xpath(nameKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with XPath Key \'" + nameKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	@SuppressWarnings("unused")
	private static WebElement getObjectByIDKey(String idKey) {
		try {
			return driver.findElement(By.id(idKey));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with ID Key \'" + idKey + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	private static WebElement getObjectByID(String objectId) {
		try {
			return driver.findElement(By.id(objectId));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with id \'" + objectId + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	private static WebElement getObjectByTagName(String tag) {
		try {
			return driver.findElement(By.tagName(tag));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with Tag Name \'" + tag + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	private static WebElement getObjectByString(String StringName) {
		try {
			return driver.findElement(By.linkText(StringName));
		} catch (NoSuchElementException e) {
			Reporter.log("Object with S Name \'" + StringName + "\' not found ");
			log.error("Error : {}", e);
			throw e;
		}
	}

	public static WebElement getSafeObjectByCSSKey(String cssKey) {

		WebElement myDynamicElement = (new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssKey)));

		// System.out.println("DynamicElement Title :"+myDynamicElement.getText());

		return myDynamicElement;
	}

	/*
	 * public static WebElement getSafeObjectByCSSKey(String cssKey) throws
	 * InterruptedException{ int i=0; WebElement element = null; while( i < 5 ){
	 * try{ element =
	 * driver.findElement(By.cssSelector(PropertyReader.getORProperty(cssKey)));
	 * break; }catch (Exception e){ Thread.sleep(2000); i++; }
	 * 
	 * } return element; } }
	 */

	public static void mouseHover(String linkText) {
		try {
			WebElement mouse = driver.findElement(By.linkText(linkText));
			Actions builder = new Actions(driver);
			builder.moveToElement(mouse).build().perform();

		} catch (Throwable t) {
			// report error
			t.getStackTrace();

		}
	}

	public static void doubleClickAction(String locator, IdentifiedBy identifyBy) {
		WebElement element;
		Actions actions = new Actions(driver);
		switch (identifyBy) {
		case CSS:
			element = driver.findElement(By.cssSelector(locator));
			actions.doubleClick(element);

		case ID:
			element = driver.findElement(By.cssSelector(locator));
			actions.doubleClick(element);
		case LINKTEXT:
			element = driver.findElement(By.cssSelector(locator));
			actions.doubleClick(element);
		case TAGNAME:
			element = driver.findElement(By.cssSelector(locator));
			actions.doubleClick(element);
			;
		case XPATH:
			element = driver.findElement(By.cssSelector(locator));
			actions.doubleClick(element);
		case NAME:
			element = driver.findElement(By.cssSelector(locator));
			actions.doubleClick(element);
		default:

		}
	}

	public static void sleep(long milliSeconds) {
		try {
			Thread.sleep(milliSeconds);
		} catch (Throwable t) {
			t.getStackTrace();
		}

	}

	public static boolean isIPValid(String ipAddress) {

		final String IP_Pattern = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

		Pattern pattern = Pattern.compile(IP_Pattern);
		Matcher matcher = pattern.matcher(ipAddress);

		return matcher.matches();
	}

	public static WebElement fluentWaitByCssKey(String cssKey) throws ElementNotFoundException {
		return fluentWait(By.cssSelector(cssKey));
	}

	public static WebElement fluentWaitByXPATHKey(String XpathKey) throws ElementNotFoundException {
		return fluentWait(By.xpath(XpathKey));
	}

	public static WebElement fluentWaitById(String Id) throws ElementNotFoundException {
		return fluentWait(By.id(Id));
	}

	public static WebElement fluentWaitByTagName(String tagName) throws ElementNotFoundException {
		return fluentWait(By.tagName(tagName));
	}

	public static WebElement fluentWaitByStringName(String stringName) throws ElementNotFoundException {
		return fluentWait(By.tagName(stringName));
	}

	public static WebElement fluentWait(final By locator) throws ElementNotFoundException {
		try {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS).pollingEvery(1, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class);

			WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
				public WebElement apply(WebDriver driver) {
					return driver.findElement(locator);
				}
			});
			return foo;

		} catch (TimeoutException | NoSuchElementException e) {
			throw new ElementNotFoundException(locator.toString());
		}

	}

	public static String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	/*
	 * public static WebElement showQuickAction(String locatorOfRecord,String
	 * locatorOfQuickActions,IdentifiedBy identifyByRecordName){ WebElement
	 * webElement = getElement(locator, identifyBy);
	 * 
	 * 
	 * long offsetHeight = webElement.getSize().height; long offsetWidth =
	 * webElement.getSize().width; // Now position the mouse on the column.
	 * Actions builderForQuickAction = new Actions(driver);
	 * 
	 * builderForQuickAction.moveToElement(webElement,Math.round(offsetWidth -
	 * 5), Math.round(offsetHeight/2));
	 * builderForQuickAction.click().build().perform();
	 * 
	 * return webElement; }
	 */

}