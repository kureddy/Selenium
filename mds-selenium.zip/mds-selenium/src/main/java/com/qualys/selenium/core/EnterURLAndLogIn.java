package com.qualys.selenium.core;

import org.testng.annotations.BeforeClass;

import com.qualys.selenium.core.pageobject.LoginPage;
import com.qualys.selenium.core.pageobject.WelcomeHomePage;
import com.qualys.selenium.customexceptions.ElementNotFoundException;

public class EnterURLAndLogIn extends BrowserSelection {

	protected LoginPage loginPage;
	protected WelcomeHomePage landingPage;

	@BeforeClass(dependsOnMethods = { "launchBrowser" })
	public void enterURL() throws ElementNotFoundException {
		Utility.driver = driver;
		if (PropertyReader.getConfigProperty("environment").equalsIgnoreCase("pod3")) {
			Utility.gotoURL("appURLPOD3");
			if (driver.getTitle().contains("Certificate Error: Navigation Blocked")) {
				driver.navigate().to("javascript:document.getElementById('overridelink').click()");
			}
			loginPage = new LoginPage();
		} else if (PropertyReader.getConfigProperty("environment").equalsIgnoreCase("pod4")) {
			Utility.gotoURL("appURLPOD4");
			if (driver.getTitle().contains("Certificate Error: Navigation Blocked")) {
				driver.navigate().to("javascript:document.getElementById('overridelink').click()");
			}
			loginPage = new LoginPage();
		}else if(PropertyReader.getConfigProperty("environment").equalsIgnoreCase("platD"))
		{
			Utility.gotoURL("appURLPLATD");
			if (driver.getTitle().contains("Certificate Error: Navigation Blocked")) {
				driver.navigate().to("javascript:document.getElementById('overridelink').click()");
			}
			loginPage = new LoginPage();
		}
	}

	@BeforeClass(dependsOnMethods = { "enterURL" })
	public void testLogin() throws ElementNotFoundException {

		LoginPage loginPage = new LoginPage();
		landingPage = loginPage.portalLogin(PropertyReader.getConfigProperty("environment"));
	}

}
