package com.qualys.selenium.mds.pageobject.assets;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog.AddSiteDialogMode;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite.NewScanEntireSiteDialog;

@Slf4j
public class SitesTab extends AssetsPage {
	int totalRows;
	int rowsInCurrentPage;
	int currentPage;
	

	public enum PageElements implements IPageElement {

		SITES_TAB_VERITY("#assets:not(.x-hide-display) #datalist-sites"),
		PAGE_LOADING_MASKED_VERIFY("#datalist-sites:not(.x-hide-display) .mds-domain-datalist .q-datalist.x-masked .q-datalist-bwrap.x-masked"),
		PAGE_LOADING_NOT_MASKED_VERIFY("#datalist-sites:not(.x-hide-display) .mds-domain-datalist .q-datalist:not(.x-masked) .q-datalist-bwrap:not(.x-masked)"),

		NEW_SCAN_DOWN_BTN("//div[contains(@class,'content-panel')]//button[contains(text(),'New Scan')]", IdentifiedBy.XPATH),
		NEW_SCAN_ENTIRE_SITE("//div[contains(@class,'q-quick-menu')]//span[contains(text(),'Scan Entire Site')]", IdentifiedBy.XPATH),
		NEW_SCAN_SINGLE_PAGE("//div[contains(@class,'q-quick-menu')]//span[contains(text(),'Scan Single Page')]", IdentifiedBy.XPATH),

		ADD_SITE_BTN("//div[@id='datalist-sites']//td//button[contains(text(),'Add Site')]", IdentifiedBy.XPATH),

		NEW_SCHEDULE_BTN("//div[@id='datalist-sites']//td//button[contains(text(),'New Schedule')]", IdentifiedBy.XPATH),

		REFRESH_PAGE_BTN("#datalist-sites:not(.x-hide-display) .x-small-editor .x-toolbar-right .x-tbar-loading"),
		// MDS_AssetsPage_SitesTab_AfterRefreshPage_WaitFor=.content-panel

		FILTER_SETTINGS_DROPDOWN("#datalist-sites:not(.x-hide-display) .x-small-editor .x-toolbar-right .dlist_view_btn"),
		FILTER_SETTINGS_DOWNLOAD(".q_view_menu .x-menu-list li:nth-child(1)"),
		FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]", IdentifiedBy.XPATH),
		SORT_BY_TITLE("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		SORT_BY_SITE_URL("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		SORT_BY_TAGS("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Rows Shown')]", IdentifiedBy.XPATH),
		ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

		PAGING_COMBO_LEFT_BTN("#datalist-sites:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row .first:not(.x-item-disabled)"),
		PAGING_COMBO_RIGHT_BTN("#datalist-sites:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row .last:not(.x-item-disabled)"),
		PAGING_COMBO_CURRENT_RANGE("#assets #datalist-sites .datalist-container .q-datalist-tbar-noheader td[class*=-toolbar-right] tr[class*=-toolbar-right-row] td:nth-of-type(2) input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("#datalist-sites:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER(".x-combo-list"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS(".x-combo-list-item"),

		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM(".x-combo-list .x-combo-list-item:nth-child(1)"),

		LIST_HEADER_SITE_TITLE("#datalist-sites:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-hd-name"),
		LIST_HEADER_SITE_URL("#datalist-sites:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-hd-url"),
		LIST_HEADER_TAGS("#datalist-sites:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-td-tags"),

		ALL_SITES_CHECKBOX("#datalist-sites:not(.x-hide-display) .mds-domain-datalist .q-datalist-body .x-grid3-header table .x-grid3-hd-checker"),

		ITEMS_ALL_ROWS("#datalist-sites:not(.x-hide-display) .mds-domain-datalist .x-grid3-scroller"), // SUPER
																										// ELEMENT
		EACH_SITE_TITLE(".x-grid3-td-name.q-quick-menu-column"), // SUB ELEMENT
		EACH_SITE_SITE_URL(".x-grid3-td-url .x-grid3-col-url"), // SUB ELEMENT
		EACH_SITE_TAGS(".x-grid3-td-tags .x-grid3-col-tags .new-asset-tag-inner"), // SUB
																					// ELEMENT

		/*
		 * EACH_SITE_ROWS(
		 * "#datalist-sites:not(.x-hide-display) .mds-domain-datalist .x-grid3-scroller"
		 * ),//SUPER ELEMENT
		 * EACH_SITE_TITLE(".x-grid3-td-name.q-quick-menu-column"),//SUB ELEMENT
		 * EACH_SITE_SITE_URL(".x-grid3-td-url .x-grid3-col-url"),//SUB ELEMENT
		 * EACH_SITE_TAGS
		 * (".x-grid3-td-tags .x-grid3-col-tags .new-asset-tag-inner"),//SUB
		 * ELEMENT
		 */
		EACH_SITE_CHECKBOX("#datalist-sites:not(.x-hide-display) .mds-domain-datalist .x-grid3-scroller .x-grid3-td-checker.x-grid3-cell-first"),

		ACTIONS_DOWN_BTN("#datalist-sites:not(.x-hide-display) .actionBtn:not(.x-item-disabled)"),
		ACTIONS_DOWN_VIEW("//li[1][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_EDIT("//li[2][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Edit')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_ADD_TAGS("//li[3][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Add Tags')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_SCAN("//li[5][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Scan')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_VIEW_REPORT_ENABLED("/li[7][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View Report')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_VIEW_REPORT_DISABLED("//li[7][contains(@class,'x-item-disabled')]//span[contains(@class,'x-menu-item-text') and contains(text(),'View Report')]", IdentifiedBy.XPATH),

		QUICK_ACTIONS_DOWN_BTN("#datalist-sites:not(.x-hide-display) .q-quick-menu-column"),
		QUICK_ACTIONS_DOWN_QUICK_ACTIONS_LABEL("li.x-menu-list-item:not(.x-item-disabled):nth-child(1) "),
		QUICK_ACTIONS_DOWN_VIEW("li.x-menu-list-item:not(.x-item-disabled):nth-child(2) "),
		QUICK_ACTIONS_DOWN_EDIT("li.x-menu-list-item:not(.x-item-disabled):nth-child(3) "),
		QUICK_ACTIONS_DOWN_ADD_TAGS("li.x-menu-list-item:not(.x-item-disabled):nth-child(4)"),
		QUICK_ACTIONS_DOWN_SCAN("li.x-menu-list-item:not(.x-item-disabled):nth-child(6)"),
		QUICK_ACTIONS_DOWN_VIEW_REPORT_ENABLED("li.x-menu-list-item:not(.x-item-disabled):nth-child(8)"),
		QUICK_ACTIONS_DOWN_VIEW_REPORT_DISABLED("li.x-menu-list-item.x-item-disabled:nth-child(8)"),

		// PENDING TO TEST NAVIGATION
		SHOW_FILTER("#datalist-sites:not(.x-hide-display) .filter-summary-panel .filter-buttons"),
		CLEAR_FILTER("#datalist-sites:not(.x-hide-display) .filter-summary-panel .filter-buttons .clear-filters-link"),
		HIDE_FILTER("#datalist-sites:not(.x-hide-display) .filter-summary-panel .filter-buttons .toggle-filter-link"),
		FILTER_APPLIED_NUMBER("#datalist-sites:not(.x-hide-display) .filter-summary-panel .filter-count span b"),

		FILTER_EXPANDED_SEARCH_TEXT_FIELD("#datalist-sites:not(.x-hide-display) .filter-panel-expanded .filter-panel:not(.x-hide-display) .filter-column-panel-start .filter-hide-label input"),

		FILTER_EXPANDED_TAG_DROPDOWN("#datalist-sites:not(.x-hide-display) .tag-combo-box span>img:last-of-type"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN("div[class='x-layer']>div+div"),

		FILTER_EXPANDED_SITE_TITLE_TEXT_FIELD("#datalist-sites:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(1) input"),
		FILTER_EXPANDED_SITE_URL_TEXT_FIELD("#datalist-sites:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(2) input"),

		FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX("#datalist-sites:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(3) div.x-hide-label input"),
		FILTER_EXPANDED_SITE_TYPE_WAS_CHECKBOX("#datalist-sites:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(3) div.x-hide-label:last-of-type input"),
		FILTER_EXPANDED_SHOW_DEACTIVATED_SITES_CHECKBOX("#datalist-sites:not(.x-hide-display) .filter-column-panel-end .filter-panel-column-body>div:nth-child(4) .x-form-checkbox");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public SitesTab() throws ElementNotFoundException {

		waitForPageUnMasking();
		if (!Utility.isElementPresent(PageElements.SITES_TAB_VERITY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the MDS > Assets page");
		}
	}

	public SitesTab waitForPageMasking() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY);
		return this;
	}

	private SitesTab waitForPageUnMasking() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.PAGE_LOADING_NOT_MASKED_VERIFY);
		return this;

	}

	public AddSiteDialog clickAddSiteBtn() throws ElementNotFoundException, SiteCreationMaxedOutException {
		Utility.waitForElementPresent(PageElements.ADD_SITE_BTN);
		Utility.click(PageElements.ADD_SITE_BTN);
		return new AddSiteDialog(AddSiteDialogMode.CREATE);
	}

	// TODO Passing but not clicking.
	public SitesTab selectAllSitesCheckBox() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.ALL_SITES_CHECKBOX);
		if (Utility.isElementPresent(PageElements.ALL_SITES_CHECKBOX)) {

			Utility.selectCheckBox(PageElements.ALL_SITES_CHECKBOX);

		} else {
			throw new NoSuchElementException("All Sites checkbox is not present");
		}

		return this;
	}

	// TODO Passing but not clinking.
	public SitesTab selectSingleScheduleCheckBox(String assetName) throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);

		Utility.selectCheckBoxOfSingleRecord(PageElements.EACH_SITE_TITLE, PageElements.EACH_SITE_CHECKBOX, superElement, assetName);

		return this;
	}

	public SitesTab clickQuickActionsDropDown(String assetName) throws ElementNotFoundException {

		waitForPageToUnMask();

		Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_BTN);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);

		try {
			int totalRowsInDL = getTotalRows();
			
			int pagination = 0;
			int  currentPageFlag = 0;
			while(currentPageFlag == 0)
			{
				if(!isOnFirstPage())
				{
					clickLeftPagingComboArrowButton();
					
				}else
				{
					currentPageFlag++;
				}
			}
			boolean isSiteTitleFound = false;
			while (pagination <= (totalRowsInDL / 20)) {

				

					isSiteTitleFound = Utility.selectQuickActionsOfSingleRecord(PageElements.EACH_SITE_TITLE, PageElements.QUICK_ACTIONS_DOWN_BTN, superElement, assetName);

					if (isSiteTitleFound) {
						
						pagination = ((totalRowsInDL / 20) + 1);

					} else {
						clickRightPagingComboArrowButton();

						pagination++;
					}
				}

			

		} catch (ElementNotFoundException e) {
			log.info("Scan date was not found");
			Assert.fail(assetName + " assetName was not found");

		}
		return this;
	}

	// TODO return type schedule View dialog
	public SitesTab selectQuickActionsView(String assetName) throws ElementNotFoundException {

		clickQuickActionsDropDown(assetName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW);
		return this;
	}

	public NewScanEntireSiteDialog selectQuickActionsAddTag(String assetName) throws ElementNotFoundException {
		clickQuickActionsDropDown(assetName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_ADD_TAGS);
		return new NewScanEntireSiteDialog();
	}

	public NewScanEntireSiteDialog selectQuickActionsScan(String assetName) throws ElementNotFoundException {

		clickQuickActionsDropDown(assetName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_SCAN);
		return new NewScanEntireSiteDialog();

	}

	public NewScanEntireSiteDialog selectQuickActionsViewReport(String assetName) throws ElementNotFoundException {
		clickQuickActionsDropDown(assetName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW_REPORT_ENABLED);
		return new NewScanEntireSiteDialog();
	}

	public SitesTab refreshScanListPage() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.REFRESH_PAGE_BTN);
		Utility.click(PageElements.REFRESH_PAGE_BTN);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab clickActionsDropDown() {
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_BTN)) {
			Utility.click(PageElements.ACTIONS_DOWN_BTN);
		} else {
			throw new NoSuchElementException("Actions button is either disabled or not present on the page");
		}

		return this;
	}

	public SitesTab selectActionsView() {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_VIEW)) {
			Utility.click(PageElements.ACTIONS_DOWN_VIEW);
		} else {
			throw new NoSuchElementException("Actions>view button is either disabled or not present on the page");
		}

		return this;
	}

	public SitesTab selectActionsEdit() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_EDIT)) {
			Utility.click(PageElements.ACTIONS_DOWN_EDIT);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Edit button is either disabled or not present on the page");
		}
		return this;
	}

	public SitesTab selectActionsAddTags() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_ADD_TAGS)) {
			Utility.click(PageElements.ACTIONS_DOWN_ADD_TAGS);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Add Tags button is either disabled or not present on the page");
		}
		return this;
	}

	public SitesTab selectActionsScan() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_SCAN)) {
			Utility.click(PageElements.ACTIONS_DOWN_SCAN);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Scan button is either disabled or not present on the page");
		}
		return this;
	}

	public SitesTab selectActionsViewReport() throws ElementNotFoundException {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_VIEW_REPORT_ENABLED)) {
			Utility.click(PageElements.ACTIONS_DOWN_VIEW_REPORT_ENABLED);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Actions_ViewReport_Enabled_DropDown_Navigation_XPATH");
		}
		return this;
	}

	public SitesTab clickFilterDropDown() {

		Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
		return this;
	}

	public SitesTab selectFilterDownload() {
		clickFilterDropDown();
		Utility.click(PageElements.FILTER_SETTINGS_DOWNLOAD);
		return this;
	}

	public SitesTab selectFilterSortBy() {

		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);

		return this;
	}

	public SitesTab selectFilterSortByName() throws ElementNotFoundException {

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_TITLE);
		Utility.moveToElementAndClick(PageElements.SORT_BY_TITLE);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab selectFilterSortByPageURL() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_SITE_URL);
		Utility.moveToElementAndClick(PageElements.SORT_BY_SITE_URL);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab selectFilterSortByTags() throws ElementNotFoundException {

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_TAGS);
		Utility.moveToElementAndClick(PageElements.SORT_BY_TAGS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab selectFilterRowsShown() {

		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);
		return this;
	}

	public SitesTab selectFilterRowsShown20() throws ElementNotFoundException {

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab selectFilterRowsShown50() throws ElementNotFoundException {

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab selectFilterRowsShown100() throws ElementNotFoundException {

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab selectFilterRowsShown200() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab sortSiteTitleFromHeader() throws ElementNotFoundException

	{
		Utility.click(PageElements.LIST_HEADER_SITE_TITLE);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab sortSiteURLFromHeader() throws ElementNotFoundException {
		Utility.click(PageElements.LIST_HEADER_SITE_URL);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab sortTagsFromHeader() throws ElementNotFoundException {
		Utility.click(PageElements.LIST_HEADER_TAGS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public SitesTab leftPagingComboArrowButton() throws ElementNotFoundException {
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_LEFT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_LEFT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();

		} else {
			throw new IllegalStateException("Left button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public SitesTab rightPagingComboArrowButton() throws ElementNotFoundException {

		if (Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN) != null) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();

		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public SitesTab clickPagingComboDropDown() {
		Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		return this;
	}

	// need waitforpageload
	public SitesTab selectPagingComboRange(int start, int end) throws ElementNotFoundException {

		clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);
		WebElement superElelemnt = Utility.getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);

		Utility.selectFromCombo(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS, superElelemnt, start + " - " + end + " of " + end);
		System.out.println(start + " - " + end + " of " + end);
		return this;
	}

	/*
	 * public void selectRows() {
	 * 
	 * clickPagingComboDropDown(); waitForPageUnMasking();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_Middle_PagingCombo_FirstRange_Navigation", IdentifiedBy.CSS);
	 * String pageRange = Utility.getTextOfPageObject(
	 * PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_Middle_PagingCombo_FirstRange_Navigation", IdentifiedBy.CSS);
	 * 
	 * String[] splitRange = pageRange.split("\\W"); int totalSites =
	 * Integer.parseInt(splitRange[5]);
	 * 
	 * if (totalSites > 20 && totalSites <= 50) { selectFilterRowsShown50();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS); }
	 * 
	 * else if (totalSites > 50 && totalSites <= 100) {
	 * selectFilterRowsShown100();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS); }
	 * 
	 * else if (totalSites > 100 && totalSites <= 200) {
	 * selectFilterRowsShown200();
	 * Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH +
	 * "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS); }
	 * 
	 * }
	 */

	public void waitForPageToUnMask() {
		log.info("waiting for New report dialog to unmask");
		Utility.waitUntilElementDissAppears(PageElements.PAGE_LOADING_MASKED_VERIFY);

	}

	public String pageRange() throws ElementNotFoundException {
		//clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_CURRENT_RANGE);
		String pageRange = Utility.getValueOfPAgeObject(PageElements.PAGING_COMBO_CURRENT_RANGE);
		//clickPagingComboDropDown();
		return pageRange;

		/*String[] splitRange = pageRange.split("\\W");
		totalRows = Integer.parseInt(splitRange[5]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);*/
	}
	
	
	
	
	public boolean isOnFirstPage() throws ElementNotFoundException
	{
		boolean isOnFirstPage = false;
		String[] splitRange = pageRange().split("\\W");
		currentPage = Integer.parseInt(splitRange[0]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		if(currentPage == 1)
		{
			isOnFirstPage = true;
		}else
		{
			isOnFirstPage = false;
		}
		return isOnFirstPage;
	}

	public int getTotalRows() throws ElementNotFoundException {

		String[] splitRange = pageRange().split("\\W");
		totalRows = Integer.parseInt(splitRange[5]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		return totalRows;
	}
	
	public int getRowsInCurrentPage() throws ElementNotFoundException
	{
		String[] splitRange = pageRange().split("\\W");
		
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		return rowsInCurrentPage;
	}

	public SitesTab clickRightPagingComboArrowButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN);
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}
	
	public SitesTab clickLeftPagingComboArrowButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_LEFT_BTN);
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_LEFT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_LEFT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}


	public SitesTab selectSiteTitle(String siteTitle) throws ElementNotFoundException {

		waitForPageToUnMask();

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);
		Utility.waitForElementPresent(PageElements.EACH_SITE_TITLE);
		try {
			int totalRowsInDL = getTotalRows();
			
			int pagination = 0;
			List<WebElement> siteNames = new ArrayList<WebElement>();
			boolean containsInThisPage = false;
			while (pagination <= (totalRowsInDL / 20)) {
				siteNames = Utility.getRecordWebEements(PageElements.EACH_SITE_TITLE, superElement);
				for (int i = 0; i < siteNames.size(); i++) {
					if (siteNames.get(i).getText().equals(siteTitle)) {
						containsInThisPage = true;
						Utility.selectFromCombo(PageElements.EACH_SITE_TITLE, superElement, siteTitle);
						pagination = ((totalRowsInDL / 20) + 1);
						i = siteNames.size();

					} else {
						containsInThisPage = false;
					}
				}
				if (!containsInThisPage) {
					clickRightPagingComboArrowButton();
					siteNames.clear();
					pagination++;
				}

			}

		} catch (ElementNotFoundException e) {
			log.info("Scan date was not found");
			Assert.fail(siteTitle + "Scan date was not found");

		}
		return this;
	}

	public String getSiteURLOfAsset(String assetName) throws ElementNotFoundException {

		String siteURLOfAsset;

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);
		WebElement superElement = Utility.getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);

		Utility.waitForElementPresent(PageElements.EACH_SITE_TITLE);
		siteURLOfAsset = Utility.getTextOfRecordColumn(PageElements.EACH_SITE_TITLE, PageElements.EACH_SITE_SITE_URL, superElement, assetName);
		return siteURLOfAsset;
	}

	// TODO Workssome times.
	public String getTagsOfAsset(String assetName) throws ElementNotFoundException {

		String tagOfAsset;

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);

		tagOfAsset = Utility.getTextOfRecordColumn(PageElements.EACH_SITE_TITLE, PageElements.EACH_SITE_TAGS, superElement, assetName);
		return tagOfAsset;
	}

	public StringBuffer getAllSiteURLText() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.EACH_SITE_SITE_URL);

		Utility.waitForElementPresent(PageElements.EACH_SITE_TITLE);
		List<WebElement> assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_SITE_TITLE, superElement);
		StringBuffer allPageURLs = new StringBuffer();
		for (int siteTitleRow = 0; siteTitleRow < assetSiteURLWebElement.size(); siteTitleRow++) {
			allPageURLs.append(assetSiteURLWebElement.get(siteTitleRow).getText() + "\n");
		}
		return allPageURLs;
	}

	public StringBuffer getAllTagsText() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);

		Utility.waitForElementPresent(PageElements.EACH_SITE_TAGS);
		List<WebElement> assetTagsWebElements = Utility.getRecordWebEements(PageElements.EACH_SITE_TAGS, superElement);
		StringBuffer allTags = new StringBuffer();
		for (int assetTagRow = 0; assetTagRow < assetTagsWebElements.size(); assetTagRow++) {
			allTags.append(assetTagsWebElements.get(assetTagRow).getText() + "\n");
		}
		return allTags;
	}

	// FILTERS EXPANDED NAVIGATION(SHOW FILTERS)
	public SitesTab clickShowFilters() {
		Utility.click(PageElements.SHOW_FILTER);
		return this;
	}

	public SitesTab searchFilter() {
		Utility.click(PageElements.FILTER_EXPANDED_SEARCH_TEXT_FIELD);
		return this;
	}

	public SitesTab selectFilterTags(String tagName) throws ElementNotFoundException {

		Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		WebElement superElement = Utility.getElement(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS);

		Utility.selectMultipleValuesDoubleClick(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS, superElement, tagName);

		return this;
	}

	public SitesTab typeSiteURLtoFilter(String scanURL) {
		Utility.click(PageElements.FILTER_EXPANDED_SITE_URL_TEXT_FIELD);
		return this;
	}

	public SitesTab typeSiteTitletoFilter(String scanURL) {
		Utility.click(PageElements.FILTER_EXPANDED_SITE_TITLE_TEXT_FIELD);
		return this;
	}

	public SitesTab selectFilterSiteTypeCheckbox(String mdsORwas) {
		if (mdsORwas.equalsIgnoreCase("MDS")) {
			Utility.click(PageElements.FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX);
		} else if (mdsORwas.equalsIgnoreCase("WAS")) {
			Utility.click(PageElements.FILTER_EXPANDED_SITE_TYPE_MDS_CHECKBOX);
		}
		return this;
	}

	public SitesTab selectFilterDeactivatedSitesCheckbox() {
		Utility.click(PageElements.FILTER_EXPANDED_SHOW_DEACTIVATED_SITES_CHECKBOX);
		return this;
	}

	public SitesTab clickHideFilters() {
		Utility.click(PageElements.HIDE_FILTER);
		return this;
	}

	public SitesTab clickClearFilters() {
		Utility.click(PageElements.CLEAR_FILTER);
		return this;
	}

}
