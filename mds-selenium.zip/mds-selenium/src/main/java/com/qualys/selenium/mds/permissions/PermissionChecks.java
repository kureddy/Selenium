package com.qualys.selenium.mds.permissions;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.PropertyReader;
import com.qualys.selenium.mds.dataobject.UserData;

@Slf4j
public class PermissionChecks {
	public static String getUserName() {
		return PropertyReader.getConfigProperty("username_" + PropertyReader.getConfigProperty("environment"));
	}

	public static String getPassword() {
		return PropertyReader.getConfigProperty("password_" + PropertyReader.getConfigProperty("environment"));
	}

	public static String getEnvironment() {
		return PropertyReader.getConfigProperty("environment");
	}

	public static boolean isSuperUser() {
		boolean superUser = false;
		UserData userPermissionData = QueryDB.getUserPermission(getUserName());
		if (userPermissionData.getIsSuperUser() == 1) {
			superUser = true;
		} else {
			superUser = false;
		}

		return superUser;
	}

	public static boolean hasPermission(String permissionName) {
		boolean hasPermission = false;

		if (isSuperUser()) {
			hasPermission = true;
			log.info("\" " + getUserName() + " \" is super user.So he has all permissions");
		} else if (!isSuperUser() && PermissionChecks.getPermissions().contains(permissionName)) {
			log.info(getUserName() + "Has permission " + permissionName);
			hasPermission = true;
		} else {
			log.warn("OOooopppsss..!!  " + getUserName() + " do not have permission " + permissionName);
			hasPermission = false;
		}
		return hasPermission;
	}

	public static boolean checkAddSitePermission() {
		boolean hasAddSitePermission = false;

		log.info("Checking if \" " + getUserName() + " \" has permission to create site :" + PermissionServices.ASSET_MALWARE_CREATE);
		if (PermissionChecks.isSuperUser()) {
			hasAddSitePermission = true;
			log.info("\"" + getUserName() + "\" is super user.So has all permissions");

		} else if (PermissionChecks.getPermissions().contains(PermissionServices.UI_ACCESS.getName()) && PermissionChecks.getPermissions().contains(PermissionServices.ASSET_MALWARE_CREATE.getName())) {
			hasAddSitePermission = true;
		} else {
			hasAddSitePermission = false;
		}
		return hasAddSitePermission;

	}

	
	
	public static boolean checkScanLaunchPermission()
	{
		boolean hasScanLaunchPermission = false;

		log.info("Checking if \" " + getUserName() + " \" has permission to create site :" + PermissionServices.MALWARE_SCAN_LAUNCH);
		if (PermissionChecks.isSuperUser()) {
			hasScanLaunchPermission = true;
			log.info("\"" + getUserName() + "\" is super user.So has all permissions");

		} else if (PermissionChecks.getPermissions().contains(PermissionServices.UI_ACCESS.getName()) && PermissionChecks.getPermissions().contains(PermissionServices.MALWARE_SCAN_LAUNCH.getName())) {
			hasScanLaunchPermission = true;
		} else {
			hasScanLaunchPermission = false;
		}
		return hasScanLaunchPermission;

	}
	
	public static List<String> getProducts() {
		UserData userPermissionData = QueryDB.getUserPermission(getUserName());
		return userPermissionData.getProducts();
	}

	public static List<String> getPermissions() {
		UserData userPermissionData = QueryDB.getUserPermission(getUserName());
		return userPermissionData.getPermissions();
	}

	public static boolean containsOnlyProduct(String productName) {

		boolean checkIfOnlyProduct = false;

		if (PermissionChecks.getProducts().size() == 1) {
			if (PermissionChecks.getProducts().contains(productName)) {
				checkIfOnlyProduct = true;
			} else {
				log.info("user contains only one product but that product is not : " + productName);
				checkIfOnlyProduct = false;
			}
		} else if (PermissionChecks.getProducts().size() > 1) {
			log.info("User contains more than 1 product");
			checkIfOnlyProduct = false;
		}

		return checkIfOnlyProduct;
	}

}
