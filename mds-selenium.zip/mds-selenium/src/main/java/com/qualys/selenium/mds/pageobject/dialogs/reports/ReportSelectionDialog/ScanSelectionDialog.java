package com.qualys.selenium.mds.pageobject.dialogs.reports.ReportSelectionDialog;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;
import com.qualys.selenium.mds.pageobject.dialogs.reports.NewReport;
import com.qualys.selenium.mds.pageobject.dialogs.reports.SelectionDialog;

@Slf4j
public class ScanSelectionDialog extends SelectionDialog {

	int totalRows;
	int rowsInCurrentPage;
	int currentPage;

	public enum PageElements implements IPageElement {

		SELECTION_DIALOG_VERIFY("div[class*=selection-dialog]"),

		DIALOG_MASK("div[class*=frame-mask]"),

		FILTER_SETTINGS_DROPDOWN("div[class*=q-dialog] tr[class*=toolbar-right-row] td:nth-of-type(5) button[class*=icon-pager]"),
		FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]", IdentifiedBy.XPATH),
		SORT_BY_SCAN_DATE("li:nth-of-type(1)[class*=menu-list-item] a[class*=-menu-group-item] span[class*=menu-item-text]"),
		SORT_BY_SCAN_TITLE("li:nth-of-type(2)[class*=menu-list-item] a[class*=-menu-group-item] span[class*=menu-item-text]"),

		FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'view_menu') and not(contains(@class,' hide-offsets'))]//span[contains(text(),'Rows Shown')]"),
		ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

		PAGING_COMBO_LEFT_BTN("div[class*=q-dialog] table[class*=toolbar-right] .first:not(.x-item-disabled) button[class*=page-prev]"),
		PAGING_COMBO_RIGHT_BTN("div[class*=q-dialog] table[class*=toolbar-right] .last:not(.x-item-disabled) button[class*=page-next]"),
		PAGING_COMBO_CURRENT_RANGE(".q-dialog .q-datalist-tbar-noheader td[class*=-toolbar-right] tr[class*=-toolbar-right-row] td:nth-of-type(2) input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("div[class*=q-dialog] div[class*=datalist-tbar] td[class*=toolbar-right] input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER("//div[contains(@style,'visibility: visible')]//div[contains(@class,'combo-list-inner')]", IdentifiedBy.XPATH),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS("//div[contains(@style,'visibility: visible')]//div[contains(@class,'-combo-list-item')]", IdentifiedBy.XPATH),

		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM("div:last-of-type[class*=combo-list] div[class*=-combo-list-inner]"),

		ITEMS_ALL_ROWS("div[class*=selection-dialog] div[class*=scroller]"),

		EACH_SCAN_DATE_COLUMN_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-first]"),

		EACH_SCAN_TITLE_COLUMN_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=td-title]"),
		EACH_SEVERITY_COLUMN_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-last]"),

		EACH_SITE_URL_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-first]"),
		EACH_SITE_NAME_ROWS("div[class*=selection-dialog] div[class*=scroller] div[class*=grid3-row] td[class*=cell-last]");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	private NewReport callingPage;

	public ScanSelectionDialog(NewReport callingPage) throws ElementNotFoundException {
		this.callingPage = callingPage;
		if (!Utility.isElementPresent(PageElements.SELECTION_DIALOG_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Scans>Scan List page");
		}
	}

	/*
	 * public SelectionDialog waitForPageMasking() { try {
	 * log.info("Waiting for page to mask");
	 * Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY); }
	 * catch (Exception e) { log.error(e.getMessage()); } return this; }
	 * 
	 * private SelectionDialog waitForPageUnMasking() { try {
	 * log.info("Waiting for page to unmask");
	 * Utility.waitForElementPresent(PageElements
	 * .PAGE_LOADING_NOT_MASKED_VERIFY); } catch (Exception e) {
	 * log.error(e.getMessage()); } return this;
	 * 
	 * }
	 */
	public void waitForPageToUnMask() {
		log.info("waiting for New report dialog to unmask");
		Utility.waitUntilElementDissAppears(PageElements.DIALOG_MASK);

	}

	public ScanSelectionDialog clickFilterDropDown() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.FILTER_SETTINGS_DROPDOWN);
		Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
		return this;
	}

	public ScanSelectionDialog selectFilterSortBy() throws ElementNotFoundException {
		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);
		return this;
	}

	public ScanSelectionDialog selectFilterSortByFirstItem() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.moveToElementAndClick(PageElements.SORT_BY_SCAN_DATE);
		/*
		 * waitForPageMasking(); waitForPageUnMasking(); ;
		 */
		return this;
	}

	public ScanSelectionDialog selectFilterSortBySecondItem() throws ElementNotFoundException {
		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_SCAN_TITLE);
		Utility.moveToElementAndClick(PageElements.SORT_BY_SCAN_TITLE);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;

	}

	public ScanSelectionDialog selectFilterRowsShown() throws ElementNotFoundException {
		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);

		return this;
	}

	public ScanSelectionDialog selectFilterRowsShown20() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public ScanSelectionDialog selectFilterRowsShown50() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public ScanSelectionDialog selectFilterRowsShown100() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public ScanSelectionDialog selectFilterRowsShown200() throws ElementNotFoundException {
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
		/*
		 * waitForPageMasking(); waitForPageUnMasking();
		 */
		return this;
	}

	public ScanSelectionDialog clickPagingComboDropDown() throws ElementNotFoundException {

		waitForPageToUnMask();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		return this;
	}

	public String pageRange() throws ElementNotFoundException {
		// clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_CURRENT_RANGE);
		String pageRange = Utility.getValueOfPAgeObject(PageElements.PAGING_COMBO_CURRENT_RANGE);
		// clickPagingComboDropDown();
		return pageRange;

		/*
		 * String[] splitRange = pageRange.split("\\W"); totalRows =
		 * Integer.parseInt(splitRange[5]); rowsInCurrentPage =
		 * Integer.parseInt(splitRange[3]);
		 */
	}

	public boolean isOnFirstPage() throws ElementNotFoundException {
		boolean isOnFirstPage = false;
		String[] splitRange = pageRange().split("\\W");
		currentPage = Integer.parseInt(splitRange[0]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		if (currentPage == 1) {
			isOnFirstPage = true;
		} else {
			isOnFirstPage = false;
		}
		return isOnFirstPage;
	}

	public int getTotalRows() throws ElementNotFoundException {

		String[] splitRange = pageRange().split("\\W");
		totalRows = Integer.parseInt(splitRange[5]);
		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		return totalRows;
	}

	public int getRowsInCurrentPage() throws ElementNotFoundException {
		String[] splitRange = pageRange().split("\\W");

		rowsInCurrentPage = Integer.parseInt(splitRange[3]);
		return rowsInCurrentPage;
	}

	public ScanSelectionDialog clickrightPagingComboArrowButton() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN);
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);

			waitForPageToUnMask();
		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	// Scan Report --> Scan Date
	// Site/summery Report --> URL
	public ScanSelectionDialog selectScanDate(String searchByDate) throws ElementNotFoundException {

		waitForPageToUnMask();

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);
		Utility.waitForElementPresent(PageElements.EACH_SCAN_DATE_COLUMN_ROWS);
		try {
			int totalRowsInDL = getTotalRows();
			int pagination = 0;
			List<WebElement> siteNames = new ArrayList<WebElement>();
			boolean containsInThisPage = false;
			while (pagination <= (totalRowsInDL / 20)) {
				siteNames = Utility.getRecordWebEements(PageElements.EACH_SCAN_DATE_COLUMN_ROWS, superElement);
				for (int i = 0; i < siteNames.size(); i++) {
					if (siteNames.get(i).getText().equals(searchByDate)) {
						containsInThisPage = true;
						Utility.selectFromCombo(PageElements.EACH_SCAN_DATE_COLUMN_ROWS, superElement, searchByDate);
						pagination = ((totalRowsInDL / 20) + 1);
						i = siteNames.size();

					} else {
						containsInThisPage = false;
					}
				}
				if (!containsInThisPage) {
					clickrightPagingComboArrowButton();
					siteNames.clear();
					pagination++;
				}

			}

		} catch (ElementNotFoundException e) {
			log.info("Scan date was not found");
			Assert.fail(searchByDate + "Scan date was not found");

		}
		return this;
	}

	public ScanSelectionDialog selectScanTitle(String searchByScanTitle) throws ElementNotFoundException {

		waitForPageToUnMask();

		Utility.waitForElementPresent(PageElements.ITEMS_ALL_ROWS);
		WebElement superElement = Utility.getElement(PageElements.ITEMS_ALL_ROWS);
		Utility.waitForElementPresent(PageElements.EACH_SCAN_DATE_COLUMN_ROWS);
		try {
			int totalRowsInDL = getTotalRows();
			int pagination = 0;
			List<WebElement> siteNames = new ArrayList<WebElement>();
			boolean containsInThisPage = false;
			while (pagination <= (totalRowsInDL / 20)) {
				siteNames = Utility.getRecordWebEements(PageElements.EACH_SCAN_TITLE_COLUMN_ROWS, superElement);
				for (int i = 0; i < siteNames.size(); i++) {
					if (siteNames.get(i).getText().equals(searchByScanTitle)) {
						containsInThisPage = true;
						Utility.selectFromCombo(PageElements.EACH_SCAN_TITLE_COLUMN_ROWS, superElement, searchByScanTitle);
						pagination = ((totalRowsInDL / 20) + 1);
						i = siteNames.size();

					} else {
						containsInThisPage = false;
					}
				}
				if (!containsInThisPage) {
					clickrightPagingComboArrowButton();
					siteNames.clear();
					pagination++;
				}

			}

		} catch (ElementNotFoundException e) {
			log.info("Scan title was not found");
			Assert.fail(searchByScanTitle + "Scan title was not found");
		}
		return this;
	}

	public NewReport clickSelectBtn() throws ElementNotFoundException {
		Utility.waitForElementPresent(DialogCommonElements.SELECT_BTN);
		Utility.click(DialogCommonElements.SELECT_BTN);

		return callingPage;
	}
}
