package com.qualys.selenium.mds.pageobject.assets;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;

@Slf4j
public class AssetsPage extends MalwarePage {
	


    public enum PageElements implements IPageElement {
    	ASSET_PAGE_VERIFY("#FrameModuleCardPanel #assets:not(.x-hide-display)"),
        SITES_TAB_BTN("#assets .section-tabs-wrap div[ref=datalist-sites]"),
        TAG_MANAGEMENT_TAB_BTN("#assets .section-tabs-wrap div[ref=datalist-tags]");
     
        String key;
        IdentifiedBy identifiedBy;

        PageElements(String key, IdentifiedBy identifiedBy) {
            this.key = key;
            this.identifiedBy = identifiedBy;
        }

        PageElements(String key) {
            this(key, IdentifiedBy.CSS);
        }

        @Override
        public String getLocator() {
            // TODO Auto-generated method stub
            return this.key;
        }

        @Override
        public IdentifiedBy getIdentifiedBy() {
            // TODO Auto-generated method stub
            return this.identifiedBy;
        }

    }

	
	public AssetsPage() throws ElementNotFoundException{
		super(MalwareLandingPage.ASSETS);
	    
	    if (!Utility.isElementPresent(PageElements.ASSET_PAGE_VERIFY)) {
            log.info("Currently at url : {}", Utility.getCurrentUrl());
          
			throw new IllegalStateException("This is not the MDS > Assets page");
		}
	}

	public SitesTab goToSitesTab() throws ElementNotFoundException {

	    Utility.waitForElementPresent(PageElements.SITES_TAB_BTN);
	    Utility.click(PageElements.SITES_TAB_BTN);
		return new SitesTab();
	}

	public TagManagementTab goToAssetsTagManagement() {
		Utility.getElement(PageElements.TAG_MANAGEMENT_TAB_BTN).click();
		return new TagManagementTab();
	}
}
