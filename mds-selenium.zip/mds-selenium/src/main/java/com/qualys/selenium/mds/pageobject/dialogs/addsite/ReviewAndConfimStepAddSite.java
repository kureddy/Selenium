package com.qualys.selenium.mds.pageobject.dialogs.addsite;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.assets.SitesTab;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;

@Slf4j
public class ReviewAndConfimStepAddSite extends AddSiteDialog {
	public enum LandingPageAfterAddSite {

		DASHBOARD("dashboard"),
		ASSETS_SITES_TAB("assets");

		String uiValue;

		LandingPageAfterAddSite(String uiValue) {
			this.uiValue = uiValue;
		}

		public String getUiValue() {
			return this.uiValue;
		}
	}

	public enum PageElements implements IPageElement {

		STEP_VERIFY_BEFORE_FILLING(".step-review:not(.last-inactive)"),
		STEP_VERIFY_AFTER_FILLING(".step-review:not(.last-inactive).last-passed"),

		REVIEW_AND_CONFIRM_STEP_LABEL(".malware-site-object-window .q-step-header .object-panel div"),
		SITE_DETAILS_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(1) .section-panel-header-text"),
		SITE_DETAILS_TITLE_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(1) .section-panel-bwrap .x-form-item:nth-of-type(1) label"),
		SITE_DETAILS_SITE_URL_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(1) .section-panel-bwrap .x-form-item:nth-of-type(2) label"),

		TAGS_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(3) .section-panel-header-text"),
		ASSIGNED_TAGS(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(3) .x-form-item label"),
		SCAN_OPTIONS_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(4) .section-panel-header-text"),
		MAXIMUM_PAGES_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(4) .section-panel-bwrap .x-form-item:nth-of-type(1) label"),
		SCAN_INTENSIOTY_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(4) .section-panel-bwrap .x-form-item:nth-of-type(2) label"),
		HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(4) .section-panel-bwrap .x-form-item:nth-of-type(3) label"),
		CRAWL_EXCLUSION_LISTS_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(5) .section-panel-header-text"),
		WHITE_LIST_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(5) .section-panel-bwrap .x-form-item:nth-of-type(1) label"),
		WHITE_LIST_REGULAR_EXPRESSION_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(5) .section-panel-bwrap .x-form-item:nth-of-type(2) label"),

		BLACK_LIST_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(5) .section-panel-bwrap .x-form-item:nth-of-type(3) label"),
		BLACK_LIST_REGULAR_EXPRESSION_LABEL(
				".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(5) .section-panel-bwrap .x-form-item:nth-of-type(4) label"),

		SCHEDULING_INFORMATION_HEADER_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(5) .section-panel:nth-of-type(6) .section-panel-header-text"),
		START_DATE_LABEL("//div[contains(@class,'malware-site-object-window')]//div[contains(@class,'object-panel')]//div[6]//label[contains(text(),'Start Date')]", IdentifiedBy.XPATH),
		TIME_ZONE_LABEL("//div[contains(@class,'malware-site-object-window')]//div[contains(@class,'object-panel')]//div[6]//label[contains(text(),'Time Zone')]", IdentifiedBy.XPATH),
		MODE_LABEL("//div[contains(@class,'malware-site-object-window')]//div[contains(@class,'object-panel')]//div[6]//label[contains(text(),'Mode')]", IdentifiedBy.XPATH),
		DESCRIPTION_LABEL("//div[contains(@class,'malware-site-object-window')]//div[contains(@class,'object-panel')]//div[6]//label[contains(text(),'Description')]", IdentifiedBy.XPATH),
		CONTRAINTS_LABEL("//div[contains(@class,'malware-site-object-window')]//div[contains(@class,'object-panel')]//div[6]//label[contains(text(),'Constraints')]", IdentifiedBy.XPATH),
		OCCURANCES_LABEL("//div[contains(@class,'malware-site-object-window')]//div[contains(@class,'object-panel')]//div[6]//label[contains(text(),'Occurrences')]", IdentifiedBy.XPATH),

		SITE_CREATION_ERROR(".dialog-error"),
		SITE_CREATION_ERROR_OK_BUTN(".dialog-error div:nth-child(2) td:nth-child(2) td button[type='button']"),
		SITE_CREATION_ERROR_CLOSE(".dialog-error div:nth-child(1) div[title='Close']"),

		// help tips
		TURN_HELP_TIPS_ON_OFF_LABEL(".malware-site-object-window .q-window-header div.help-on"), // TODO
																									// :
																									// no
																									// such
																									// element
																									// exception
		LAUNCH_HELP_LABEL(".malware-site-object-window .q-window-header div.launch-help"),

		HELP_TIPS_ON(".malware-site-object-window .q-window-header div.help-on .help-toggle-on"),
		HELP_TIPS_OFF(".malware-site-object-window .q-window-header div.help-on .help-toggle-off");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public LandingPageAfterAddSite landingPage;

	public ReviewAndConfimStepAddSite(AddSiteDialogMode mode) throws SiteCreationMaxedOutException, ElementNotFoundException {
		super(mode);

		if (Utility.waitForElementPresent(PageElements.STEP_VERIFY_BEFORE_FILLING) == null) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the AddSite>Review and Confirm page");
		}
	}

	public ReviewAndConfimStepAddSite oNHelpTips() {
		Utility.click(PageElements.HELP_TIPS_ON);
		return this;
	}

	public ReviewAndConfimStepAddSite oFFHelpTips() {
		Utility.click(PageElements.HELP_TIPS_OFF);
		return this;
	}

	public ReviewAndConfimStepAddSite launchHelp() {
		Utility.click(PageElements.LAUNCH_HELP_LABEL);
		return this;
	}

	public DashboardPage clickCancel() throws ElementNotFoundException {
		Utility.click(DialogCommonElements.CANCEL_BTN);

		return new DashboardPage();
	}

	public SchedulingStep clickPrevious() throws SiteCreationMaxedOutException, ElementNotFoundException {
		Utility.click(DialogCommonElements.PREVIOUS_BTN);
		return new SchedulingStep(AddSiteDialogMode.CREATE);
	}

	public MalwarePage clickFinish(LandingPageAfterAddSite landingPage) throws ElementNotFoundException {

		Utility.click(DialogCommonElements.FINISH_BTN);
		log.info("clicking on finish button");
		switch (landingPage) {
		case DASHBOARD:
			return new DashboardPage();
		case ASSETS_SITES_TAB:

			return new SitesTab();

		default:
			throw new RuntimeException("No Report Type selected");
		}
	}

	public MalwarePage clickSaveAndScanNow(LandingPageAfterAddSite landingPage) throws ElementNotFoundException {

		Utility.click(DialogCommonElements.SAVE_AND_SCAN_NOW_BTN);

		switch (landingPage) {
		case DASHBOARD:
			return new DashboardPage();
		case ASSETS_SITES_TAB:

			return new SitesTab();

		default:
			throw new RuntimeException("No Report Type selected");
		}

	}

	public ReviewAndConfimStepAddSite verifyReviewAndConfirmStepStaticText() {
		CustomVerification customVerification = new CustomVerification();

		// customVerification.verifyEquals("Site Details step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help ");
		// //TODO : no such element exception
		customVerification.verifyEquals("Site Details step LAUNCH_HELP_", Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL), "Launch help");

		customVerification.verifyEquals("Review and confirm header description ", Utility.getTextOfPageObject(PageElements.REVIEW_AND_CONFIRM_STEP_LABEL), "Review and confirm your settings");
		customVerification.verifyEquals("Review and confirm site details header ", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_HEADER_LABEL), "Site Details");
		customVerification.verifyEquals("Review and confirm site details title ", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_TITLE_LABEL), "Title");
		customVerification.verifyEquals("Review and confirm site details URL ", Utility.getTextOfPageObject(PageElements.SITE_DETAILS_SITE_URL_LABEL), "Site URL");

		customVerification.verifyEquals("Review and confirm tags header ", Utility.getTextOfPageObject(PageElements.TAGS_HEADER_LABEL), "Tags");
		customVerification.verifyEquals("Review and confirm assigned tags ", Utility.getTextOfPageObject(PageElements.ASSIGNED_TAGS), "Assigned tags");

		customVerification.verifyEquals("Review and confirm scan options header ", Utility.getTextOfPageObject(PageElements.SCAN_OPTIONS_HEADER_LABEL), "Scan Options");
		customVerification.verifyEquals("Review and confirm max pages title ", Utility.getTextOfPageObject(PageElements.MAXIMUM_PAGES_LABEL), "Maximum Pages");
		customVerification.verifyEquals("Review and confirm scan intensity not matching", Utility.getTextOfPageObject(PageElements.SCAN_INTENSIOTY_LABEL), "Scan Intensity");

		customVerification.verifyEquals("Review and confirm header ", Utility.getTextOfPageObject(PageElements.HEADER_LABEL), "Headers");
		customVerification.verifyEquals("Review and confirm crawl exclusion list header ", Utility.getTextOfPageObject(PageElements.CRAWL_EXCLUSION_LISTS_HEADER_LABEL), "Crawl exclusion lists");
		customVerification.verifyEquals("Review and confirm white list ", Utility.getTextOfPageObject(PageElements.WHITE_LIST_LABEL), "White List");

		customVerification.verifyEquals("Review and confirm White List (Regular Expressions) ", Utility.getTextOfPageObject(PageElements.WHITE_LIST_REGULAR_EXPRESSION_LABEL),
				"White List (Regular Expressions)");
		customVerification.verifyEquals("Review and confirm Black List ", Utility.getTextOfPageObject(PageElements.BLACK_LIST_LABEL), "Black List");
		customVerification.verifyEquals("Review and confirm Black List (Regular Expressions) ", Utility.getTextOfPageObject(PageElements.BLACK_LIST_REGULAR_EXPRESSION_LABEL),
				"Black List (Regular Expressions)");

		customVerification.verifyEquals("Review and confirm Scheduling Information header ", Utility.getTextOfPageObject(PageElements.SCHEDULING_INFORMATION_HEADER_LABEL), "Scheduling Information");
		customVerification.verifyEquals("Review and confirm Start Date ", Utility.getTextOfPageObject(PageElements.START_DATE_LABEL), "Start Date");
		customVerification.verifyEquals("Review and confirm Time Zone ", Utility.getTextOfPageObject(PageElements.TIME_ZONE_LABEL), "Time Zone");

		customVerification.verifyEquals("Review and confirm Mode ", Utility.getTextOfPageObject(PageElements.MODE_LABEL), "Mode");
		customVerification.verifyEquals("Review and confirm Description ", Utility.getTextOfPageObject(PageElements.DESCRIPTION_LABEL), "Description");
		customVerification.verifyEquals("Review and confirm Constraints ", Utility.getTextOfPageObject(PageElements.CONTRAINTS_LABEL), "Constraints");

		customVerification.verifyEquals("Review and Occurrences ", Utility.getTextOfPageObject(PageElements.OCCURANCES_LABEL), "Occurrences");

		customVerification.verifyEquals("Review and confirm continue button g", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN), "Cancel");
		customVerification.verifyEquals("Review and confirm cancel button  ", Utility.getTextOfPageObject(DialogCommonElements.PREVIOUS_BTN_REVIEW_AND_CONFIRM), "Previous");
		customVerification.verifyEquals("Review and confirm continue button ", Utility.getTextOfPageObject(DialogCommonElements.FINISH_BTN), "Finish");
		customVerification.verifyEquals("Review and confirm cancel button  ", Utility.getTextOfPageObject(DialogCommonElements.SAVE_AND_SCAN_NOW_BTN), "Save & Scan Now");
		return this;
	}
}
