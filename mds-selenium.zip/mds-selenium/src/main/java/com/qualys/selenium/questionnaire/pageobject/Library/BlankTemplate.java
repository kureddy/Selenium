package com.qualys.selenium.questionnaire.pageobject.Library;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.questionnaire.pageobject.QuestionnairePage;

@Slf4j
public class BlankTemplate extends QuestionnairePage {

	public enum PageElements implements IPageElement {
		
		BLANK_TEMPLATE_VERIFY("#template-list #datalist-templates "),
		BACK_TO_LIST_LINK("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=quest-breadcrumbs] table[class*=link]"),
		
		CLICK_TO_ADD_TITLE_EDIT_AREA("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=template-title] span[class*=empty-editable-text]"),
		CLICK_TO_ADD_DESCRIPTION_EDIT_AREA("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=template-description] span[class*=empty-editable-text]"),
		
		PUBLISH_BUTN("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=template-editor-header-panel] tr[class*=-toolbar-right-row] td:nth-of-type(1) table[class*=-button-flat-gray]"),
		SAVE_AND_EXIT_BTN("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=template-editor-header-panel] tr[class*=-toolbar-right-row] td:nth-of-type(2) table[class*=-button-flat-gray]"),
		DELETE_BTN("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=template-editor-header-panel] tr[class*=-toolbar-right-row] td:nth-of-type(4) table[class*=-button-flat-gray]"),
		
		DOCUMENT_VIEW_PROPERTY_TAB("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=questionnaire-property-tabs] ul[class*=tab-strip-top] li:nth-of-type(1) span[class*=tab-strip-text]"),
		OUTLINE_VIEW_PROPERTY_VIEW("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div[class*=questionnaire-property-tabs] ul[class*=tab-strip-top] li:nth-of-type(2) span[class*=tab-strip-text]"),
		CREATE_ELEMENTS_PROPERTY_VIEW("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] ul[class*=tab-strip-top] li:nth-of-type(1) span[class*=tab-strip-text]"),
		SELECTION_PROPERTY_VIEW("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] ul[class*=tab-strip-top] li:nth-of-type(2) span[class*=tab-strip-text]"),
		NEW_SUBSCRIPTION_LABEL("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div[class*=subsection-element-dragtarget]"),
		
		TEXT_FIELD_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(1)[class*=question-element-dragtarget]"),
		FORMATED_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(2)[class*=question-element-dragtarget]"),
		DROP_DOWN_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(3)[class*=question-element-dragtarget]"),
		YES_NO_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(4)[class*=question-element-dragtarget]"),
		MULTI_SELECT_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(5)[class*=question-element-dragtarget]"),
		SINGLE_SELECT_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(6)[class*=question-element-dragtarget]"),
		DATE_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(4)[class*=question-element-dragtarget]"),
		NUMERIC_ELEMENT("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div:nth-of-type(4)[class*=question-element-dragtarget]"),
		
		DOCUMENT_VIEW_CONTAINER("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(1)[class*=questionnaire-property-tabs] div[class*=tab-panel-bwrap] div[class*=editable-document-panel-container]"),
		
		
		QUESTION_PROPERTIES_SIDE_BY_SIDE("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div[class*=scroller] div:nth-of-type(2)[class*=question-detail-panel] div:nth-of-type(1)[class*=layout-item]"),
		QUESTION_PROPERTIES_STACKED("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div[class*=scroller] div:nth-of-type(2)[class*=question-detail-panel] div:nth-of-type(2)[class*=layout-item]"),
		QUESTION_PROPERTIES_FORMATTED("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div[class*=scroller] div:nth-of-type(2)[class*=question-detail-panel] div:nth-of-type(3)[class*=layout-item]"),
		
		LENGTH_REQUIREMENT_MORE_THAN("#template-list #datalist-templates div:nth-of-type(2)[class*=tab-view-panel] div:nth-of-type(2)[class*=questionnaire-property-tabs] div[class*=scroller] div:nth-of-type(2)[class*=question-detail-panel] input[class*=form-num-field]");
		
		
		
		
		
		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public BlankTemplate() throws ElementNotFoundException {
		super(QuestionnaireLandingPage.LIBRARY);

		if (!Utility.isElementPresent(PageElements.BLANK_TEMPLATE_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());

			throw new IllegalStateException("This is not the Questionnaire  > Blank template page");
		}
	}
	
	
	
}
