package com.qualys.selenium.mds.pageobject.dialogs.schedule;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;

@Slf4j
public class ReviewAndConfirm {

    public enum PageElements implements IPageElement {

        STEP_VERIFY_LEFT_PANEL_BEFORE_FILLING(".schedule-object-window .step-review:not(.last-inactive)"), 
        STEP_VERIFY_LEFT_PANEL_AFTER_FILLING(".schedule-object-window .step-review:not(.last-inactive).last-passed");

        String key;
        IdentifiedBy identifiedBy;

        PageElements(String key, IdentifiedBy identifiedBy) {
            this.key = key;
            this.identifiedBy = identifiedBy;
        }

        PageElements(String key) {
            this(key, IdentifiedBy.CSS);
        }

        @Override
        public String getLocator() {
            return this.key;
        }

        @Override
        public IdentifiedBy getIdentifiedBy() {
            return this.identifiedBy;
        }

    }

    public ReviewAndConfirm() {
        if (!Utility.isElementPresent(PageElements.STEP_VERIFY_LEFT_PANEL_BEFORE_FILLING)) {
            log.info("Currently at url : {}", Utility.getCurrentUrl());
            throw new IllegalStateException(
                    "This is not the Schedule>Review and Confirm page");
        }
    }

    public void clickCancel() {
        Utility.click(DialogCommonElements.CANCEL_BTN);
    }

    public SchedulingOptions clickPrevious() {
        Utility.click(DialogCommonElements.PREVIOUS_BTN);
        return new SchedulingOptions("create", "Previous");
    }

    public void clickFinish() {
        
        Utility.click(DialogCommonElements.FINISH_BTN);
    }

}
