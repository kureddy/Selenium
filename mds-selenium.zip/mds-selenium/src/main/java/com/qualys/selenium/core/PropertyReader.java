/**
 * This class will load the properties files and provide methods to access contents of these files.
 * 
 *  @author Udaya Knodapalli
 *  
 */
package com.qualys.selenium.core;

import java.util.Properties;

public class PropertyReader {

	public static Properties ALL_CONFIG = new Properties();
	public static Properties CORE_CONFIG = new Properties();
	public static Properties MDS_CONFIG = new Properties();
	public static Properties ALL_WEBELEMENTS = new Properties();
	public static Properties CORE_WEBELEMENTS = new Properties();
	public static Properties MDS_WEB_ELEMENTS = new Properties();
	public static Properties JDBC_PROPERTIES = new Properties();

	static {
		try {

			/* MDS related config */
			MDS_CONFIG.load(PropertyReader.class.getResourceAsStream("/mds/mds-config.properties"));

			/* CORE CONFIG */
			CORE_CONFIG.load(PropertyReader.class.getResourceAsStream("/core/core-config.properties"));
			JDBC_PROPERTIES.load(PropertyReader.class.getResourceAsStream("/core/jdbcConnection.properties"));

			/* move all CONFIG */
			ALL_CONFIG.putAll(MDS_CONFIG);
			ALL_CONFIG.putAll(CORE_CONFIG);

			/*
			 * MDS related web elements
			 * MDS_WEB_ELEMENTS.load(PropertyReader.class
			 * .getResourceAsStream("/mds/mds-webelements.properties"));
			 */

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getConfigProperty(String key) {
		return ALL_CONFIG.getProperty(key);
	}

	public static String getWebElementProperty(String key) {
		return ALL_WEBELEMENTS.getProperty(key);
	}
	
	public static String getJDBCProperties(String key)
	{
		return JDBC_PROPERTIES.getProperty(key);
	}

	/*
	 * public static String getMDSConfigProperty(String key){ return
	 * MDS_CONFIG.getProperty(key); }
	 */
}
