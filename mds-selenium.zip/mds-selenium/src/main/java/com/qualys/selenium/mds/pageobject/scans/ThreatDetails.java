package com.qualys.selenium.mds.pageobject.scans;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog;

public class ThreatDetails extends AbstractDialog {

	public DetectionsTab clickClose() throws ElementNotFoundException {
		Utility.click(DialogCommonElements.CLOSE_BTN);
		return new DetectionsTab();

	}

}
