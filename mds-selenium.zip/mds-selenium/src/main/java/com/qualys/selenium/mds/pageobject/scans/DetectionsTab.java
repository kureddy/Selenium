/* contains following methods:
 * select Checkboxes(all detections,single detection) 
 * => Methods --> selectAllDetectionsCheckBox(),selectSingleScheduleCheckBox(String detectionName)
 * 
 * Navigate to QuickActions dropdown(Select View,Rescan Page) 
 * => Methods --> clickQuickActionsDropDown(String detectionName),selectQuickActionsView(String detectionName),selectQuickActionsRescanPage(String detectionName)
 * 
 * * Navigate to refresh button
 * => methods --> refreshScanListPage()
 * 
 * Navigat to Actions dropdown  
 * => methods --> clickActionsDropDown(),selectActionsView(),selectActionsRescanPage()
 * 
 * Navigate to Filter dropdown on the right(select Download,SortBy-->PageURL,High,Med,Low,Rows Shown-->20,50,100,200)
 * => methods --> clickFilterDropDown(),selectFilterDownload(),selectFilterSortBy(),selectFilterSortByName(),selectFilterSortByPageURL(),selectFilterSortByHigh(),selectFilterRowsShown()
 * selectFilterRowsShown20(),selectFilterRowsShown50(),selectFilterRowsShown100(),selectFilterRowsShown200()

 * Navigate to header Titles(click on PageURL,High,Med,Low,Severity)
 * => methods --> SortPageURLFromHeader(),SortHighVulnsFromHeader(),SortMediumVulnsFromHeader(), SortLowVulnsFromHeader(),SortSeverityFromHeader()
 * 
 *  
 * Navigating to Paging combo(left arrow,right arrow,middle paging combo dropdown)
 * => methods --> leftPagingComboArrowButton(),rightPagingComboArrowButton(),clickPagingComboDropDown(),electPagingComboRange(int start, int end)
 * 
 * 
 * Navigating to left panel data(clicking on Left panel sites),selecting the rows equal to detections found
 * => methods --> clickLeftPanelSitesDataFilter(String siteName),selectRowsShownEqualToLeftPanelDetectionsFound(String siteName)
 * 
 * Getting all text from each column
 * ==> methods --> getAllPageURLText(),getAllHighVulnsText(),getAllMediumVulnsText(),getAllLowVulns(),getAllSeverity()
 * Getting text of each detection (pageURL,high,med,low,severity) 
 *  ==> methods --> getHighVulnsOfDetection(String detectionName),getMedVulnsOfDetection(String detectionName),getLowVulnsOfDetection(String detectionName),getSeverityOfDetection(String detectionName)
 */

package com.qualys.selenium.mds.pageobject.scans;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite.NewScanEntireSiteDialog;

@Slf4j
public class DetectionsTab extends ScansPage {

	public enum PageElements implements IPageElement {

		DETECTIONS_TAB_TAB_VERIFY("#infected-pages:not(.x-hide-display) .tab-navigation-panel "),
		PAGE_LOADING_NOT_MASKED_VERIFY("#infected-pages:not(.x-hide-display) .tab-navigation-panel .q-datalist:not(.x-masked) .q-datalist-bwrap:not(.x-masked)"),
		PAGE_LOADING_MASKED_VERIFY("#infected-pages:not(.x-hide-display) .mds-schedule-datalist .q-datalist.x-masked .q-datalist-bwrap.x-masked"),

		REFRESH_PAGE_BTN("#infected-pages:not(.x-hide-display) .x-small-editor .x-toolbar-right .x-tbar-loading"),
		// MDS_ScansPage_ScanListTab_AfterRefreshPage_WaitFor=.content-panel

		FILTER_SETTINGS_DROPDOWN("#infected-pages:not(.x-hide-display) .x-small-editor .x-toolbar-right .dlist_view_btn"),
		FILTER_SETTINGS_DOWNLOAD(".q_view_menu .x-menu-list li:nth-child(1)"),
		FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]", IdentifiedBy.XPATH),
		SORT_BY_PAGE_URL("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		SORT_BY_HIGH_VULNS("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		SORT_BY_MEDIUM_VULNS("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		SORT_BY_LOW_VULN("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),
		FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Rows Shown')]"),
		ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
		ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
		ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
		ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),

		PAGING_COMBO_LEFT_BTN("#datalist-schedules:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader  .x-toolbar-right tr.x-toolbar-right-row .first:not(.x-item-disabled)"),
		PAGING_COMBO_RIGHT_BTN("#datalist-schedules:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row .last:not(.x-item-disabled)"),
		PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("#datalist-schedules:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row input[name=pagingCombo]"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER(".x-combo-list"),
		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS(".x-combo-list-item"),

		PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM(".x-combo-list .x-combo-list-item:nth-child(1)"),

		LIST_HEADER_PAGE_URL("#infected-pages:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-hd-url"),
		LIST_HEADER_HIGH_VULNS("#infected-pages:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-hd-highVulns"),
		LIST_HEADER_MEDIUM_VULNS("#infected-pages:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-td-mediumVulns"),
		LIST_HEADER_LOW_VULNS("#infected-pages:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-td-lowVulns"),
		LIST_HEADER_SEVERITY("#infected-pages:not(.x-hide-display) .q-datalist-body .x-grid3-header .x-grid3-cell-last"),

		ALL_DETECTIONS_CHECKBOX("#infected-pages:not(.x-hide-display) .q-datalist-body table td:nth-of-type(1)[class*=grid3-hd]"),

		LEFT_PANEL_FILTER_CONTAINER("#infected-pages:not(.x-hide-display) .left-navigation .x-panel-bwrap .data-view-filter .data-view-filter-list"), // SUPER
																																						// ELEMENT
		LEFT_PANEL_FILTER_SITE_TITLE(".record .url"), // SUB ELEMENT
		LEFT_PANEL_FILTER_DETECTIONS_PERFORMED(".record .desc"), // SUB ELEMENT

		EACH_DETECTIONS_ROWS("#infected-pages:not(.x-hide-display) .tab-navigation-panel .x-grid3-scroller"), // //SUPER
																												// ELEMENT
		EACH_PAGE_URL(".x-grid3-td-url.q-quick-menu-column"), // SUB ELEMENT
		EACH_HIGH_VULNS(".x-grid3-td-highVulns .x-grid3-col-highVulns"), // SUB
																			// ELEMENT
		EACH_MEDIUM_VULNS(".x-grid3-td-mediumVulns .x-grid3-col-mediumVulns"), // SUB
																				// ELEMENT
		EACH_LOW_VULNS(".x-grid3-td-lowVulns .x-grid3-col-lowVulns"), // SUB
																		// ELEMENT
		EACH_DETECTIONS_SEVERITY(".x-grid3-scroller .x-grid3-cell-last .severity-level"), // SUB
																							// ELEMENT

		EACH_DETECTIONS_CHECKBOX("#infected-pages:not(.x-hide-display) .x-grid3-scroller .x-grid3-td-checker.x-grid3-cell-first"),

		ACTIONS_ENABLED_DOWN_BTN("#infected-pages:not(.x-hide-display) .actionBtn:not(.x-item-disabled)"),
		ACTIONS_DISABLED_DOWN_BTN("#infected-pages:not(.x-hide-display) .actionBtn.x-item-disabled"),
		ACTIONS_DOWN_VIEW("//li[1][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View')]", IdentifiedBy.XPATH),
		ACTIONS_DOWN_RESCAN_PAGE("//li[2][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'Rescan page')]", IdentifiedBy.XPATH),

		QUICK_ACTIONS_DOWN_BTN("#infected-pages:not(.x-hide-display) .q-quick-menu-column"),
		QUICK_ACTIONS_DOWN_QUICK_ACTIONS_LABEL("li.x-menu-list-item:not(.x-item-disabled):nth-child(1) "),
		QUICK_ACTIONS_DOWN_VIEW("li.x-menu-list-item:not(.x-item-disabled):nth-child(2)"),
		QUICK_ACTIONS_DOWN_RESCAN_PAGE("li.x-menu-list-item:not(.x-item-disabled):nth-child(3)"),

		// PENDING TO TEST NAVIGATION
		SHOW_FILTER("#infected-pages:not(.x-hide-display) .filter-summary-panel .filter-buttons"),
		CLEAR_FILTER("#infected-pages:not(.x-hide-display) .filter-summary-panel .filter-buttons .clear-filters-link"),
		HIDE_FILTER("#infected-pages:not(.x-hide-display) .filter-summary-panel .filter-buttons .toggle-filter-link"),
		FILTER_APPLIED_NUMBER("#infected-pages:not(.x-hide-display) .filter-summary-panel .filter-count span b"),

		FILTER_EXPANDED_TAG_DROPDOWN("#infected-pages:not(.x-hide-display) .tag-combo-box span>img:last-of-type"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node"),
		FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_CLOSE_BTN("div[class='x-layer']>div+div"),

		FILTER_EXPANDED_SITE_TITLE_TEXT_FIELD("#infected-pages:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(1) input"),
		FILTER_EXPANDED_SITE_URL_TEXT_FIELD("#infected-pages:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(2) input"),

		FILTER_EXPANDED_SHOW_DEACTIVATED_SITES_CHECKBOX("#infected-pages:not(.x-hide-display) .filter-column-panel-middle .filter-panel-column-body>div:nth-child(3) .x-form-checkbox"),

		FILTER_EXPANDED_HIGH_SEVERITY_CHECKBOX("#infected-pages:not(.x-hide-display) .filter-panel-column-body>div:nth-child(1) div.x-hide-label:first-of-type input"),
		FILTER_EXPANDED_MEDUIUM_SEVERITY_CHECKBOX("#infected-pages:not(.x-hide-display) .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(2) input"),
		FILTER_EXPANDED_LOW_SEVERITY_CHECKBOX("#infected-pages:not(.x-hide-display) .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(3) input");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public DetectionsTab() throws ElementNotFoundException{
		
		log.info(Utility.getCurrentUrl());
		//waitForPageMasking();
		waitForPageUnMasking();
		if (!Utility.isElementPresent(PageElements.DETECTIONS_TAB_TAB_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Scans>Detction List page");
		}
	}

	public DetectionsTab waitForPageMasking() {
		try {
			log.info("waiting for page to mask");
			Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY);
			return this;
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return this;
	}

	private DetectionsTab waitForPageUnMasking() {
		try {
			log.info("waiting for page to unmask");
			Utility.waitForElementPresent(PageElements.PAGE_LOADING_NOT_MASKED_VERIFY);
			return this;
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return this;

	}

	public DetectionsTab selectAllDetectionsCheckBox() throws ElementNotFoundException {
		if (Utility.isElementPresent(PageElements.ALL_DETECTIONS_CHECKBOX)) {

			log.info("Waiting for detections checkbox to be present");
			Utility.waitForElementPresent(PageElements.ALL_DETECTIONS_CHECKBOX);

			Utility.selectCheckBox(PageElements.ALL_DETECTIONS_CHECKBOX);
			log.info("Check box is selected");

		} else {
			throw new NoSuchElementException("All Detections checkbox is not present");
		}

		return this;
	}

	public DetectionsTab selectSingleDetectionCheckBox(String detectionName) {
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		Utility.selectCheckBoxOfSingleRecord(PageElements.EACH_DETECTIONS_ROWS, PageElements.EACH_DETECTIONS_CHECKBOX, superElement, detectionName);

		return this;
	}

	public DetectionsTab clickQuickActionsDropDown(String detectionName) throws ElementNotFoundException {

		log.info("Executing logic to find the record : " + detectionName + "clicking on quick action drop down button");
		Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_BTN);
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		Utility.selectQuickActionsOfSingleRecord(PageElements.EACH_PAGE_URL, PageElements.QUICK_ACTIONS_DOWN_BTN, superElement, detectionName);

		return this;

	}

	// TODO return type schedule View dialog
	public ThreatDetails selectQuickActionsView(String detectionName) throws ElementNotFoundException{

		clickQuickActionsDropDown(detectionName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW);
		return new ThreatDetails();
	}

	public NewScanEntireSiteDialog selectQuickActionsRescanPage(String detectionName) throws ElementNotFoundException {
		clickQuickActionsDropDown(detectionName);
		Utility.click(PageElements.QUICK_ACTIONS_DOWN_RESCAN_PAGE);
		return new NewScanEntireSiteDialog();
	}

	public DetectionsTab refreshScanListPage() {
		Utility.click(PageElements.REFRESH_PAGE_BTN);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab clickActionsDropDown() {
		if (!Utility.isElementPresent(PageElements.ACTIONS_DISABLED_DOWN_BTN) && Utility.isElementPresent(PageElements.ACTIONS_ENABLED_DOWN_BTN)) {
			Utility.click(PageElements.ACTIONS_ENABLED_DOWN_BTN);
		} else {
			throw new NoSuchElementException("Actions button is either disabled or not present on the page");
		}

		return this;
	}

	public DetectionsTab selectActionsView() {
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_VIEW)) {
			Utility.click(PageElements.ACTIONS_DOWN_VIEW);
		} else {
			throw new NoSuchElementException("Actions>view button is either disabled or not present on the page");
		}

		return this;
	}

	public NewScanEntireSiteDialog selectActionsRescanPage() throws ElementNotFoundException{
		clickActionsDropDown();
		if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_RESCAN_PAGE)) {
			Utility.click(PageElements.ACTIONS_DOWN_RESCAN_PAGE);
			waitForPageMasking();
			waitForPageUnMasking();
		} else {
			throw new NoSuchElementException("Actions>Rescan Again button is either disabled or not present on the page");
		}
		// change mode to automated
		return new NewScanEntireSiteDialog();
	}

	public DetectionsTab clickFilterDropDown() {

		Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
		return this;
	}

	public DetectionsTab selectFilterDownload() {
		clickFilterDropDown();
		Utility.click(PageElements.FILTER_SETTINGS_DOWNLOAD);
		return this;
	}

	public DetectionsTab selectFilterSortBy() {

		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);

		return this;
	}

	public DetectionsTab selectFilterSortByPageURL() throws ElementNotFoundException{

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_PAGE_URL);
		Utility.moveToElementAndClick(PageElements.SORT_BY_PAGE_URL);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab selectFilterSortByHigh() throws ElementNotFoundException{

		selectFilterSortBy();
		Utility.waitForElementPresent(PageElements.SORT_BY_HIGH_VULNS);
		Utility.moveToElementAndClick(PageElements.SORT_BY_HIGH_VULNS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab selectFilterRowsShown() {

		clickFilterDropDown();
		Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);
		return this;
	}

	public DetectionsTab selectFilterRowsShown20() throws ElementNotFoundException{

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab selectFilterRowsShown50() throws ElementNotFoundException{

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab selectFilterRowsShown100() throws ElementNotFoundException{

		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab selectFilterRowsShown200() throws ElementNotFoundException{
		selectFilterRowsShown();
		Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
		Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab SortPageURLFromHeader() {
		Utility.click(PageElements.LIST_HEADER_PAGE_URL);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab SortHighVulnsFromHeader()

	{
		Utility.click(PageElements.LIST_HEADER_HIGH_VULNS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab SortMediumVulnsFromHeader() {
		Utility.click(PageElements.LIST_HEADER_MEDIUM_VULNS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab SortLowVulnsFromHeader() {
		Utility.click(PageElements.LIST_HEADER_LOW_VULNS);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab SortSeverityFromHeader() {
		Utility.click(PageElements.LIST_HEADER_SEVERITY);
		waitForPageMasking();
		waitForPageUnMasking();
		return this;
	}

	public DetectionsTab leftPagingComboArrowButton() {
		if (Utility.isElementPresent(PageElements.PAGING_COMBO_LEFT_BTN)) {
			Utility.click(PageElements.PAGING_COMBO_LEFT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();

		} else {
			throw new IllegalStateException("Left button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public DetectionsTab rightPagingComboArrowButton() throws ElementNotFoundException{

		if (Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN) != null) {
			Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
			waitForPageMasking();
			waitForPageUnMasking();

		} else {

			throw new IllegalStateException("Right button to navigate to nextpage  element is disabled");
		}
		return this;
	}

	public DetectionsTab clickPagingComboDropDown() {
		Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
		return this;
	}

	// need waitforpageload
	public DetectionsTab selectPagingComboRange(int start, int end) throws ElementNotFoundException{

		clickPagingComboDropDown();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);
		WebElement superElelemnt = Utility.getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);

		Utility.selectFromCombo(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS, superElelemnt, start + " - " + end + " of " + end);
		System.out.println(start + " - " + end + " of " + end);
		return this;
	}

	public DetectionsTab clickLeftPanelSitesDataFilter(String siteName) throws ElementNotFoundException{
		Utility.waitForElementPresent(PageElements.LEFT_PANEL_FILTER_CONTAINER);
		WebElement superElement = Utility.getElement(PageElements.LEFT_PANEL_FILTER_CONTAINER);

		Utility.selectFromCombo(PageElements.LEFT_PANEL_FILTER_SITE_TITLE, superElement, siteName);
		selectRowsShownEqualToLeftPanelDetectionsFound(siteName);
		waitForPageMasking();
		waitForPageUnMasking();

		return this;
	}

	public DetectionsTab selectRowsShownEqualToLeftPanelDetectionsFound(String siteName) throws ElementNotFoundException{
		WebElement superElement = Utility.getElement(PageElements.LEFT_PANEL_FILTER_CONTAINER);
		String detectionsFound = Utility.selectLeftPanelRecordFilterGetText(PageElements.LEFT_PANEL_FILTER_SITE_TITLE, PageElements.LEFT_PANEL_FILTER_DETECTIONS_PERFORMED, superElement, siteName);
		String[] splitbyBrackets = detectionsFound.split("\\W");
		int numberOfDetectionsFound = Integer.parseInt(splitbyBrackets[3]);

		if (numberOfDetectionsFound <= 20) {
			selectFilterRowsShown20();
		} else if (numberOfDetectionsFound > 20 && numberOfDetectionsFound <= 50) {
			selectFilterRowsShown50();
		} else if (numberOfDetectionsFound > 50 && numberOfDetectionsFound <= 100) {
			selectFilterRowsShown100();
		} else if (numberOfDetectionsFound > 100 && numberOfDetectionsFound <= 200) {
			selectFilterRowsShown200();
		}

		return this;
	}

	public void selectRows() throws ElementNotFoundException{

		clickPagingComboDropDown();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);
		String pageRange = Utility.getTextOfPageObject(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);

		String[] splitRange = pageRange.split("\\W");
		int totalDetections = Integer.parseInt(splitRange[5]);

		if (totalDetections > 20 && totalDetections <= 50) {
			selectFilterRowsShown50();
			waitForPageMasking();
		}

		else if (totalDetections > 50 && totalDetections <= 100) {
			selectFilterRowsShown100();
			waitForPageMasking();
		}

		else if (totalDetections > 100 && totalDetections <= 200) {
			selectFilterRowsShown200();
			waitForPageMasking();
		}

	}

	public String getHighVulnsOfDetection(String detectionName) throws ElementNotFoundException{

		String numberOfHighVulns = "";
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.EACH_DETECTIONS_ROWS);
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		numberOfHighVulns = Utility.getTextOfRecordColumn(PageElements.EACH_PAGE_URL, PageElements.EACH_HIGH_VULNS, superElement, detectionName);
		return numberOfHighVulns;
	}

	public String getMedVulnsOfDetection(String detectionName) throws ElementNotFoundException{

		String numberOfMedVulns = "";
		selectRows();
		waitForPageUnMasking();
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		numberOfMedVulns = Utility.getTextOfRecordColumn(PageElements.EACH_PAGE_URL, PageElements.EACH_MEDIUM_VULNS, superElement, detectionName);
		return numberOfMedVulns;
	}

	public String getLowVulnsOfDetection(String detectionName) throws ElementNotFoundException{

		String numberOfLowVulns = "";
		selectRows();
		waitForPageUnMasking();
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		numberOfLowVulns = Utility.getTextOfRecordColumn(PageElements.EACH_PAGE_URL, PageElements.EACH_LOW_VULNS, superElement, detectionName);
		return numberOfLowVulns;
	}

	// TODO -Severity is an image
	public String getSeverityOfDetection(String detectionName) throws ElementNotFoundException{

		String numberOfLowVulns = "";
		selectRows();
		waitForPageUnMasking();
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		numberOfLowVulns = Utility.getTextOfRecordColumn(PageElements.EACH_PAGE_URL, PageElements.EACH_DETECTIONS_SEVERITY, superElement, detectionName);
		return numberOfLowVulns;
	}

	public StringBuffer getAllPageURLText() throws ElementNotFoundException{
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.EACH_DETECTIONS_ROWS);
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		List<WebElement> detectionsPageURLWebElement = Utility.getRecordWebEements(PageElements.EACH_PAGE_URL, superElement);
		StringBuffer allPageURLs = new StringBuffer();
		for (int scanTitleRow = 0; scanTitleRow < detectionsPageURLWebElement.size(); scanTitleRow++) {
			allPageURLs.append(detectionsPageURLWebElement.get(scanTitleRow).getText() + "\n");
		}
		return allPageURLs;
	}

	public StringBuffer getAllHighVulnsText() throws ElementNotFoundException{
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.EACH_DETECTIONS_ROWS);
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		List<WebElement> highVulnsWebElements = Utility.getRecordWebEements(PageElements.EACH_HIGH_VULNS, superElement);
		StringBuffer allhighVulns = new StringBuffer();
		for (int scanDateRow = 0; scanDateRow < highVulnsWebElements.size(); scanDateRow++) {
			allhighVulns.append(highVulnsWebElements.get(scanDateRow).getText() + "\n");
		}
		return allhighVulns;
	}

	public StringBuffer getAllMediumVulnsText() throws ElementNotFoundException{
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.EACH_DETECTIONS_ROWS);
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		List<WebElement> mediumVulnsWebElements = Utility.getRecordWebEements(PageElements.EACH_MEDIUM_VULNS, superElement);
		StringBuffer allMediumVulns = new StringBuffer();
		for (int scanDateRow = 0; scanDateRow < mediumVulnsWebElements.size(); scanDateRow++) {
			allMediumVulns.append(mediumVulnsWebElements.get(scanDateRow).getText() + "\n");
		}
		return allMediumVulns;
	}

	public StringBuffer getAllLowVulns() throws ElementNotFoundException{
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.EACH_DETECTIONS_ROWS);
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		List<WebElement> lowVulnsWebElements = Utility.getRecordWebEements(PageElements.EACH_LOW_VULNS, superElement);
		StringBuffer allLowVulns = new StringBuffer();
		for (int scannedPagesRow = 0; scannedPagesRow < lowVulnsWebElements.size(); scannedPagesRow++) {
			allLowVulns.append(lowVulnsWebElements.get(scannedPagesRow).getText() + "\n");
		}
		return allLowVulns;
	}

	public StringBuffer getAllSeverity() throws ElementNotFoundException{
		selectRows();
		waitForPageUnMasking();
		Utility.waitForElementPresent(PageElements.EACH_DETECTIONS_ROWS);
		WebElement superElement = Utility.getElement(PageElements.EACH_DETECTIONS_ROWS);

		List<WebElement> severityWebElements = Utility.getRecordWebEements(PageElements.EACH_DETECTIONS_SEVERITY, superElement);
		StringBuffer allSeverity = new StringBuffer();
		for (int statusRow = 0; statusRow < severityWebElements.size(); statusRow++) {
			allSeverity.append(severityWebElements.get(statusRow).getText() + "\n");
		}
		return allSeverity;
	}

	// FILTERS EXPANDED NAVIGATION(SHOW FILTERS)
	public DetectionsTab clickShowFilters() {
		Utility.click(PageElements.SHOW_FILTER);
		return this;
	}

	public DetectionsTab filterByTags(String tagName) throws ElementNotFoundException{

		Utility.click(PageElements.FILTER_EXPANDED_TAG_DROPDOWN);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		WebElement superElement = Utility.getElement(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER);

		Utility.waitForElementPresent(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS);

		Utility.selectMultipleValuesDoubleClick(PageElements.FILTER_EXPANDED_TAG_DROPDOWN_CONTAINER_ITEMS, superElement, tagName);

		return this;
	}

	public DetectionsTab typeSiteTitletoFilter(String scanURL) {
		Utility.click(PageElements.FILTER_EXPANDED_SITE_TITLE_TEXT_FIELD);
		return this;
	}

	public DetectionsTab filterBySiteURL(String scanURL) {
		Utility.click(PageElements.FILTER_EXPANDED_SITE_URL_TEXT_FIELD);
		return this;
	}

	public DetectionsTab filterBySeverity(String highORmediumORlowORsafe) {
		if (highORmediumORlowORsafe.equalsIgnoreCase("high")) {
			Utility.click(PageElements.FILTER_EXPANDED_HIGH_SEVERITY_CHECKBOX);
		} else if (highORmediumORlowORsafe.equalsIgnoreCase("medium")) {
			Utility.click(PageElements.FILTER_EXPANDED_MEDUIUM_SEVERITY_CHECKBOX);
		} else if (highORmediumORlowORsafe.equalsIgnoreCase("low")) {
			Utility.click(PageElements.FILTER_EXPANDED_LOW_SEVERITY_CHECKBOX);
		}

		return this;
	}

	public DetectionsTab clickHideFilters() {
		Utility.click(PageElements.HIDE_FILTER);
		return this;
	}

	public DetectionsTab clickClearFilters() {
		Utility.click(PageElements.CLEAR_FILTER);
		return this;
	}
}
