package com.qualys.selenium.mds.pageobject.knowledgebase;

import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.MalwarePage;



public class KnowledgeBaseTab extends MalwarePage{
    
    
    public enum PageElements implements IPageElement {
        
        KB_LIST_TAB_VERIFY("#malware-kb:not(.x-hide-display)"),
        PAGE_LOADING_MASKED_VERIFY("#malware-kb:not(.x-hide-display) .mds-domain-datalist .q-datalist.x-masked .q-datalist-bwrap.x-masked"),
        PAGE_LOADING_NOT_MASKED_VERIFY("#malware-kb:not(.x-hide-display) .mds-domain-datalist .q-datalist:not(.x-masked) .q-datalist-bwrap:not(.x-masked)"),
           
        
           
           REFRESH_PAGE_BTN("#malware-kb:not(.x-hide-display) .x-small-editor .x-toolbar-right .x-tbar-loading"),
           //MDS_AssetsPage_SitesTab_AfterRefreshPage_WaitFor=.content-panel
           
           FILTER_SETTINGS_DROPDOWN("#malware-kb:not(.x-hide-display) .x-small-editor .x-toolbar-right .dlist_view_btn"),
           FILTER_SETTINGS_SORT_BY("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Sort By')]",IdentifiedBy.XPATH),
              SORT_BY_QID("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
              SORT_BY_NAME("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
              SORT_BY_SEVERITY("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
             
           FILTER_SETTINGS_ROWS_SHOWN("//div[contains(@class,'q_view_menu') and not(contains(@class,' x-hide-offsets'))]//ul//li//a//span[contains(text(),'Rows Shown')]",IdentifiedBy.XPATH),
              ROWS_SHOWN_20("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(1)"),
              ROWS_SHOWN_50("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(2)"),
              ROWS_SHOWN_100("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(3)"),
              ROWS_SHOWN_200("div.x-layer:not(.x-hide-offsets):not(.q_view_menu) .x-menu-list li:nth-child(4)"),
              
           PAGING_COMBO_LEFT_BTN("#malware-kb:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row .first:not(.x-item-disabled)"),
           PAGING_COMBO_RIGHT_BTN("#malware-kb:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row .last:not(.x-item-disabled)"),
           PAGING_COMBO_RANGE_DROPDOWN_TRIGGER("#malware-kb:not(.x-hide-display) .q-datalist-tbar.q-datalist-tbar-noheader .x-toolbar-right tr.x-toolbar-right-row input[name=pagingCombo]"),
           PAGING_COMBO_RANGE_DROPDOWN_CONTAINER(".x-combo-list"),
           PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS(".x-combo-list-item"),
           
           PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM(".x-combo-list .x-combo-list-item:nth-child(1)"),
           
           
           
           ALL_REPORT_CHECKBOX("#malware-kb:not(.x-hide-display) .datalist-container .q-datalist-body .x-grid3-header table .x-grid3-hd-checker"),
           
           EACH_KB_ROWS("#malware-kb:not(.x-hide-display) .datalist-container .x-grid3-scroller"),//SUPER ELEMENT
           EACH_KB_QID("//div[contains(@class,'viewport')]//div[2]//td[contains(@class,'reportTitle')]/div[contains(@class,'col-reportTitle')]",IdentifiedBy.XPATH),//SUB ELEMENT
           EACH_KB_NAME("//div[contains(@class,'viewport')]//div[2]//td[contains(@class,'reportType')]/div[contains(@class,'col-reportType')]",IdentifiedBy.XPATH),//SUB ELEMENT
           EACH_KB_SEVERITY("//div[contains(@class,'viewport')]//div[2]//td[contains(@class,'reportDefType')]/div[contains(@class,'col-reportDefType')]",IdentifiedBy.XPATH),//SUB ELEMENT
          
           
           EACH_REPORT_CHECKBOX("#malware-kb:not(.x-hide-display) .datalist-container .x-grid3-scroller .x-grid3-td-checker.x-grid3-cell-first"),
           
           ACTIONS_DOWN_BTN("#malware-kb:not(.x-hide-display) .actionBtn:not(.x-item-disabled)"),
           ACTIONS_DOWN_VIEW("//li[1][not(contains(@class,'x-item-disabled'))]//span[contains(@class,'x-menu-item-text') and contains(text(),'View')]",IdentifiedBy.XPATH),
          
               
           QUICK_ACTIONS_DOWN_BTN("#malware-kb:not(.x-hide-display) .q-quick-menu-column"),
           QUICK_ACTIONS_DOWN_QUICK_ACTIONS_LABEL("li.x-menu-list-item:not(.x-item-disabled):nth-child(1) "),
           QUICK_ACTIONS_DOWN_VIEW("li.x-menu-list-item:not(.x-item-disabled):nth-child(2) "),
          

          //PENDING TO TEST NAVIGATION
          SHOW_FILTER("#malware-kb:not(.x-hide-display) .filter-summary-panel .filter-buttons"),
          CLEAR_FILTER("#malware-kb:not(.x-hide-display) .filter-summary-panel .filter-buttons .clear-filters-link"),
          HIDE_FILTER("#malware-kb:not(.x-hide-display) .filter-summary-panel .filter-buttons .toggle-filter-link"),
          FILTER_APPLIED_NUMBER("#malware-kb:not(.x-hide-display) .filter-summary-panel .filter-count span b"),
          
          
         // FILTER_EXPANDED_SEARCH_TEXT_FIELD("#malware-kb:not(.x-hide-display) .filter-panel-expanded .filter-panel:not(.x-hide-display) .filter-column-panel-start .filter-hide-label input"),
          
          FILTER_EXPANDED_HIGH_SEVERITY_CHECKBOX("#malware-kb:not(.x-hide-display) .filter-column-panel-start .filter-panel-column-body>div:nth-child(1) div.x-hide-label:first-of-type input"),
          FILTER_EXPANDED_MEDUIUM_SEVERITY_CHECKBOX("#malware-kb:not(.x-hide-display) .filter-column-panel-start .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(2) input"),
          FILTER_EXPANDED_LOW_SEVERITY_CHECKBOX("#malware-kb:not(.x-hide-display) .filter-column-panel-start .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(3) input"),
          FILTER_EXPANDED_SAFE_SEVERITY_CHECKBOX("#malware-kb:not(.x-hide-display) .filter-column-panel-start .filter-panel-column-body>div:nth-child(1) div.x-hide-label:nth-of-type(4) input");
          
         
       String key;
       IdentifiedBy identifiedBy;

       PageElements(String key, IdentifiedBy identifiedBy) {
           this.key = key;
           this.identifiedBy = identifiedBy;
       }

       PageElements(String key) {
           this(key, IdentifiedBy.CSS);
       }

       @Override
       public String getLocator() {
           // TODO Auto-generated method stub
           return this.key;
       }

       @Override
       public IdentifiedBy getIdentifiedBy() {
           // TODO Auto-generated method stub
           return this.identifiedBy;
       }

   }
	public static final String PAGE_CONSTANTS_STARTS_WITH = "MDS_KnowledgeBaseTab_";
	public KnowledgeBaseTab() throws ElementNotFoundException{
		super(MalwareLandingPage.KNOWLEDGEBASE);
		
	}
	
	 public KnowledgeBaseTab clickShowFilters()
	    {
	        Utility.click(PageElements.SHOW_FILTER);
	        return this;
	    }
	    
	    public KnowledgeBaseTab waitForPageMasking() throws ElementNotFoundException {
	        Utility.waitForElementPresent(PageElements.PAGE_LOADING_MASKED_VERIFY);
	        return this;
	    }

	    private KnowledgeBaseTab waitForPageUnMasking() throws ElementNotFoundException {
	        Utility.waitForElementPresent(PageElements.PAGE_LOADING_NOT_MASKED_VERIFY);
	        return this;

	    }

	    // TODO Passing but not clinking.
	    public KnowledgeBaseTab selectAllSitesCheckBox() throws ElementNotFoundException {
	        Utility.waitForElementPresent(PageElements.ALL_REPORT_CHECKBOX);
	        if (Utility.isElementPresent(PageElements.ALL_REPORT_CHECKBOX)) {

	            Utility.selectCheckBox(PageElements.ALL_REPORT_CHECKBOX);

	        } else {
	            throw new NoSuchElementException(
	                    "All Sites checkbox is not present");
	        }

	        return this;
	    }

	    // TODO Passing but not clinking.
	    public KnowledgeBaseTab selectSingleScheduleCheckBox(String qIDNumber) throws ElementNotFoundException{
	        Utility.waitForElementPresent(PageElements.EACH_KB_ROWS);
	        WebElement superElement = Utility
	                .getElement(PageElements.EACH_KB_ROWS);

	        Utility.selectCheckBoxOfSingleRecord(PageElements.EACH_KB_QID,PageElements.EACH_REPORT_CHECKBOX,superElement,qIDNumber);

	        return this;
	    }

	    public KnowledgeBaseTab clickQuickActionsDropDown(String qIDNumber) throws ElementNotFoundException{

	        Utility.waitForElementPresent(PageElements.QUICK_ACTIONS_DOWN_BTN);
	        WebElement superElement = Utility
	                .getElement(PageElements.EACH_KB_ROWS);

	        Utility.selectQuickActionsOfSingleRecord(PageElements.EACH_KB_QID, PageElements.QUICK_ACTIONS_DOWN_BTN,
	                superElement,qIDNumber);

	        return this;

	    }

	    // TODO return type schedule View dialog
	    public KnowledgeBaseTab selectQuickActionsView(String qIDNumber) throws ElementNotFoundException{

	        clickQuickActionsDropDown(qIDNumber);
	        Utility.click(PageElements.QUICK_ACTIONS_DOWN_VIEW);
	        return this;
	    }

	  
	   

	    public KnowledgeBaseTab refreshNewReportsPage() throws ElementNotFoundException{
	        Utility.waitForElementPresent(PageElements.REFRESH_PAGE_BTN);
	        Utility.click(PageElements.REFRESH_PAGE_BTN);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }

	    public KnowledgeBaseTab clickActionsDropDown() {
	        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_BTN)) {
	            Utility.click(PageElements.ACTIONS_DOWN_BTN);
	        } else {
	            throw new NoSuchElementException(
	                    "Actions button is either disabled or not present on the page");
	        }

	        return this;
	    }

	    public KnowledgeBaseTab selectActionsView() {
	        clickActionsDropDown();
	        if (Utility.isElementPresent(PageElements.ACTIONS_DOWN_VIEW)) {
	            Utility.click(PageElements.ACTIONS_DOWN_VIEW);
	        } else {
	            throw new NoSuchElementException(
	                    "Actions>view button is either disabled or not present on the page");
	        }

	        return this;
	    }
 

	    public KnowledgeBaseTab clickFilterDropDown() {

	        Utility.click(PageElements.FILTER_SETTINGS_DROPDOWN);
	        return this;
	    }

	   

	    public KnowledgeBaseTab selectFilterSortBy() {

	        clickFilterDropDown();
	        Utility.moveToElement(PageElements.FILTER_SETTINGS_SORT_BY);

	        return this;
	    }

	    public KnowledgeBaseTab selectFilterSortByName() throws ElementNotFoundException{

	        selectFilterSortBy();
	        Utility.waitForElementPresent(PageElements.SORT_BY_QID);
	        Utility.moveToElementAndClick(PageElements.SORT_BY_QID);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }

	    public KnowledgeBaseTab selectFilterSortByFormat() throws ElementNotFoundException{
	        selectFilterSortBy();
	        Utility.waitForElementPresent(PageElements.SORT_BY_NAME);
	        Utility.moveToElementAndClick(PageElements.SORT_BY_NAME);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }

	    public KnowledgeBaseTab selectFilterSortByType() throws ElementNotFoundException{

	        selectFilterSortBy();
	        Utility.waitForElementPresent(PageElements.SORT_BY_SEVERITY);
	        Utility.moveToElementAndClick(PageElements.SORT_BY_SEVERITY);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }
	    
	   
	    
	   

	    public KnowledgeBaseTab selectFilterRowsShown() {

	        clickFilterDropDown();
	        Utility.moveToElement(PageElements.FILTER_SETTINGS_ROWS_SHOWN);
	        return this;
	    }

	    public KnowledgeBaseTab selectFilterRowsShown20() throws ElementNotFoundException{

	        selectFilterRowsShown();
	        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_20);
	        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_20);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }

	    public KnowledgeBaseTab selectFilterRowsShown50() throws ElementNotFoundException{

	        selectFilterRowsShown();
	        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_50);
	        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_50);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }

	    public KnowledgeBaseTab selectFilterRowsShown100() throws ElementNotFoundException{

	        selectFilterRowsShown();
	        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_100);
	        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_100);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }

	    public KnowledgeBaseTab selectFilterRowsShown200() throws ElementNotFoundException{
	        selectFilterRowsShown();
	        Utility.waitForElementPresent(PageElements.ROWS_SHOWN_200);
	        Utility.moveToElementAndClick(PageElements.ROWS_SHOWN_200);
	        waitForPageMasking();
	        waitForPageUnMasking();
	        return this;
	    }

	   

	    public KnowledgeBaseTab leftPagingComboArrowButton() throws ElementNotFoundException{
	        if (Utility.isElementPresent(PageElements.PAGING_COMBO_LEFT_BTN)) {
	            Utility.click(PageElements.PAGING_COMBO_LEFT_BTN);
	            waitForPageMasking();
	            waitForPageUnMasking();

	        } else {
	            throw new IllegalStateException(
	                    "Left button to navigate to nextpage  element is disabled");
	        }
	        return this;
	    }

	    public KnowledgeBaseTab rightPagingComboArrowButton() throws ElementNotFoundException{

	        if (Utility.waitForElementPresent(PageElements.PAGING_COMBO_RIGHT_BTN) != null) {
	            Utility.click(PageElements.PAGING_COMBO_RIGHT_BTN);
	            waitForPageMasking();
	            waitForPageUnMasking();

	        } else {

	            throw new IllegalStateException(
	                    "Right button to navigate to nextpage  element is disabled");
	        }
	        return this;
	    }

	    public KnowledgeBaseTab clickPagingComboDropDown() {
	        Utility.click(PageElements.PAGING_COMBO_RANGE_DROPDOWN_TRIGGER);
	        return this;
	    }

	    // need waitforpageload
	    public KnowledgeBaseTab selectPagingComboRange(int start, int end) throws ElementNotFoundException{

	        clickPagingComboDropDown();
	        Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);
	        WebElement superElelemnt = Utility
	                .getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER);

	        Utility.selectFromCombo(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_ITEMS, superElelemnt, start + " - " + end + " of "
	                        + end);
	        System.out.println(start + " - " + end + " of " + end);
	        return this;
	    }

	   /* public void selectRows() {

	        clickPagingComboDropDown();
	        waitForPageUnMasking();
	        Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH
	                + "Filter_Middle_PagingCombo_FirstRange_Navigation",
	                IdentifiedBy.CSS);
	        String pageRange = Utility.getTextOfPageObject(
	                PAGE_CONSTANTS_STARTS_WITH
	                        + "Filter_Middle_PagingCombo_FirstRange_Navigation",
	                IdentifiedBy.CSS);

	        String[] splitRange = pageRange.split("\\W");
	        int totalSites = Integer.parseInt(splitRange[5]);

	        if (totalSites > 20 && totalSites <= 50) {
	            selectFilterRowsShown50();
	            Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH
	                    + "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS);
	        }

	        else if (totalSites > 50 && totalSites <= 100) {
	            selectFilterRowsShown100();
	            Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH
	                    + "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS);
	        }

	        else if (totalSites > 100 && totalSites <= 200) {
	            selectFilterRowsShown200();
	            Utility.waitForElementPresent(PAGE_CONSTANTS_STARTS_WITH
	                    + "Filter_PageLoading_Masked_Verify", IdentifiedBy.CSS);
	        }

	    }
	*/
	    
	    
	   
	    
	    
	    
	    public String getFormatOfReport(String qIDNumber) throws ElementNotFoundException{

	        String siteURLOfAsset;

	        Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);
	        WebElement superElement = Utility
	                .getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);

	        Utility.waitForElementPresent(PageElements.EACH_KB_QID);
	        siteURLOfAsset = Utility.getTextOfRecordColumn(PageElements.EACH_KB_QID,
	                PageElements.EACH_KB_NAME,
	                superElement,qIDNumber);
	        return siteURLOfAsset;
	    }
	    
	     
	    public String getNameOfKB(String qIDNumber) throws ElementNotFoundException {

	        String siteURLOfAsset;

	        Utility.waitForElementPresent(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);
	        WebElement superElement = Utility
	                .getElement(PageElements.PAGING_COMBO_RANGE_DROPDOWN_CONTAINER_FIRST_ITEM);

	        Utility.waitForElementPresent(PageElements.EACH_KB_QID);
	        siteURLOfAsset = Utility.getTextOfRecordColumn(PageElements.EACH_KB_QID,
	                PageElements.EACH_KB_NAME,
	                superElement,qIDNumber);
	        return siteURLOfAsset;
	    }

	    //TODO Workssome times. 
	    public String getSeverityOfKB(String qIDNumber) throws ElementNotFoundException{

	        String tagOfAsset;

	        Utility.waitForElementPresent(PageElements.EACH_KB_ROWS);
	        WebElement superElement = Utility
	                .getElement(PageElements.EACH_KB_ROWS);

	        tagOfAsset = Utility.getTextOfRecordColumn(PageElements.EACH_KB_QID,
	                PageElements.EACH_KB_SEVERITY,
	                superElement, qIDNumber);
	        return tagOfAsset;
	    }

	    public StringBuffer getAllNamesText() throws ElementNotFoundException{

	        Utility.waitForElementPresent(PageElements.EACH_KB_ROWS);
	        WebElement superElement = Utility
	                .getElement(PageElements.EACH_KB_NAME);

	        Utility.waitForElementPresent(PageElements.EACH_KB_QID);
	        List<WebElement> assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_KB_QID,superElement);
	        StringBuffer allReportNames = new StringBuffer();
	        for (int siteTitleRow = 0; siteTitleRow < assetSiteURLWebElement.size(); siteTitleRow++) {
	            allReportNames.append(assetSiteURLWebElement.get(siteTitleRow)
	                    .getText() + "\n");
	        }
	        return allReportNames;
	    }
	    
	    public StringBuffer getAllSeverityText() throws ElementNotFoundException{

	        Utility.waitForElementPresent(PageElements.EACH_KB_ROWS);
	        WebElement superElement = Utility
	                .getElement(PageElements.EACH_KB_SEVERITY);

	        Utility.waitForElementPresent(PageElements.EACH_KB_QID);
	        List<WebElement> assetSiteURLWebElement = Utility.getRecordWebEements(PageElements.EACH_KB_NAME,superElement);
	        StringBuffer allFormats = new StringBuffer();
	        for (int siteTitleRow = 0; siteTitleRow < assetSiteURLWebElement.size(); siteTitleRow++) {
	            allFormats.append(assetSiteURLWebElement.get(siteTitleRow)
	                    .getText() + "\n");
	        }
	        return allFormats;
	    }

	   
	   
	    //FILTERS EXPANDED NAVIGATION(SHOW FILTERS)
	    public KnowledgeBaseTab filterBySeverity(String highORmediumORlowORsafe)
	    {
	        if(highORmediumORlowORsafe.equalsIgnoreCase("high"))
	        {
	            Utility.click(PageElements.FILTER_EXPANDED_HIGH_SEVERITY_CHECKBOX);
	        }
	        else if(highORmediumORlowORsafe.equalsIgnoreCase("medium"))
	        {
	            Utility.click(PageElements.FILTER_EXPANDED_MEDUIUM_SEVERITY_CHECKBOX);
	        }
	        else if(highORmediumORlowORsafe.equalsIgnoreCase("low"))
	        {
	            Utility.click(PageElements.FILTER_EXPANDED_LOW_SEVERITY_CHECKBOX);
	        }
	        else if(highORmediumORlowORsafe.equalsIgnoreCase("safe"))
	        {
	            Utility.click(PageElements.FILTER_EXPANDED_SAFE_SEVERITY_CHECKBOX);
	        }
	        return this;
	    }
	    
	    
	    
	    
	    public KnowledgeBaseTab clickHideFilters()
	    {
	        Utility.click(PageElements.HIDE_FILTER);
	        return this;
	    }
	    public KnowledgeBaseTab clickClearFilters()
	    {
	        Utility.click(PageElements.CLEAR_FILTER);
	        return this;
	    }
}