package com.qualys.selenium.questionnaire.pageobject.Library;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.questionnaire.pageobject.QuestionnairePage;

@Slf4j
public class TemplatesTab extends QuestionnairePage {

	public enum PageElements implements IPageElement {

		TEMPLATE_TAB_VERIFY("#FrameModuleCardPanel #template-list:not(.x-hide-display)"),
		NEW_TEMPLATE_DROPDOWN("#template-list #template-main-panel div[class*=filter-list-toolbar] tr[class*=toolbar-left-row] > td:nth-of-type(3) > table"),
		NEW_TEMPLATE_BLANK_TEMPLATE("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(1)"),
		NEW_TEMPLATE_FROM_TEMPLATE_XML("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(2)"),
		NEW_VERSION_DROPDOWN("#template-list #datalist-templates #template-main-panel div[class*=filter-list-toolbar] tr[class*=toolbar-left-row] > td:nth-of-type(5) > table"),
		NEW_VERSION_BLANK_TEMPLATE("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(1)"),
		NEW_VERSION_FROM_TEMPLATE_XML("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(2)"),
		NEW_VERSION_COPY_OF_PUBLISHED("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(3)");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public TemplatesTab() throws ElementNotFoundException {
		super(QuestionnaireLandingPage.LIBRARY);

		if (!Utility.isElementPresent(PageElements.TEMPLATE_TAB_VERIFY)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());

			throw new IllegalStateException("This is not the Questionnaire  > Templated tab page");
		}
	}

	public TemplatesTab clickOnNewTemplate() {
		Utility.click(PageElements.NEW_TEMPLATE_DROPDOWN);
		return this;
	}

	public BlankTemplate clickBlankTemplate() throws ElementNotFoundException {
		clickBlankTemplate();
		Utility.click(PageElements.NEW_TEMPLATE_BLANK_TEMPLATE);
		return new BlankTemplate();
	}

}
