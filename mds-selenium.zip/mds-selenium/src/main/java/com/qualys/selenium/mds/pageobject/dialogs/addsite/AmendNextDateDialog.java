package com.qualys.selenium.mds.pageobject.dialogs.addsite;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;

@Slf4j
public class AmendNextDateDialog extends SchedulingStep {

	public enum PageElements implements IPageElement {

		STEP_VERIFY("//div[contains(@class,'q-dialog')]", IdentifiedBy.XPATH),
		STEP_VERIFY_AFTER_FILLING(".step-scheduling:not(.middle-inactive).middle-passed"),

		CANCEL_BTN_AMEND_NEXT_DATE_DIALOGUE(
				"//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-footer')]//table[contains(@class,'q-btn-gray-light')]//button[text()='Cancel']",
				IdentifiedBy.XPATH),

		// Amend schedule
		KEEP_CURRENT_SELECTION_RADIO_BTN(
				"//div[contains(@class,'dialog')]//div[contains(@class,'column')]//div[1]//div[contains(@class,'form-element')]//input[@name='selectionRadio']",
				IdentifiedBy.XPATH),
		CHANGE_START_DATE_RADIO_BTN("//div[contains(@class,'dialog')]//div[contains(@class,'column')]//div[2]//div[contains(@class,'form-element')]//input[@name='selectionRadio']"),
		DATE_OPTION_ONE(
				"//div[contains(@class,'dialog')]//form[contains(@class,'panel-body-noheader')]//div[3]//div[contains(@class,'form-radio-group')]//div[contains(@class,'column')]//div//div[1]//input[@name='choiceRadio']",
				IdentifiedBy.XPATH),
		DATE_OPTION_TWO(
				"//div[contains(@class,'dialog')]//form[contains(@class,'panel-body-noheader')]//div[3]//div[contains(@class,'form-radio-group')]//div[contains(@class,'column')]//div//div[2]//input[@name='choiceRadio']",
				IdentifiedBy.XPATH),
		DATE_OPTION_THREE(
				"//div[contains(@class,'dialog')]//form[contains(@class,'panel-body-noheader')]//div[3]//div[contains(@class,'form-radio-group')]//div[contains(@class,'column')]//div//div[3]//input[@name='choiceRadio']",
				IdentifiedBy.XPATH),
		DATE_OPTION_FOUR(
				"//div[contains(@class,'dialog')]//form[contains(@class,'panel-body-noheader')]//div[3]//div[contains(@class,'form-radio-group')]//div[contains(@class,'column')]//div//div[4]//input[@name='choiceRadio']",
				IdentifiedBy.XPATH),
		DATE_OPTION_FIVE(
				"//div[contains(@class,'dialog')]//form[contains(@class,'panel-body-noheader')]//div[3]//div[contains(@class,'form-radio-group')]//div[contains(@class,'column')]//div//div[5]//input[@name='choiceRadio']",
				IdentifiedBy.XPATH),

		PREVIOUS_FIVE_DATES_BTN("//div[contains(@class,'dialog')]//form[contains(@class,'panel-body-noheader')]/div[4]//table[1]", IdentifiedBy.XPATH),
		NEXT_FIVE_DATES_bTN("//div[contains(@class,'dialog')]//form[contains(@class,'panel-body-noheader')]/div[4]//table[2]", IdentifiedBy.XPATH);

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public AmendNextDateDialog(AddSiteDialogMode mode) throws SiteCreationMaxedOutException, ElementNotFoundException {
		super(mode);
		if (Utility.waitForElementPresent(PageElements.STEP_VERIFY) == null) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the AddSite>Scheduling page");
		}
	}

	public boolean isAmendNextDatePresent() {
		return Utility.isElementPresent(PageElements.STEP_VERIFY);

	}

	public AmendNextDateDialog selectCurrentSelectionRadioBtn() {
		Utility.selectRadioButton(PageElements.KEEP_CURRENT_SELECTION_RADIO_BTN);
		return this;
	}

	public AmendNextDateDialog selectChangeStartDateRadioBtn() {
		Utility.selectRadioButton(PageElements.CHANGE_START_DATE_RADIO_BTN);
		return this;
	}

	public AmendNextDateDialog changeDateTo(String optionNumberToSelectDate) {
		try {
			if (optionNumberToSelectDate.equalsIgnoreCase("option1")) {
				Utility.selectRadioButton(PageElements.DATE_OPTION_ONE);

			} else if (optionNumberToSelectDate.equalsIgnoreCase("option2")) {
				Utility.selectRadioButton(PageElements.DATE_OPTION_TWO);
			} else if (optionNumberToSelectDate.equalsIgnoreCase("option3")) {
				Utility.selectRadioButton(PageElements.DATE_OPTION_THREE);
			} else if (optionNumberToSelectDate.equalsIgnoreCase("option4")) {
				Utility.selectRadioButton(PageElements.DATE_OPTION_FOUR);
			} else if (optionNumberToSelectDate.equalsIgnoreCase("option5")) {
				Utility.selectRadioButton(PageElements.DATE_OPTION_FIVE);
			}
		} catch (Exception e) {
			log.error("Please select either option1, option2, option3, option4, option5 to change start date");
		}

		return this;
	}

	public SchedulingStep clickCancelOnAmendScheduleDialog() {
		Utility.click(PageElements.CANCEL_BTN_AMEND_NEXT_DATE_DIALOGUE);
		return this;
	}

}
