package com.qualys.selenium.questionnaire.pageobject;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.core.pageobject.AbstractFrame;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.assets.SitesTab;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.pageobject.reports.ReportsPage;
import com.qualys.selenium.mds.pageobject.scans.ScansPage;

@Slf4j
public class QuestionnairePage extends AbstractFrame {
	// public static final String PAGE_CONSTANTS_STARTS_WITH = "MDS_";
	public enum QuestionnaireLandingPage {

		DASHBOARD(""),
		QUESTIONNAIRE("scans"),
		REPORTS("reports"),
		LIBRARY("assets");
		String uiValue;

		QuestionnaireLandingPage(String uiValue) {
			this.uiValue = uiValue;
		}

		public String getUiValue() {
			return this.uiValue;
		}
	}

	public enum PageElements implements IPageElement {

		// the page loading check is not exactly correct
		// TODO: Developer should add a unique id - to verify each module
		DASHBOARD_LABEL("#ModuleTabsPanel .module-tabs-tab:nth-child(2)"),
		QUESTIONNAIRE_LABEL("#ModuleTabsPanel .module-tabs-tab:nth-child(3)"),
		REPORTS_LABEL("#ModuleTabsPanel .module-tabs-tab:nth-child(4)"),
		LIBRARY_LABEL("#ModuleTabsPanel .module-tabs-tab:nth-child(5)"),

		QUESTIONNAIRE_SERVICE_LABEL("#FrameMenu table tr:nth-child(2) button[type=button]"),
		HELP_LABEL("#FrameMenu table:nth-child(6) tr:nth-child(2) button[type='button']"),
		USER_NAME_LABEL("#FrameMenu table:nth-child(7) tr:nth-child(2) button[type='button']"),
		LOG_OUT_LABEL("#FrameMenu table:nth-child(8) button"),

		ABOUT_LABEL(".footer #frame-about"),
		TERMS_OF_USE_LABEL(".footer #frame-terms-use"),
		SUPPORT_LABEL(".footer #frame-support"),

		QUESTIONNAIRE_MODULE_CHECK("#FrameModuleCardPanel #questionnaire-home"),

		//DASHBOARD_TAB_CHECK("#FrameModuleCardPanel div:not(.x-hide-display)[class*=questionnaire-dashboard]"), // ("div:not(#page-loading-frame)"),
		DASHBOARD_TAB_CHECK("#FrameModuleCardPanel #questionnaire-home"),
		QUESTIONNAIRE_LIST_TAB_CHECK("#FrameModuleCardPanel #questionnaire-list:not(.x-hide-display)"),
		REPORT_TAB_CHECK("#FrameModuleCardPanel #reports-list:not(.x-hide-display)"),
		LIBRARY_TAB_CHECK("#FrameModuleCardPanel #template-list:not(.x-hide-display)");

		/*
		 * // NOTIFICATION_DIALOGE_PRESENT(".notifier-mr h3"),
		 * NOTIFICATION_DIALOGE_PRESENT
		 * ("div:first-of-type[class*=success] div[class*=-notifier-mc]"),
		 * SITE_CREATION_MASK_LOAD(
		 * ".malware-site-object-window div[class*=-masked-relative] div[class*=-mask-loading]"
		 * ), SITE_CREATION_ERROR(
		 * "//div[contains(@class,'dialog-error')]//div[text()='Site Creation']"
		 * , IdentifiedBy.XPATH),
		 * SITE_CREATION_ERROR_TEXT(".dialog-error .message"),
		 * 
		 * SITE_CREATION_ERROR_OK_BUTN(".dialog-error button[type=button]");
		 */

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}

	public QuestionnairePage(QuestionnaireLandingPage questionnaireLandingPage) throws ElementNotFoundException {

		// Utility.waitForElementPresent(PageElements.MALWARE_PAGE_CHECK);

		switch (questionnaireLandingPage) {
		case DASHBOARD:
			if (!Utility.isElementPresent(PageElements.DASHBOARD_TAB_CHECK)) {
				log.info("Currently at url : {}", Utility.getCurrentUrl());
				throw new IllegalStateException("This is not the Questionnaire > Dashboard page");
			}
			;
			break;
		case QUESTIONNAIRE:
			if (!Utility.isElementPresent(PageElements.QUESTIONNAIRE_LIST_TAB_CHECK)) {
				log.info("Currently at url : {}", Utility.getCurrentUrl());
				throw new IllegalStateException("This is not the Questionnaire > Scans page");
			}
			;
			break;

		case REPORTS:
			if (!Utility.isElementPresent(PageElements.REPORT_TAB_CHECK)) {
				log.info("Currently at url : {}", Utility.getCurrentUrl());
				throw new IllegalStateException("This is not the Questionnaire > Respots page");
			}
			;
			break;

		case LIBRARY:
			if (!Utility.isElementPresent(PageElements.LIBRARY_TAB_CHECK)) {
				log.info("Currently at url : {}", Utility.getCurrentUrl());
				throw new IllegalStateException("This is not the Questionnaire > Assets page");
			}
			break;

		default:
			throw new RuntimeException("No Report Type selected");
		}

		System.out.println("malwarepage check");
		log.info("Currently at url : {}", Utility.getCurrentUrl());
		if (!Utility.getCurrentUrl().contains("module/questionnaire/")) {
			throw new IllegalStateException("\n This is not the Malware page. \n Expected URL contains : module/questionnaire/ but \n actual URL contains:" + Utility.getCurrentUrl());
		}
	}

	// Click on Dashboard
	public DashboardPage goToDashBoard() throws ElementNotFoundException {
		Utility.click(PageElements.DASHBOARD_LABEL);
		return new DashboardPage();
	}

	// click on QUESTIONNAIRE
	public ScansPage goToQuestionnaireList() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.QUESTIONNAIRE_LABEL);
		Utility.click(PageElements.QUESTIONNAIRE_LABEL);
		return new ScansPage();
	}

	// click on REPORTS
	public ReportsPage goToReports() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.REPORTS_LABEL);
		Utility.click(PageElements.REPORTS_LABEL);
		return new ReportsPage();
	}

	// click on LIBRARY
	public SitesTab goToLibrary() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.LIBRARY_LABEL);
		Utility.click(PageElements.LIBRARY_LABEL);
		return new SitesTab();
	}
}
