package com.qualys.selenium.mds.pageobject.dialogs.addsite;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.dashboard.DashboardPage;
import com.qualys.selenium.mds.permissions.PermissionChecks;

@Slf4j
public class SchedulingStep extends AddSiteDialog {
	public String recurranceModeToTrack = "";

	public enum PageElements implements IPageElement {

		STEP_VERIFY_ACTIVE_BODY(".step-scheduling:not(.middle-inactive)"),
		STEP_VERIFY_PASSED_BODY(".step-scheduling:not(.middle-inactive).middle-passed"),

		SCHEDULING_STEP_HEADER_DESCRIPTION_LABEL(".malware-site-object-window .q-step-header .object-panel div"),
		SCHEDULING_STEP_DESCRIPTION(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(4) .section-panel:nth-of-type(2) .notice"),
		REQUIRED_FIELDS_NOTICE_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(4) .notice-required"),

		ENABLE_SCHEDULING_CHECKBOX_LABEL(".malware-site-object-window .enable-scheduling label"),
		RECURRANCE_HEADING_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(4) .section-panel:nth-of-type(3) .section-panel-header-text"),
		RECURRANCE_MODE_LABEL(".malware-site-object-window .q-step-content .object-panel .q-scroller:nth-of-type(4) .section-panel:nth-of-type(3) .section-panel-body .x-form-item-label"),

		// RECURRANCE MODE GENERAL LABELS
		GENERAL_RECURRANCE_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Recurrence']", IdentifiedBy.XPATH),
		GENERAL_ENDS_AFTER_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Ends after']", IdentifiedBy.XPATH),
		GENERAL_OCCURANCES_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='occurrences']", IdentifiedBy.XPATH),

		// Daily
		DAILY_EVERY_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='daily']//label[text()='Every']", IdentifiedBy.XPATH),
		DAILY_DAYS_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='daily']//label[text()='days']", IdentifiedBy.XPATH),

		// WEEKLY LABELS
		WEEKLY_EVERY_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='weekly']//label[text()='Every']", IdentifiedBy.XPATH),

		WEEKLY_WEEKS_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='weeks']", IdentifiedBy.XPATH),
		WEEKLY_ON_DAYS_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='On Days']", IdentifiedBy.XPATH),
		WEEKLY_MONDAY_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Monday']", IdentifiedBy.XPATH),
		WEEKLY_TUESDAY_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Tuesday']", IdentifiedBy.XPATH),
		WEEKLY_WEDNESDAY_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Wednesday']", IdentifiedBy.XPATH),
		WEEKLY_THURSDAY_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Thursday']", IdentifiedBy.XPATH),
		WEEKLY_FRIDAY_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Friday']", IdentifiedBy.XPATH),
		WEEKLY_SATURDAY_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Saturday']", IdentifiedBy.XPATH),
		WEEKLY_SUNDAY_CHECKBOX_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Sunday']", IdentifiedBy.XPATH),

		// TODO
		// MONTHLY LABELS
		MONTHLY_DAY_RADIOBTN_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//label[text()='Day']", IdentifiedBy.XPATH),
		MONTHLY_DAY_OF_EVERY("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//label[text()='of every']", IdentifiedBy.XPATH),
		MONTHLY_DAY_MONTH("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//label[text()='month']", IdentifiedBy.XPATH),
		MONTHLY_THE_RADIOBTN_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//label[text()='The']", IdentifiedBy.XPATH),
		MONTHLY_THE_OF_EVERY("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//div[1][contains(@class,' x-panel')]//label[text()='of every']", IdentifiedBy.XPATH),
		MONTHLY_THE_MONTH("//div[contains(@class,'malware-domain-schedule-panel')]//div[3][contains(@class,'section-panel')]//div[2][contains(@class,' x-panel')]//label[text()='month']", IdentifiedBy.XPATH),

		MONTHLY_NEXT_RUN_DATE_HEADER_DESCRIPTION_LABEL(".q-dialog .q-dialog-body .page-info"),
		MONTHLY_NEXT_RUN_DATE_RADIOBTN_KEEP_CURRENT_SELECTION_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label[text()='Keep my current selection']", IdentifiedBy.XPATH),
		MONTHLY_NEXT_RUN_DATE_RADIOBTN_STARTS_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label//b[contains(text(),'(starts ')]"),

		MONTHLY_NEXT_RUN_DATE_RADIOBTN_CHANGE_START_DATE_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label[contains(text(),'Change my start date')]", IdentifiedBy.XPATH),
		MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE1_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label[contains(text(),'Tuesday 01')]", IdentifiedBy.XPATH),
		MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE2_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label[contains(text(),'Thursday 01')]", IdentifiedBy.XPATH),
		MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE3_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label[contains(text(),'Sunday 01')]", IdentifiedBy.XPATH),
		MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE4_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label[contains(text(),'Tuesday 01 Jul 2014')]", IdentifiedBy.XPATH),
		MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE5_LABEL("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//label[contains(text(),'Friday 01')]", IdentifiedBy.XPATH),

		// help tips labels
		TURN_HELP_TIPS_ON_OFF_LABEL(".malware-site-object-window .q-window-header div.help-on"), // TODO
																									// :
																									// no
																									// such
																									// element
																									// exception
		LAUNCH_HELP_LABEL(".malware-site-object-window .q-window-header div.launch-help"),

		HELP_TIPS_ON(".malware-site-object-window .q-window-header div.help-on .help-toggle-on"),
		HELP_TIPS_OFF(".malware-site-object-window .q-window-header div.help-on .help-toggle-off"),

		MONTHLY_NEXT_RUN_DATE_PREVIOUS_5_DATES("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//button[text()='Previous 5 dates']", IdentifiedBy.XPATH),
		MONTHLY_NEXT_RUN_DATE_NEXT_5_DATES("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-body')]//button[text()='Next 5 dates']", IdentifiedBy.XPATH),
		MONTHLY_AMEND_SCHEDULE_CANCEL_BUTTON("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-bl')]//button[text()='Cancel']", IdentifiedBy.XPATH),
		MONTHLY_AMEND_SCHEDULE_CONTINUE_BUTTON("//div[contains(@class,'q-dialog')]//div[contains(@class,'q-dialog-bl')]//button[text()='Continue']", IdentifiedBy.XPATH),

		LAUNCH_INFORMATION_HEADER_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[4][contains(@class,'section-panel')]//div[contains(@class,'section-panel-header')]//span[text()='Launch Information']", IdentifiedBy.XPATH),
		START_DATE_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[4][contains(@class,'section-panel')]//div[contains(@class,'section-panel-bwrap')]//label[text()='Start Date']", IdentifiedBy.XPATH),
		TIME_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[4][contains(@class,'section-panel')]//div[contains(@class,'section-panel-bwrap')]//label[text()='Time']", IdentifiedBy.XPATH),
		TIME_ZONE_LABEL("//div[contains(@class,'malware-domain-schedule-panel')]//div[4][contains(@class,'section-panel')]//div[contains(@class,'section-panel-bwrap')]//label[text()='Time Zone']", IdentifiedBy.XPATH),

		ENABLE_SCHEDULING_CHECKBOX(".malware-site-object-window  input[name=enable-scheduling]"),
		RECURRANCE_MODE_DOWN_ARROW_TRIGGER("div.malware-domain-schedule-panel div.x-form-label-top div.x-form-field-trigger-wrap>input.x-trigger-noedit+img"),

		RECURRANCE_MODE_CONTAINTER_SINGLE_OCCURANCE("//div[contains(@class,'x-combo-list')]//div[text()='Single occurrence']", IdentifiedBy.XPATH),

		// DAILY
		RECURRANCE_MODE_CONTAINTER_DAILY("//div[contains(@class,'x-combo-list')]//div[text()='Daily']", IdentifiedBy.XPATH),
		DAILY_WAIT("daily", IdentifiedBy.ID),
		DAILY_TOTAL_DAYS(".malware-domain-schedule-panel div.section-panel+div>div+div>div>div+div.x-panel:not(.x-hide-display)"),
		DAILY_EVERY_X_DAYS(".malware-domain-schedule-panel div[id=daily] input[class*=num-field]"),

		// WEEKLY
		RECURRANCE_MODE_CONTAINTER_WEEKLY("//div[contains(@class,'x-combo-list')]//div[text()='Weekly']", IdentifiedBy.XPATH),
		WEEKLY_WAIT("weekly", IdentifiedBy.ID),
		WEEKLY_EVERY_X_WEEKS(".malware-domain-schedule-panel div[id=weekly] input[class*=num-field]"),

		// MONTHLY
		RECURRANCE_MODE_CONTAINTER_MONTHLY("//div[contains(@class,'x-combo-list')]//div[text()='Monthly']", IdentifiedBy.XPATH),
		MONTHLY_DAY_OF_EVERY_MONTH_RADIO_BTN("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//input[@name='occurrenceMonthlyTypeCb']", IdentifiedBy.XPATH),
		MONTHLY_DAY_NUMBER_A("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//div[1][contains(@class,' x-panel')]/div/div//div[contains(@class,'form-field-wrap')]//input", IdentifiedBy.XPATH), // 1,2,
		MONTHLY_INPUT_DAY_OF_EVERY_MONTH(".malware-domain-schedule-panel #monthly input[class*=form-focus]"),
		MONTHLY_MONTH_NUMBER_A("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//div/div/div[1]//div[contains(@class,'box-inner')]/input", IdentifiedBy.XPATH),
		MONTHLY_XTH_MONTH_NUMBER_A(".malware-domain-schedule-panel #monthly input[class*=box-item]"),

		MONTHLY_X_DAY_OF_X_MONTH_RADIO_BTN(".malware-domain-schedule-panel div[id=monthly] input:nth-of-type(1)[name=occurrenceMonthlyTypeCb]"),
		MONTHLY_X_DAY_OF_X_WEEK_X_MONTH_RADIO_BTN(".malware-domain-schedule-panel div[id=monthly] div:nth-of-type(2)[class*=panel] input"),

		MONTHLY_DAY_OF_EVERY_WEEK_RADIO_BTN("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']/div/div/div[2]//input[@name='occurrenceMonthlyTypeCb']", IdentifiedBy.XPATH),

		MONTHLY_DAY_NUMBER_IN_WORDS("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//div/div/div[2]//div[contains(@class,'form-field-wrap')]//input", IdentifiedBy.XPATH), // first,second
		MONTHLY_DAY_NUMBER_IN_WORDS_CONTAINER("//div[contains(@class,'layer')][6]", IdentifiedBy.XPATH),
		MONTHLY_DAY_NUMBER_IN_WORDS_FIRST("//div[contains(@class,'layer')][6]//div[1][contains(@class,'combo-list-item')]", IdentifiedBy.XPATH),
		MONTHLY_DAY_NUMBER_IN_WORDS_SECOND("//div[contains(@class,'layer')][6]//div[2][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NUMBER_IN_WORDS_THIRD("//div[contains(@class,'layer')][6]//div[3][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NUMBER_IN_WORDS_FOURTH("//div[contains(@class,'layer')][6]//div[4][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NUMBER_IN_WORDS_LAST("//div[contains(@class,'layer')][6]//div[5][contains(@class,'combo-list-item')]"),

		MONTHLY_DAY_NAME("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//div[3][contains(@class,'trigger-wrap')]//input", IdentifiedBy.XPATH), // Monday,Tuesday,etc
		MONTHLY_DAY_NAME_CONTAINER("//div[contains(@class,'layer')][4]"),
		MONTHLY_DAY_NAME_MONDAY("//div[contains(@class,'layer')][4]//div[1][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NAME_TUESDAY("//div[contains(@class,'layer')][4]//div[2][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NAME_WEDNESDAY("//div[contains(@class,'layer')][4]//div[3][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NAME_THURSDAY("//div[contains(@class,'layer')][4]//div[4][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NAME_FRIDAY("//div[contains(@class,'layer')][4]//div[5][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NAME_SATURDAY("//div[contains(@class,'layer')][4]//div[6][contains(@class,'combo-list-item')]"),
		MONTHLY_DAY_NAME_SUNDAY("//div[contains(@class,'layer')][4]//div[7][contains(@class,'combo-list-item')]"),

		MONTHLY_XTH_MONTH_B("//div[contains(@class,'malware-domain-schedule-panel')]//div[@id='monthly']//div/div/div[2]//div[contains(@class,'box-inner')]/input", IdentifiedBy.XPATH), // 1,2,3
		MONTHLY_WAIT("monthly", IdentifiedBy.ID),

		// GENERAL
		ENDS_AFTER_CHECKBOX(".malware-domain-schedule-panel input[name=occurrenceEndCb]"),
		ENDS_AFTER_INVISIBLE_CHECKBOX(".malware-domain-schedule-panel .x-hide-display input[name=occurrenceEndCb]"),
		OCCURENCES_DISABLED(".malware-domain-schedule-panel input[name=occurrenceCnt]:disabled"),
		OCCURENCES_ENABLED(".malware-domain-schedule-panel input[name=occurrenceCnt]:not([disabled])"),

		START_DATE_DOWN_ARROW_TRIGGER(".malware-site-object-window input[name=scan-day]"),
		START_DATE_DOWN_CONTAINER_DATE_PICKER("x-datepicker-cb-menu"),
		DATE_PICKER_TOADAY_DATE(".x-date-menu .x-date-picker table .x-date-bottom button"),

		TIME_DOWN_ARROW_TRIGGER(".malware-site-object-window input[name=start-time]"),
		TIME_DOWN_CONTAINER("div[class=x-combo-list-inner]"),
		TIME_DOWN_CONTAINER_ITEMS("div[class=x-combo-list-inner] .x-combo-list-item"),

		TIME_ZONE_DOWN_ARROW_TRIGGER(".malware-schedule-timezone span img:last-of-type"),
		TIME_ZONE_DOWN_CONTAINER(".results-hint"),
		TIME_ZONE_DOWN_CONTAINER_ITEMS(".combobox-item");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public SchedulingStep(AddSiteDialogMode mode) throws SiteCreationMaxedOutException, ElementNotFoundException {
		super(mode);
		
		if (!Utility.isElementPresent(PageElements.STEP_VERIFY_ACTIVE_BODY)) {
				log.info("User " + PermissionChecks.getUserName() + " has scheduling permissions");			
			}
			else
			{
				try
				{
					log.warn("User " + PermissionChecks.getUserName() + " do not have scheduling permissions");
					log.info("Currently at url : {}", Utility.getCurrentUrl());
					throw new IllegalStateException("This is not the AddSite>Scheduling page");
				}catch(Exception e)
				{
					log.warn("Exception at scheduleing step");
				}
			}
		
	}

	

	public SchedulingStep enableSchedulingCheckBox(String doYouEnableSchedule) {
		if (!doYouEnableSchedule.equalsIgnoreCase("none") || !doYouEnableSchedule.equalsIgnoreCase("no")) {
			log.info("Clicking on Enable scheduling checkbox");

			Utility.click(PageElements.ENABLE_SCHEDULING_CHECKBOX);
			return this;
		} else {
			log.trace("doYouEnableSchedule =" + doYouEnableSchedule + " So, not enabling schedule");
			return this;
		}
	}

	public SchedulingStep selectRecurrenceMode(String recurrenceMode) throws ElementNotFoundException {

		if (!recurrenceMode.equalsIgnoreCase("none")) {

			recurranceModeToTrack = recurrenceMode;
			Utility.click(PageElements.RECURRANCE_MODE_DOWN_ARROW_TRIGGER);
			Utility.waitForElementPresent(PageElements.RECURRANCE_MODE_CONTAINTER_SINGLE_OCCURANCE);

			if (recurranceModeToTrack.equalsIgnoreCase("Single occurence")) {
				Utility.click(PageElements.RECURRANCE_MODE_CONTAINTER_SINGLE_OCCURANCE);

			} else if (recurranceModeToTrack.equalsIgnoreCase("Daily")) {

				Utility.click(PageElements.RECURRANCE_MODE_CONTAINTER_DAILY);

				Utility.waitForElementPresent(PageElements.DAILY_WAIT);

			} else if (recurranceModeToTrack.equalsIgnoreCase("weekly")) {

				Utility.click(PageElements.RECURRANCE_MODE_CONTAINTER_WEEKLY);
				Utility.waitForElementPresent(PageElements.WEEKLY_WAIT);

			} else if (recurranceModeToTrack.equalsIgnoreCase("Monthly")) {

				Utility.click(PageElements.RECURRANCE_MODE_CONTAINTER_MONTHLY);

				Utility.waitForElementPresent(PageElements.MONTHLY_WAIT);
			}

			return this;
		} else {
			log.trace("recurrenceMode = " + recurrenceMode + " so not selecting recurrence mode");
			return this;
		}
	}

	public SchedulingStep enableRecurrenceEndsAfter(String doYouEnableRecurrenceEndsAfter) throws ElementNotFoundException {
		if (!doYouEnableRecurrenceEndsAfter.equalsIgnoreCase("none") || !doYouEnableRecurrenceEndsAfter.equalsIgnoreCase("no")) {
			Utility.waitForElementPresent(PageElements.ENDS_AFTER_CHECKBOX);
			Utility.click(PageElements.ENDS_AFTER_CHECKBOX);
			return this;
		} else {
			log.trace("doYouEnableRecurrenceEndsAfter = " + doYouEnableRecurrenceEndsAfter + " so not enabling it");
			return this;
		}
	}

	public SchedulingStep selectDaysCheckBox(String dayName) {
		if (!dayName.equalsIgnoreCase("none")) {
			if (dayName.contains("-")) {
				String[] eachDay = dayName.split("-");
				for (String dayOfWeek : eachDay) {
					try {
						if (dayOfWeek.equalsIgnoreCase("Monday")) {

							Utility.selectCheckBox(PageElements.WEEKLY_MONDAY_CHECKBOX_LABEL);
						} else if (dayOfWeek.equalsIgnoreCase("Tuesday")) {
							Utility.selectCheckBox(PageElements.WEEKLY_TUESDAY_CHECKBOX_LABEL);
						} else if (dayOfWeek.equalsIgnoreCase("Wednesday")) {
							Utility.selectCheckBox(PageElements.WEEKLY_WEDNESDAY_CHECKBOX_LABEL);
						} else if (dayOfWeek.equalsIgnoreCase("Thursday")) {
							Utility.selectCheckBox(PageElements.WEEKLY_THURSDAY_CHECKBOX_LABEL);
						} else if (dayOfWeek.equalsIgnoreCase("Friday")) {
							Utility.selectCheckBox(PageElements.WEEKLY_FRIDAY_CHECKBOX_LABEL);
						} else if (dayOfWeek.equalsIgnoreCase("Saturday")) {
							Utility.selectCheckBox(PageElements.WEEKLY_SATURDAY_CHECKBOX_LABEL);
						} else if (dayOfWeek.equalsIgnoreCase("Sunday")) {
							Utility.selectCheckBox(PageElements.WEEKLY_SUNDAY_CHECKBOX_LABEL);

						}
					} catch (Exception e) {

					}
				}

			}
			return this;
		} else {
			log.trace("dayName = " + dayName + " so not selectDaysCheckBox");
			return this;
		}
	}

	public SchedulingStep typeRecurrenceOccurrences(String numberOfOccurences) {
		if (!numberOfOccurences.equalsIgnoreCase("none")) {

			if (Utility.isElementPresent(PageElements.OCCURENCES_ENABLED) && !numberOfOccurences.equalsIgnoreCase("none")) {
				Utility.typeInEditBox(PageElements.OCCURENCES_ENABLED, numberOfOccurences);
				return this;
			} else if (Utility.isElementPresent(PageElements.OCCURENCES_DISABLED) && !numberOfOccurences.equalsIgnoreCase("none")) {
				log.warn("Recurrence Occurance edit box is disabled.Please enable by checking -Ends after- check box");
				return this;
			} else {
				log.error("Could not type in Recurrence Occurence coz input value is invalid = " + numberOfOccurences);
				return this;
			}
		} else {
			log.trace("numberOfOccurences = " + numberOfOccurences + "So not typing in RecurrenceOccurrences ");
			return this;
		}
	}

	public SchedulingStep enableDayOfMonth(String doYouEnableDayOfMonth) {
		if (!doYouEnableDayOfMonth.equalsIgnoreCase("none")) {

			Utility.selectRadioButton(PageElements.MONTHLY_DAY_OF_EVERY_MONTH_RADIO_BTN);
			return this;
		} else {
			log.trace("doYouEnableDayOfMonth = " + doYouEnableDayOfMonth + "So enabling day of month");
			return this;
		}
	}

	public String getDayOnPage() {

		return Utility.getTextOfPageObject(PageElements.MONTHLY_INPUT_DAY_OF_EVERY_MONTH);

	}

	public SchedulingStep typeDayNumberA(String daysInNumberA) {
		Utility.typeInEditBox(PageElements.MONTHLY_DAY_NUMBER_A, daysInNumberA);
		return this;
	}

	public SchedulingStep typeMonthNumberA(String ofEveryXmonth) {
		Utility.typeInEditBox(PageElements.MONTHLY_MONTH_NUMBER_A, ofEveryXmonth);
		return this;
	}

	public SchedulingStep enableDayOfWeek() {
		Utility.selectRadioButton(PageElements.MONTHLY_DAY_OF_EVERY_WEEK_RADIO_BTN);
		return this;
	}

	public SchedulingStep clickDropDownDayNumberInWords() {
		Utility.click(PageElements.MONTHLY_DAY_NAME);
		return this;
	}

	public SchedulingStep selectDayNumberInWords(String dayNumberInWords) throws ElementNotFoundException {
		clickDropDownDayNumberInWords();
		Utility.waitForElementPresent(PageElements.MONTHLY_DAY_NUMBER_IN_WORDS);
		//String dayNumber = dayNumberInWords;

		/*
		 * switch (dayNumber.toLowerCase()) { case "first":
		 * Utility.click(PageElements.MONTHLY_DAY_NUMBER_IN_WORDS_FIRST); break;
		 * case "second":
		 * Utility.click(PageElements.MONTHLY_DAY_NUMBER_IN_WORDS_SECOND);
		 * break; case "third":
		 * Utility.click(PageElements.MONTHLY_DAY_NUMBER_IN_WORDS_THIRD); break;
		 * case "fourth":
		 * Utility.click(PageElements.MONTHLY_DAY_NUMBER_IN_WORDS_FOURTH);
		 * break; case "last":
		 * Utility.click(PageElements.MONTHLY_DAY_NUMBER_IN_WORDS_LAST); break;
		 * default: break; }
		 */
		return this;
	}

	public SchedulingStep clickDropDownDayName() {
		Utility.click(PageElements.MONTHLY_DAY_NAME);
		return this;
	}

	public SchedulingStep selectDayName(String dayName) {
		clickDropDownDayName();
		String dayNameSelect = dayName;

		if (dayNameSelect.equalsIgnoreCase("monday")) {
			Utility.click(PageElements.MONTHLY_DAY_NAME_MONDAY);
		} else if (dayNameSelect.equalsIgnoreCase("tuesday")) {
			Utility.click(PageElements.MONTHLY_DAY_NAME_TUESDAY);
		} else if (dayNameSelect.equalsIgnoreCase("wednesday")) {
			Utility.click(PageElements.MONTHLY_DAY_NAME_WEDNESDAY);
		} else if (dayNameSelect.equalsIgnoreCase("thursday")) {
			Utility.click(PageElements.MONTHLY_DAY_NAME_THURSDAY);
		} else if (dayNameSelect.equalsIgnoreCase("friday")) {
			Utility.click(PageElements.MONTHLY_DAY_NAME_FRIDAY);
		} else if (dayNameSelect.equalsIgnoreCase("saturday")) {
			Utility.click(PageElements.MONTHLY_DAY_NAME_SATURDAY);
		} else if (dayNameSelect.equalsIgnoreCase("sunday")) {
			Utility.click(PageElements.MONTHLY_DAY_NAME_SUNDAY);
		}

		return this;

	}

	// Applicable for Daily schedule option
	public SchedulingStep typeEveryXDays(String every_X_Days) {
		if (!every_X_Days.equalsIgnoreCase("none")) {
			Utility.typeInEditBox(PageElements.DAILY_EVERY_X_DAYS, every_X_Days);
			log.info("Typing in Every x days text field (Daily schedule option)");
			return this;
		} else {
			log.info("Daily schedule every x days = \" " + every_X_Days + "\" so, not typing in");
			return this;
		}

	}

	// Applicable for weekly schedule
	public SchedulingStep typeEndsAfterXWeeks(String every_X_Weeks) {
		if (!every_X_Weeks.equalsIgnoreCase("none")) {
			Utility.typeInEditBox(PageElements.WEEKLY_EVERY_X_WEEKS, every_X_Weeks);
			log.info("Typing in Every x days text field (Daily schedule option)");
			return this;
		} else {
			log.info("Daily schedule every x days = \" " + every_X_Weeks + "\" so, not typing in");
			return this;
		}
	}

	// Applicable for monthly schedule
	public SchedulingStep enableXthDayOfXthMonth(String enableXDayXOfEveryMonth) {
		if (!enableXDayXOfEveryMonth.equalsIgnoreCase("none")) {
			Utility.typeInEditBox(PageElements.MONTHLY_X_DAY_OF_X_MONTH_RADIO_BTN, enableXDayXOfEveryMonth);
			log.info("Enabling first radio button (Monthly schedule option)");
			return this;
		} else {
			log.info("Monthly schedule, Enable first radio button \"enableXDayXOfEveryMonth\" = \" " + enableXDayXOfEveryMonth.toUpperCase() + "\" so, not enabling it");
			return this;
		}
	}

	// Applicable for monthly schedule
	public SchedulingStep enableXDayofXWeekXthMonth(String enableXDayofXWeekXthMonth) {
		if (!enableXDayofXWeekXthMonth.equalsIgnoreCase("none")) {
			Utility.typeInEditBox(PageElements.MONTHLY_X_DAY_OF_X_WEEK_X_MONTH_RADIO_BTN, enableXDayofXWeekXthMonth);
			log.info("Enabling second radio button (Monthly schedule option)");
			return this;
		} else {
			log.info("Monthly schedule, Enable second radio button \"enableXDayofXWeekXthMonth\" = \" " + enableXDayofXWeekXthMonth.toUpperCase() + "\" so, not enabling it");
			return this;
		}
	}

	// Applicable for monthly schedule
	public SchedulingStep typeEveryXNoOfMonths(String monthNumberB) {
		if (!monthNumberB.equalsIgnoreCase("none")) {
			Utility.typeInEditBox(PageElements.MONTHLY_XTH_MONTH_B, monthNumberB);
			log.info("Enabling second radio button (Monthly schedule option)");
			return this;
		} else {
			log.info("Monthly schedule, monthNumberB  = \" " + monthNumberB.toUpperCase() + "\" so, not typing in");
			return this;
		}

	}

	public SchedulingStep selectLaunchInfoStartDate() {

		Utility.moveToElementAndClick(PageElements.START_DATE_DOWN_ARROW_TRIGGER);
		return this;
	}

	public SchedulingStep selectLaunchInfoTime() {
		return this;
	}

	public SchedulingStep selectLaunchInfoTimeZone() {
		return this;
	}

	public SchedulingStep oNHelpTips() {
		Utility.click(PageElements.HELP_TIPS_ON);
		return this;
	}

	public SchedulingStep oFFHelpTips() {
		Utility.click(PageElements.HELP_TIPS_OFF);
		return this;
	}

	public SchedulingStep launchHelp() {
		Utility.click(PageElements.LAUNCH_HELP_LABEL);
		return this;
	}

	public ReviewAndConfimStepAddSite clickContinue() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(DialogCommonElements.CONTINUE_BTN);
		return new ReviewAndConfimStepAddSite(siteDialogueMode);

	}

	public AmendNextDateDialog clickContinueReviewandConfirmToAmendNextDate() throws SiteCreationMaxedOutException, ElementNotFoundException {

		Utility.click(DialogCommonElements.CONTINUE_BTN);
		return new AmendNextDateDialog(siteDialogueMode);
	}

	public SchedulingStep clickContinueWhenIntensityIsMonthly() {

		Utility.click(DialogCommonElements.CONTINUE_BTN);

		return this;
	}

	public DashboardPage clickCancel() throws ElementNotFoundException {
		Utility.click(DialogCommonElements.CANCEL_BTN);
		return new DashboardPage();
	}

	public CrawlExclusionListsStep clickPrevious() throws SiteCreationMaxedOutException, ElementNotFoundException {
		Utility.click(DialogCommonElements.PREVIOUS_BTN);
		return new CrawlExclusionListsStep(AddSiteDialogMode.CREATE);
	}

	public SchedulingStep verifySchedulingStepStaticText() throws ElementNotFoundException {
		CustomVerification customVerification = new CustomVerification();

		// customVerification.verifyEquals("Site Details step TURN_HELP_TIPS_ON_OFF_LABEL ",Utility.getTextOfPageObject(PageElements.TURN_HELP_TIPS_ON_OFF_LABEL),"Turn help tips: On | Off Launch help ");
		// //TODO : no such element exception
		customVerification.verifyEquals("Site Details step LAUNCH_HELP_", Utility.getTextOfPageObject(PageElements.LAUNCH_HELP_LABEL), "Launch help");
		customVerification.verifyEquals("Scheduling Step header description ", Utility.getTextOfPageObject(PageElements.SCHEDULING_STEP_HEADER_DESCRIPTION_LABEL), "Define how often you want to scan this site for malware");
		customVerification.verifyEquals("Scheduling Step SCHEDULING_STEP_DESCRIPTION  ", Utility.getTextOfPageObject(PageElements.SCHEDULING_STEP_DESCRIPTION), "Enable scheduling to define a scan schedule for your site.");
		customVerification.verifyEquals("Scheduling Step REQUIRED_FIELDS_NOTICE_LABEL  ", Utility.getTextOfPageObject(PageElements.REQUIRED_FIELDS_NOTICE_LABEL), "(*) REQUIRED FIELDS");
		customVerification.verifyEquals("Scheduling Step ENABLE_SCHEDULING_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.ENABLE_SCHEDULING_CHECKBOX_LABEL), "Enable Scheduling");

		// Enable scheduling check box
		enableSchedulingCheckBox("yes");

		// Single occurrence static text
		customVerification.verifyEquals("Scheduling Step RECURRANCE_HEADING_LABEL  ", Utility.getTextOfPageObject(PageElements.RECURRANCE_HEADING_LABEL), "Recurrence");
		customVerification.verifyEquals("Scheduling Step RECURRANCE_MODE_LABEL  ", Utility.getTextOfPageObject(PageElements.RECURRANCE_MODE_LABEL), "Mode*");

		// Daily occurrence static text
		selectRecurrenceMode("daily");
		customVerification.verifyEquals("Scheduling Step GENERAL_ENDS_AFTER_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.GENERAL_ENDS_AFTER_CHECKBOX_LABEL), "Ends after");

		customVerification.verifyEquals("Scheduling Step GENERAL_OCCURANCES_LABEL  ", Utility.getTextOfPageObject(PageElements.GENERAL_OCCURANCES_LABEL), "occurrences");
		Utility.getElement(PageElements.OCCURENCES_DISABLED).isDisplayed();
		customVerification.verifyEquals("Scheduling Step DAILY_EVERY_LABEL  ", Utility.getTextOfPageObject(PageElements.DAILY_EVERY_LABEL), "Every");
		customVerification.verifyEquals("Scheduling Step DAILY_DAYS_LABEL  ", Utility.getTextOfPageObject(PageElements.DAILY_DAYS_LABEL), "days");

		// Weekly occurrence static text
		selectRecurrenceMode("weekly");
		customVerification.verifyEquals("Scheduling Step GENERAL_ENDS_AFTER_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.GENERAL_ENDS_AFTER_CHECKBOX_LABEL), "Ends after");

		customVerification.verifyEquals("Scheduling Step GENERAL_OCCURANCES_LABEL  ", Utility.getTextOfPageObject(PageElements.GENERAL_OCCURANCES_LABEL), "occurrences");
		customVerification.verifyEquals("Scheduling Step WEEKLY_EVERY_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_EVERY_LABEL), "Every");
		customVerification.verifyEquals("Scheduling Step WEEKLY_WEEKS_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_WEEKS_LABEL), "weeks");
		customVerification.verifyEquals("Scheduling Step WEEKLY_ON_DAYS_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_ON_DAYS_LABEL), "On Days");
		customVerification.verifyEquals("Scheduling Step WEEKLY_MONDAY_CHECKBOX_LABEL ", Utility.getTextOfPageObject(PageElements.WEEKLY_MONDAY_CHECKBOX_LABEL), "Monday");
		customVerification.verifyEquals("Scheduling Step WEEKLY_TUESDAY_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_TUESDAY_CHECKBOX_LABEL), "Tuesday");
		customVerification.verifyEquals("Scheduling Step WEEKLY_WEDNESDAY_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_WEDNESDAY_CHECKBOX_LABEL), "Wednesday");
		customVerification.verifyEquals("Scheduling Step WEEKLY_THURSDAY_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_THURSDAY_CHECKBOX_LABEL), "Thursday");
		customVerification.verifyEquals("Scheduling Step WEEKLY_FRIDAY_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_FRIDAY_CHECKBOX_LABEL), "Friday");
		customVerification.verifyEquals("Scheduling Step WEEKLY_SATURDAY_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_SATURDAY_CHECKBOX_LABEL), "Saturday");
		customVerification.verifyEquals("Scheduling Step WEEKLY_SUNDAY_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.WEEKLY_SUNDAY_CHECKBOX_LABEL), "Sunday");

		// monthly occurrence static text
		selectRecurrenceMode("monthly");
		customVerification.verifyEquals("Scheduling Step GENERAL_ENDS_AFTER_CHECKBOX_LABEL  ", Utility.getTextOfPageObject(PageElements.GENERAL_ENDS_AFTER_CHECKBOX_LABEL), "Ends after");

		customVerification.verifyEquals("Scheduling Step GENERAL_OCCURANCES_LABEL  ", Utility.getTextOfPageObject(PageElements.GENERAL_OCCURANCES_LABEL), "occurrences");
		customVerification.verifyEquals("Scheduling Step MONTHLY_DAY_RADIOBTN_LABEL  ", Utility.getTextOfPageObject(PageElements.MONTHLY_DAY_RADIOBTN_LABEL), "Day");
		customVerification.verifyEquals("Scheduling Step MONTHLY_DAY_OF_EVERY  ", Utility.getTextOfPageObject(PageElements.MONTHLY_DAY_OF_EVERY), "of every");
		customVerification.verifyEquals("Scheduling Step MONTHLY_DAY_MONTH  ", Utility.getTextOfPageObject(PageElements.MONTHLY_DAY_MONTH), "month");
		customVerification.verifyEquals("Scheduling Step MONTHLY_THE_RADIOBTN_LABEL  ", Utility.getTextOfPageObject(PageElements.MONTHLY_THE_RADIOBTN_LABEL), "The");
		customVerification.verifyEquals("Scheduling Step MONTHLY_THE_OF_EVERY  ", Utility.getTextOfPageObject(PageElements.MONTHLY_THE_OF_EVERY), "of every");
		customVerification.verifyEquals("Scheduling Step MONTHLY_THE_MONTH  ", Utility.getTextOfPageObject(PageElements.MONTHLY_THE_MONTH), "month");

		customVerification.verifyEquals("Scheduling Step LAUNCH_INFORMATION_HEADER_LABEL  ", Utility.getTextOfPageObject(PageElements.LAUNCH_INFORMATION_HEADER_LABEL), "Launch Information");
		customVerification.verifyEquals("Scheduling Step START_DATE_LABEL  ", Utility.getTextOfPageObject(PageElements.START_DATE_LABEL), "Start Date");
		customVerification.verifyEquals("Scheduling Step TIME_LABEL  ", Utility.getTextOfPageObject(PageElements.TIME_LABEL), "Time*");
		customVerification.verifyEquals("Scheduling Step TIME_ZONE_LABEL  ", Utility.getTextOfPageObject(PageElements.TIME_ZONE_LABEL), "Time Zone*");

		clickContinueWhenIntensityIsMonthly();

		// Amend Schedule Dialog appears
		customVerification.verifyEquals("Scheduling Step MONTHLY_NEXT_RUN_DATE_HEADER_DESCRIPTION_LABEL  ", Utility.getTextOfPageObject(PageElements.MONTHLY_NEXT_RUN_DATE_HEADER_DESCRIPTION_LABEL),
				"Your start date has been set to a different day than your specified event day.");
		customVerification.verifyEquals("Scheduling Step MONTHLY_NEXT_RUN_DATE_RADIOBTN_KEEP_CURRENT_SELECTION_LABEL  ", Utility.getTextOfPageObject(PageElements.MONTHLY_NEXT_RUN_DATE_RADIOBTN_KEEP_CURRENT_SELECTION_LABEL),
				"Keep my current selection(starts Tuesday 04 Mar 2014");
		customVerification.verifyEquals("Scheduling Step MONTHLY_NEXT_RUN_DATE_RADIOBTN_CHANGE_START_DATE_LABEL  ", Utility.getTextOfPageObject(PageElements.MONTHLY_NEXT_RUN_DATE_RADIOBTN_CHANGE_START_DATE_LABEL),
				"Change my start date to date below to match your recurrence definition");

		// TODO : Need to work on dates
		/*
		 * customVerification.verifyEquals(
		 * "Scheduling Step MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE1_LABEL  "
		 * ,Utility.getTextOfPageObject(PageElements.
		 * MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE1_LABEL), "Tuesday 01 Apr 2014");
		 * customVerification.verifyEquals(
		 * "Scheduling Step MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE2_LABEL  "
		 * ,Utility.getTextOfPageObject(PageElements.
		 * MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE2_LABEL), "Thursday 01 May 2014");
		 * customVerification.verifyEquals(
		 * "Scheduling Step MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE3_LABEL  "
		 * ,Utility.getTextOfPageObject(PageElements.
		 * MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE3_LABEL), "Sunday 01 Jun 2014");
		 * customVerification.verifyEquals(
		 * "Scheduling Step MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE4_LABEL  "
		 * ,Utility.getTextOfPageObject(PageElements.
		 * MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE4_LABEL), "Tuesday 01 Jul 2014");
		 * customVerification.verifyEquals(
		 * "Scheduling Step MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE5_LABEL  "
		 * ,Utility.getTextOfPageObject(PageElements.
		 * MONTHLY_NEXT_RUN_DATE_RADIOBTN_DATE5_LABEL), "Friday 01 Aug 2014");
		 */

		customVerification.verifyEquals("Scheduling Step MONTHLY_NEXT_RUN_DATE_PREVIOUS_5_DATES  ", Utility.getTextOfPageObject(PageElements.MONTHLY_NEXT_RUN_DATE_PREVIOUS_5_DATES), "Previous 5 dates");
		customVerification.verifyEquals("Scheduling Step MONTHLY_NEXT_RUN_DATE_NEXT_5_DATES  ", Utility.getTextOfPageObject(PageElements.MONTHLY_NEXT_RUN_DATE_NEXT_5_DATES), "Next 5 dates");
		customVerification.verifyEquals("Scheduling Step MONTHLY_NEXT_RUN_DATE_NEXT_5_DATES  ", Utility.getTextOfPageObject(PageElements.MONTHLY_NEXT_RUN_DATE_NEXT_5_DATES), "Next 5 dates");

		customVerification.verifyEquals("Scheduling Step MONTHLY_AMEND_SCHEDULE_CANCEL_BUTTON  ", Utility.getTextOfPageObject(PageElements.MONTHLY_AMEND_SCHEDULE_CANCEL_BUTTON), "Cancel");
		customVerification.verifyEquals("Scheduling Step MONTHLY_AMEND_SCHEDULE_CONTINUE_BUTTON  ", Utility.getTextOfPageObject(PageElements.MONTHLY_AMEND_SCHEDULE_CONTINUE_BUTTON), "Continue");

		// clickCancelOnAmendScheduleDialog();

		customVerification.verifyEquals("Scheduling Step CONTINUE_BTN  ", Utility.getTextOfPageObject(DialogCommonElements.CONTINUE_BTN), "Continue");
		customVerification.verifyEquals("Scheduling Step CANCEL_BTN  ", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN), "Cancel");

		return this;

	}

}
