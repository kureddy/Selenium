package com.qualys.selenium.mds.pageobject.dashboard;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.customexceptions.SiteCreationMaxedOutException;
import com.qualys.selenium.mds.pageobject.MalwarePage;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog;
import com.qualys.selenium.mds.pageobject.dialogs.addsite.AddSiteDialog.AddSiteDialogMode;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.entiresite.NewScanEntireSiteDialog;
import com.qualys.selenium.mds.pageobject.dialogs.newscan.singlepage.NewScanSinglePage;

@Slf4j
public class DashboardPage extends MalwarePage {

	public enum PageElements implements IPageElement {
		PAGE_LOADING_CHECK("#dashboard:not(.x-hide-display)"),
		NEW_SCAN_BTN(".add-scan-btn button"),
		NEW_SCAN_ENTIRE_SITE_BTN(".q-quick-menu li:first-of-type"),
		NEW_SCAN_SINGLE_PAGE_BTN(".q-quick-menu li:last-of-type"),
		ADD_SITE_LINK(".add-malware-btn"),
		ADD_SITE_BUTTON(".add-scan button"),

		// LABELS

		DASHBOARD_PAGE_TITLE_LABEL("#dashboard .title"),
		LAST_LOG_IN("#dashboard .date-range"),
		SCANS_SINCE_LAST_LOG_IN("#dashboard .subtitle"),

		TOTAL_SITES_BOX_LABEL("#dashboard .item-selected .title"),
		TOTAL_SITES_BOX_NUMBER_LABEL("#dashboard .item-selected .nb"),
		SITES_WITH_DETECTIONS_BOX_LABEL("#dashboard .item:nth-of-type(2) .title"),
		SITES_WITH_DETECTIONS_BOX_NUMBER_LABEL("#dashboard .item:nth-of-type(2) .nb"),
		TOTAL_DETECTIONS_LABEL("#dashboard .item:nth-of-type(3) .title"),
		TOTAL_DETECTIONS_BOX_NUMBER_LABEL("#dashboard .item:nth-of-type(3) .nb"),

		NEW_SCAN_DRIOPDOWN_LABEL(".add-scan-btn button"),
		ADD_SITE_LINK_LABEL(".add-malware-btn"),

		DETECTIONS_TREND_LABEL("#dashboard .base-panel-gray:nth-of-type(1) .title"),
		DETECTIONS_TREND_DATE_RANGE_LABEL("#dashboard .base-panel-gray:nth-of-type(1) .base-panel-gray-bwrap #date-range-text"),
		DETECTIONS_TREND_DATE_RANGE_7_DAYS_LABEL("#dashboard .base-panel-gray:nth-of-type(1) .base-panel-gray-bwrap #date-range-bar .x-toolbar-cell:nth-of-type(2) .link"),
		// TODO
		DETECTIONS_TREND_FRI_LABEL(""),
		DETECTIONS_TREND_SAT_LABEL(""),
		DETECTIONS_TREND_SUN_LABEL(""),
		DETECTIONS_TREND_MON_LABEL(""),
		DETECTIONS_TREND_TUE_LABEL(""),
		DETECTIONS_TREND_WED_LABEL(""),
		DETECTIONS_TREND_THU_LABEL(""),
		DETECTIONS_TREND_DATE_RANGE_14_DAYS_LABEL("#dashboard .base-panel-gray:nth-of-type(1) .base-panel-gray-bwrap #date-range-bar .x-toolbar-cell:nth-of-type(3) .link"),
		// TODO
		DETECTIONS_TREND_VERTICAL_LABEL(
				"//div[@id='dashboard']//div[1]//div[contains(@class,'base-panel-gray')]//div[contains(@class,'base-panel-gray-bwrap')]//div[contains(@id,'malware-threats-chart')]//div[@class='highcharts-container']"),
		// TODO
		DETECTIONS_TREND_HORIZONTAL_LABEL(""),

		SITES_WITH_DETECTIONS_LABEL("#dashboard .base-panel-gray:nth-of-type(2) .title"),
		SITES_WITH_DETECTIONS_VIEW_ALL_LABEL("#dashboard .base-panel-gray:nth-of-type(2) .clickable"),

		YOUR_LAST_SCANS_LABEL("#dashboard .base-panel-blue:nth-of-type(1) .title"),
		YOUR_LAST_SCANS_VIEW_ALL_LABEL("#dashboard .base-panel-blue:nth-of-type(1) .clickable"),
		YOUR_LAST_SCANS_SCAN_COLUMN_LABEL("#dashboard .base-panel-blue:nth-of-type(1) .scan-activity-portlet .x-grid3-td-title"),
		YOUR_LAST_SCANS_SCAN_DATE_COLUMN_LABEL("#dashboard .base-panel-blue:nth-of-type(1) .scan-activity-portlet .sort-desc"),
		YOUR_LAST_SCANS_STATUS_COLUMN_LABEL("#dashboard .base-panel-blue:nth-of-type(1) .scan-activity-portlet .x-grid3-td-3"),
		YOUR_LAST_SCANS_SEVERITY_COLUMN_LABEL("#dashboard .base-panel-blue:nth-of-type(1) .scan-activity-portlet .x-grid3-cell-last"),

		YOUR_UPCOMING_SCANS_LABEL("#dashboard .base-panel-blue:nth-of-type(2) .title"),
		YOUR_UPCOMING_SCANS_VIEW_ALL_LABEL("#dashboard .base-panel-blue:nth-of-type(2) .clickable"),
		YOUR_UPCOMING_SCANS_SCAN_NAME_COLUMN_LABEL("#dashboard .base-panel-blue:nth-of-type(2) .scan-activity-portlet .x-grid3-td-name"),
		YOUR_UPCOMING_SCANS_STARTS_COLUMN_LABEL("#dashboard .base-panel-blue:nth-of-type(2) .scan-activity-portlet .x-grid3-td-2"),
		YOUR_UPCOMING_SCANS_OCCURS_COLUMN_LABEL("#dashboard .base-panel-blue:nth-of-type(2) .scan-activity-portlet .x-grid3-cell-last");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}
	}

	
	public DashboardPage() throws ElementNotFoundException {
		super(MalwareLandingPage.DASHBOARD);
		
		
	}
	
	public DashboardPage clickNewScanButton() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.NEW_SCAN_BTN);
		Utility.click(PageElements.NEW_SCAN_BTN);
		return this;
	}

	public NewScanEntireSiteDialog clickNewScanEntireSite() throws ElementNotFoundException {
		clickNewScanButton();

		Utility.waitForElementPresent(PageElements.NEW_SCAN_ENTIRE_SITE_BTN);
		Utility.moveToElementAndClick(PageElements.NEW_SCAN_ENTIRE_SITE_BTN);

		return new NewScanEntireSiteDialog();
	}

	public NewScanSinglePage clickNewScanSinglePage() throws ElementNotFoundException {

		clickNewScanButton();
		Utility.waitForElementPresent(PageElements.NEW_SCAN_SINGLE_PAGE_BTN);
		Utility.moveToElementAndClick(PageElements.NEW_SCAN_SINGLE_PAGE_BTN);
		return new NewScanSinglePage();
	}

	public AddSiteDialog clickOnAddSiteLink() throws ElementNotFoundException  {
		try {

			Utility.waitForElementPresent(PageElements.ADD_SITE_LINK);
			Utility.click(PageElements.ADD_SITE_LINK);
			return new AddSiteDialog(AddSiteDialogMode.CREATE);

		} catch (SiteCreationMaxedOutException e) {
				e.logException();
			if (verifySiteCreationError()) {
				e.logException();
				return null;
			}else
			{
				log.error("");
				return null;
			}
		}
	}

	public AddSiteDialog goToAddSiteButton() throws SiteCreationMaxedOutException, ElementNotFoundException {
		Utility.click(PageElements.ADD_SITE_BUTTON);
		return new AddSiteDialog(AddSiteDialogMode.CREATE);
	}

	public DashboardPage verifyDashboardPageStaticText() {

		CustomVerification customVerification = new CustomVerification();

		customVerification.verifyEquals("Dashboard Page DASHBOARD_PAGE_TITLE_LABEL  ", Utility.getTextOfPageObject(PageElements.DASHBOARD_PAGE_TITLE_LABEL), "Dashboard");
		customVerification.verifyEquals("Dashboard Page LAST_LOG_IN  ", Utility.getTextOfPageObject(PageElements.LAST_LOG_IN), "Last login: 06 Mar 2014");
		customVerification.verifyEquals("Dashboard Page SCANS_SINCE_LAST_LOG_IN ", Utility.getTextOfPageObject(PageElements.SCANS_SINCE_LAST_LOG_IN), "0 scans since last login");
		customVerification.verifyEquals("Dashboard Page TOTAL_SITES_BOX_LABEL  ", Utility.getTextOfPageObject(PageElements.TOTAL_SITES_BOX_LABEL), "Total Sites");
		customVerification.verifyEquals("Dashboard Page TOTAL_SITES_BOX_NUMBER_LABEL  ", Utility.getTextOfPageObject(PageElements.TOTAL_SITES_BOX_NUMBER_LABEL), "72");
		customVerification.verifyEquals("Dashboard Page SITES_WITH_DETECTIONS_BOX_LABEL  ", Utility.getTextOfPageObject(PageElements.SITES_WITH_DETECTIONS_BOX_LABEL), "Sites with Detections");
		customVerification.verifyEquals("Dashboard Page SITES_WITH_DETECTIONS_BOX_NUMBER_LABEL  ", Utility.getTextOfPageObject(PageElements.SITES_WITH_DETECTIONS_BOX_NUMBER_LABEL), "2");
		customVerification.verifyEquals("Dashboard Page TOTAL_DETECTIONS_LABEL  ", Utility.getTextOfPageObject(PageElements.TOTAL_DETECTIONS_LABEL), "Total Detections");
		customVerification.verifyEquals("Dashboard Page TOTAL_DETECTIONS_BOX_NUMBER_LABEL  ", Utility.getTextOfPageObject(PageElements.TOTAL_DETECTIONS_BOX_NUMBER_LABEL), "34");

		customVerification.verifyEquals("Dashboard Page NEW_SCAN_DRIOPDOWN_", Utility.getTextOfPageObject(PageElements.NEW_SCAN_DRIOPDOWN_LABEL), "New Scan");
		customVerification.verifyEquals("Dashboard Page ADD_SITE_LINK_", Utility.getTextOfPageObject(PageElements.ADD_SITE_LINK_LABEL), "  Add Site\n ");

		customVerification.verifyEquals("Dashboard Page DETECTIONS_TREND_", Utility.getTextOfPageObject(PageElements.DETECTIONS_TREND_LABEL), "Detection Trend");
		customVerification.verifyEquals("Dashboard Page DETECTIONS_TREND_DATE_RANGE_LABEL  ", Utility.getTextOfPageObject(PageElements.DETECTIONS_TREND_DATE_RANGE_LABEL), "Date range");
		customVerification.verifyEquals("Dashboard Page DETECTIONS_TREND_DATE_RANGE_7_DAYS_LABEL  ", Utility.getTextOfPageObject(PageElements.DETECTIONS_TREND_DATE_RANGE_7_DAYS_LABEL),
				"      7 days\n ");
		customVerification.verifyEquals("Dashboard Page DETECTIONS_TREND_DATE_RANGE_14_DAYS_LABEL  ", Utility.getTextOfPageObject(PageElements.DETECTIONS_TREND_DATE_RANGE_14_DAYS_LABEL),
				"      14 days\n ");
		// TODO
		/*
		 * customVerification.verifyEquals(
		 * "Dashboard Page DETECTIONS_TREND_VERTICAL_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_VERTICAL_LABEL), "Reports");
		 * customVerification
		 * .verifyEquals("Dashboard Page DETECTIONS_TREND_HORIZONTAL_LABEL  "
		 * ,Utility
		 * .getTextOfPageObject(PageElements.DETECTIONS_TREND_HORIZONTAL_LABEL),
		 * "Assets");
		 */

		// TODO
		/*
		 * customVerification.verifyEquals(
		 * "Dashboard Page DETECTIONS_TREND_MON_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_MON_LABEL), "Reports");
		 * customVerification
		 * .verifyEquals("Dashboard Page DETECTIONS_TREND_TUE_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_TUE_LABEL), "Reports");
		 * customVerification
		 * .verifyEquals("Dashboard Page DETECTIONS_TREND_WED_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_WED_LABEL), "Reports");
		 * customVerification
		 * .verifyEquals("Dashboard Page DETECTIONS_TREND_THU_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_THU_LABEL), "Reports");
		 * customVerification
		 * .verifyEquals("Dashboard Page DETECTIONS_TREND_FRI_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_FRI_LABEL), "Reports");
		 * customVerification
		 * .verifyEquals("Dashboard Page DETECTIONS_TREND_SAT_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_SAT_LABEL), "Reports");
		 * customVerification
		 * .verifyEquals("Dashboard Page DETECTIONS_TREND_SUN_LABEL  "
		 * ,Utility.getTextOfPageObject
		 * (PageElements.DETECTIONS_TREND_SUN_LABEL), "Reports");
		 */

		customVerification.verifyEquals("Dashboard Page SITES_WITH_DETECTIONS_BOX_LABEL  ", Utility.getTextOfPageObject(PageElements.SITES_WITH_DETECTIONS_BOX_LABEL), "Sites with Detections");
		customVerification.verifyEquals("Dashboard Page SITES_WITH_DETECTIONS_VIEW_ALL_LABEL  ", Utility.getTextOfPageObject(PageElements.SITES_WITH_DETECTIONS_VIEW_ALL_LABEL), "View all");

		customVerification.verifyEquals("Dashboard Page YOUR_LAST_SCANS_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_LAST_SCANS_LABEL), "Your Last Scans");
		customVerification.verifyEquals("Dashboard Page YOUR_LAST_SCANS_VIEW_ALL_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_LAST_SCANS_VIEW_ALL_LABEL), "View all");
		customVerification.verifyEquals("Dashboard Page YOUR_LAST_SCANS_SCAN_COLUMN_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_LAST_SCANS_SCAN_COLUMN_LABEL), "Scan");
		customVerification.verifyEquals("Dashboard Page YOUR_LAST_SCANS_SCAN_DATE_COLUMN_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_LAST_SCANS_SCAN_DATE_COLUMN_LABEL), "Scan Date");
		customVerification.verifyEquals("Dashboard Page YOUR_LAST_SCANS_STATUS_COLUMN_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_LAST_SCANS_STATUS_COLUMN_LABEL), "Status");
		customVerification.verifyEquals("Dashboard Page YOUR_LAST_SCANS_SEVERITY_COLUMN_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_LAST_SCANS_SEVERITY_COLUMN_LABEL), "Severity");

		customVerification.verifyEquals("Dashboard Page YOUR_UPCOMING_SCANS_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_UPCOMING_SCANS_LABEL), "Your Upcoming Scans");
		customVerification.verifyEquals("Dashboard Page YOUR_UPCOMING_SCANS_VIEW_ALL_", Utility.getTextOfPageObject(PageElements.YOUR_UPCOMING_SCANS_VIEW_ALL_LABEL), "View all");
		customVerification.verifyEquals("Dashboard Page YOUR_UPCOMING_SCANS_SCAN_NAME_COLUMN_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_UPCOMING_SCANS_SCAN_NAME_COLUMN_LABEL),
				"Scan name");
		customVerification.verifyEquals("Dashboard Page YOUR_UPCOMING_SCANS_STARTS_COLUMN_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_UPCOMING_SCANS_STARTS_COLUMN_LABEL), "Starts");
		customVerification.verifyEquals("Dashboard Page YOUR_UPCOMING_SCANS_OCCURS_COLUMN_LABEL  ", Utility.getTextOfPageObject(PageElements.YOUR_UPCOMING_SCANS_OCCURS_COLUMN_LABEL), "Occurs");

		return this;

	}
}
