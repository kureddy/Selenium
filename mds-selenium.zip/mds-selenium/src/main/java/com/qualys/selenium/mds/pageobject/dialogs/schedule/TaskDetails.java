package com.qualys.selenium.mds.pageobject.dialogs.schedule;

import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.qualys.selenium.core.CustomVerification;
import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.AbstractDialog.DialogCommonElements;

@Slf4j
public class TaskDetails extends ScheduleDialogue {

	public enum PageElements implements IPageElement {

		STEP_VERIFY_BEFORE_FILLING(".schedule-object-window .step-basic:not(.middle-inactive):not(.first-passed)"),
		STEP_VERIFY_AFTER_FILLING(".schedule-object-window .step-basic:not(.middle-inactive).first-passed"),

		SCHEDULE_NAME_TEXT_FIELD(".schedule-object-window input[name=name]"),
		SCHEDULE_NAME_ERROR_MESSAGE(".schedule-object-window input[name=name]+div[style*=\"display: block\"]"),

		SCHEDLUE_BY_SITE_RADIO_BTN(".schedule-object-window .object-panel form>div:nth-child(3) div:nth-child(2) div:nth-child(1)>div:nth-of-type(2)>input[name=reportBy]"),
		// IF SITE RADIO BUTOON IS SELECTED
		SITE_TITLE_DROPDOWN_TRIGGER(".schedule-object-window .section-panel-body .malware-domain-combobox+img:last-of-type"),
		SITE_TITLE_DROPDOWN_CONTAINER(".combobox .x-combo-list-inner "),
		SITE_TITLE_DROPDOWN_CONTAINER_ITEMS(".combobox-item .title"),
		SITE_TITLE_ERROR_MESSAGE_PRESENT(".schedule-object-window .section-panel-body input[name=malware-domain].x-form-invalid "),

		SCHEDLUE_BY_TAG_RADIO_BTN(".schedule-object-window .object-panel form>div:nth-child(3) div:nth-child(2) div:nth-child(1)>div:nth-of-type(3)>input[name=reportBy]"),
		// IF TAG RADIO BUTTON IS SELECTED
		TAG_DROPDOWN_TRIGGER(".schedule-object-window .section-panel-body #malware-scan-schedule-tag-selector span>img:last-of-type"),
		TAG_DROPDOWN_CONTAINER(".basic-tag-tree .x-tree-root-node"),
		TAG_DROPDOWN_CONTAINER_ITEMS(".basic-tag-tree .x-tree-node"),
		// TODO xpath is not clicking on close
		TAG_DROPDOWN_CLOSE_BUTN("//div[contains(@class,'x-layer')]//div[contains(text(),'Close')]", IdentifiedBy.XPATH),

		MAX_PAGES_TEXTFIELD(".schedule-object-window input[name=max-pages]"),

		// IF TAG RADIO BUTTON IS SELECTED
		SPECIFIC_SCAN_PREFERENCE_CHECKBOX("schedule-object-window .section-panel-body input[name=override-scan-preferences]"),

		SCAN_INTENSITY_TEXT_FIELD(".schedule-object-window input[name=intensity]"),
		SCAN_INTENSITY_DOWN_CONTAINER_MAXIMUM("div.x-combo-list-item:nth-child(1)"),
		SCAN_INTENSITY_DOWN_CONTAINER_HIGH("div.x-combo-list-item:nth-child(2)"),
		SCAN_INTENSITY_DOWN_CONTAINER_MEDIUM("div.x-combo-list-item:nth-child(3)"),
		SCAN_INTENSITY_DOWN_CONTAINER_LOW("div.x-combo-list-item:nth-child(4)"),
		SCAN_INTENSITY_DOWN_CONTAINER_MINIMUM("div.x-combo-list-item:nth-child(5)"),

		SCAN_DETAILS_HEADER_LABEL("//div[contains(@class,'schedule-object-window')]//span[contains(@class,'section-panel-header-text')]", IdentifiedBy.XPATH),
		SCHEDULE_NAME_LABEL("//div[contains(@class,'schedule-object-window')]//label[contains(@class,'item-label')]", IdentifiedBy.XPATH),
		REQUIRED_FIELDS_NOTICE_LABEL("css=.schedule-object-window .q-scroller:nth-of-type(1) .notice-required div"),
		SCHEDULE_BY_LABEL("//div[contains(@class,'schedule-object-window')]//div[contains(@class,'section-panel-body')]//div[contains(@class,' radio-label')]", IdentifiedBy.XPATH),
		SITE_TITLE_LABEL(".schedule-object-window .object-panel form>div:nth-child(3)>div:nth-child(2)>div>div:nth-child(3):not(.x-hide-display) label"),
		SELECT_A_TAG_LABEL(".schedule-object-window .object-panel form div:not[.x-hide-display]>label[for='malware-scan-schedule-tag-selector']"),
		SCAN_PREFERENCES_HEADER_LABEL(".schedule-object-window div.object-panel>div:nth-child(1) form>div:nth-child(4) .section-panel-header-text"),
		MAX_PAGES_LABEL(".schedule-object-window .object-panel form>div:nth-child(4)>div:nth-child(2) .section-panel-body>div:nth-child(3)>label"),
		SCAN_INTENSITY_LABEL(".schedule-object-window .object-panel form>div:nth-child(4)>div:nth-child(2) .section-panel-body>div:nth-child(4)>label"),

		;

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			return this.identifiedBy;
		}

	}

	public TaskDetails(String mode) {
		super(mode);
		if (!Utility.isElementPresent(PageElements.STEP_VERIFY_BEFORE_FILLING)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the AddSite>Site Details List page");
		}
	}

	public TaskDetails(String mode, String Previous) {
		super(mode);
		if (!Utility.isElementPresent(PageElements.STEP_VERIFY_AFTER_FILLING)) {
			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Schedule>TaskDetails List page");
		}
	}

	public TaskDetails typeScheduleName(String scheduleTitle) {

		Utility.typeInEditBox(PageElements.SCHEDULE_NAME_TEXT_FIELD, scheduleTitle);
		// Utility.waitForElementPresent(PageElements.SCHEDULE_NAME_ERROR_MESSAGE);
		/*
		 * for (int sec = 0; sec <= 10; sec++) { if
		 * (Utility.getElement(PageElements
		 * .SCHEDULE_NAME_ERROR_MESSAGE).isDisplayed() == false) { sec = 10; } }
		 */
		return this;
	}

	public TaskDetails selectScheduleByRadioButton(String siteORtag) throws ElementNotFoundException {

		boolean res = Utility.getElement(PageElements.SCHEDLUE_BY_SITE_RADIO_BTN).isSelected();
		System.out.println(res);
		if (siteORtag.equalsIgnoreCase("site")) {
			if (!Utility.getElement(PageElements.SCHEDLUE_BY_SITE_RADIO_BTN).isSelected()) {
				Utility.waitForElementPresent(PageElements.SCHEDLUE_BY_SITE_RADIO_BTN);
				Utility.selectRadioButton(PageElements.SCHEDLUE_BY_SITE_RADIO_BTN);
			} else if (Utility.getElement(PageElements.SCHEDLUE_BY_SITE_RADIO_BTN).isSelected()) {

			}
		} else if (siteORtag.equalsIgnoreCase("tag")) {
			Utility.waitForElementPresent(PageElements.SCHEDLUE_BY_TAG_RADIO_BTN);
			Utility.selectRadioButton(PageElements.SCHEDLUE_BY_TAG_RADIO_BTN);
		}

		return this;
	}

	public TaskDetails clickSiteTitleDownDown() throws ElementNotFoundException {

		Utility.waitForElementPresent(PageElements.SITE_TITLE_DROPDOWN_TRIGGER);
		if (Utility.getElement(PageElements.SCHEDLUE_BY_SITE_RADIO_BTN).isSelected()) {
			Utility.click(PageElements.SITE_TITLE_DROPDOWN_TRIGGER);
		} else {
			throw new NoSuchElementException("Schedule by Site Radio button is not selected");
		}
		return this;
	}

	public TaskDetails selectScanTitle(String siteName) throws ElementNotFoundException {
		clickSiteTitleDownDown();
		WebElement superElement = Utility.getElement(PageElements.SITE_TITLE_DROPDOWN_CONTAINER);
		Utility.selectFromCombo(PageElements.SITE_TITLE_DROPDOWN_CONTAINER_ITEMS, superElement, siteName);
		return this;
	}

	public TaskDetails clickTagDropDown() throws ElementNotFoundException{
		Utility.waitForElementPresent(PageElements.TAG_DROPDOWN_TRIGGER);
		if (Utility.getElement(PageElements.SCHEDLUE_BY_TAG_RADIO_BTN).isSelected()) {
			Utility.click(PageElements.TAG_DROPDOWN_TRIGGER);
		} else {
			throw new NoSuchElementException("Schedule by Tag is not selected");

		}
		return this;
	}

	public TaskDetails selectTag(String tagName) throws ElementNotFoundException{

		clickTagDropDown();
		Utility.waitForElementPresent(PageElements.TAG_DROPDOWN_CONTAINER);
		WebElement superElement = Utility.getElement(PageElements.TAG_DROPDOWN_CONTAINER);
		Utility.waitForElementPresent(PageElements.TAG_DROPDOWN_CONTAINER_ITEMS);
		Utility.selectMultipleValuesDoubleClick(PageElements.TAG_DROPDOWN_CONTAINER_ITEMS, superElement, tagName);
		clickTagDropDownCloseButton();
		return this;
	}

	// TODO --> XPATH is not clicking on close of tag dropdown
	public TaskDetails clickTagDropDownCloseButton() {
		// Utility.click();
		return this;
	}

	public TaskDetails typeMaximumPages(String numberOfPages) {

		Utility.typeInEditBox(PageElements.MAX_PAGES_TEXTFIELD, numberOfPages);
		return this;
	}

	public TaskDetails selectScanIntensity(String intensityLevel) {

		Utility.click(PageElements.SCAN_INTENSITY_TEXT_FIELD);

		if (intensityLevel.equalsIgnoreCase("Maximum")) {
			Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_MAXIMUM);
		} else if (intensityLevel.equalsIgnoreCase("High")) {

			Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_HIGH);

		} else if (intensityLevel.equalsIgnoreCase("Medium")) {

			Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_MEDIUM);

		} else if (intensityLevel.equalsIgnoreCase("Low")) {
			Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_LOW);

		} else if (intensityLevel.equalsIgnoreCase("Minimum")) {
			Utility.click(PageElements.SCAN_INTENSITY_DOWN_CONTAINER_MINIMUM);
		}
		return this;
	}

	public SchedulingOptions clickContinue() {
		Utility.click(DialogCommonElements.CONTINUE_BTN);
		return new SchedulingOptions(scheduleDialogMode);
	}

	public void clickCancel() {
		Utility.click(DialogCommonElements.CANCEL_BTN);
	}

	public TaskDetails verifyTaskDetailsStepStaticText() {
		CustomVerification customVerification = new CustomVerification();

		customVerification.verifyEquals("Task details step SCAN_DETAILS_HEADER_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_DETAILS_HEADER_LABEL), "Scan details");

		customVerification.verifyEquals("Task details step SCHEDULE_NAME_LABEL", Utility.getTextOfPageObject(PageElements.SCHEDULE_NAME_LABEL), "Schedule Name");

		customVerification.verifyEquals("Task details step SCHEDULE_BY_LABEL", Utility.getTextOfPageObject(PageElements.SCHEDULE_BY_LABEL), "Schedule by");

		customVerification.verifyEquals("Task details step SITE_TITLE_LABEL", Utility.getTextOfPageObject(PageElements.SITE_TITLE_LABEL), "Site Title*");

		try {
			selectScheduleByRadioButton("tag");

			Utility.waitForElementPresent(PageElements.SELECT_A_TAG_LABEL);
		} catch (Exception e) {
			log.error("Could not select tag", e);
		}
		customVerification.verifyEquals("Task details step SELECT_A_TAG_LABEL", Utility.getTextOfPageObject(PageElements.SELECT_A_TAG_LABEL), "Select a tag");

		customVerification.verifyEquals("Task details step SCAN_PREFERENCES_HEADER_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_PREFERENCES_HEADER_LABEL), "Scan Preferences");

		customVerification.verifyEquals("Task details step MAX_PAGES_LABEL", Utility.getTextOfPageObject(PageElements.MAX_PAGES_LABEL), "Maximum Pages*");

		customVerification.verifyEquals("Task details step SCAN_INTENSITY_LABEL", Utility.getTextOfPageObject(PageElements.SCAN_INTENSITY_LABEL), "Scan Intensity*");

		customVerification.verifyEquals("Task details step CONTINUE_BTN ", Utility.getTextOfPageObject(DialogCommonElements.CONTINUE_BTN), "Continue");

		customVerification.verifyEquals("Task details step CANCEL_BTN ", Utility.getTextOfPageObject(DialogCommonElements.CANCEL_BTN), "Cancel");

		return this;
	}
}
