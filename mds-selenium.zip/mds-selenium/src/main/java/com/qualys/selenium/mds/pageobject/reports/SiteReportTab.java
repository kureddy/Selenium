package com.qualys.selenium.mds.pageobject.reports;

import lombok.extern.slf4j.Slf4j;

import com.qualys.selenium.core.Utility;
import com.qualys.selenium.core.Utility.IPageElement;
import com.qualys.selenium.core.Utility.IdentifiedBy;
import com.qualys.selenium.customexceptions.ElementNotFoundException;
import com.qualys.selenium.mds.pageobject.dialogs.reports.saveReport.siteReport.CompressedHTMLSiteReport;
import com.qualys.selenium.mds.pageobject.dialogs.reports.saveReport.siteReport.EncryptedPortableDocumentPdfSiteReport;
import com.qualys.selenium.mds.pageobject.dialogs.reports.saveReport.siteReport.PortableDocFormatPdfSiteReport;

@Slf4j
public class SiteReportTab extends ReportsPage {
	public enum PageElements implements IPageElement {

		SITE_REPORT_TAB_VERIFY("div:not(.x-hide-display)[id*=report-asset]  div[class*=panel-body]"),

		SAVE_REPORT_BTN("div:not(.x-hide-display)[id*=report-asset] div[class*=report-header] div[class*=small-editor] td[class*=toolbar-right] table[class*=blue-dark] button[class*=btn-text]"),
		// COMPRESSED_HTML_PAGES("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(1)"),
		COMPRESSED_HTML_PAGES("div:not(.x-hide-offsets)[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(1)"),
		PORTABLE_DOCUMENT_FORMAT("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(2)"),
		ENCRYPTED_PORTABLE_DOCUMENT("div[class*=menu-floating] ul[class*=menu-list] li:nth-of-type(3)"),

		SITE_REPORT_TITLE_CHANGE_BTN_LINK("div:not(.x-hide-display)[id*=report-asset] div[class*=form-composite] table:nth-of-type(1):not(.x-hide-display)[class*=action] button"),
		SITE_REPORT_TITLE_SAVE_BTN_LINK("div:not(.x-hide-display)[id*=report-asset] div[class*=form-composite] table:nth-of-type(2):not(.x-hide-display)[class*=action] button"),
		SITE_REPORT_TITLE_CANCEL_BTN_LINK("div:not(.x-hide-display)[id*=report-asset] div[class*=form-composite] table:nth-of-type(3):not(.x-hide-display)[class*=action] button"),

		SITE_REPORT_CLOSE(
				"div[id=FrameModuleCardPanel] div:not(x-hide-display)[id=reporting] div[class*=tab-container-header-panel] div[class*=section-tabs-tab-selected] span[title='Site report']+span[class*='-close']"),

		SITE_REPORT_TITLE_TEXTBOX("div:not(.x-hide-display)[id*=report-asset] div[class*=report-header-title] input[class*=edit-field]"),

		SITE_REPORT_TAB_MASK("div[class*=el-mask]");

		String key;
		IdentifiedBy identifiedBy;

		PageElements(String key, IdentifiedBy identifiedBy) {
			this.key = key;
			this.identifiedBy = identifiedBy;
		}

		PageElements(String key) {
			this(key, IdentifiedBy.CSS);
		}

		@Override
		public String getLocator() {
			// TODO Auto-generated method stub
			return this.key;
		}

		@Override
		public IdentifiedBy getIdentifiedBy() {
			// TODO Auto-generated method stub
			return this.identifiedBy;
		}

	}

	public SiteReportTab() throws ElementNotFoundException {
		
		 //waitForPageToMask();
		 waitForPageToUnMask();
		if (!Utility.isElementPresent(PageElements.SITE_REPORT_TAB_VERIFY)) {

			log.info("Currently at url : {}", Utility.getCurrentUrl());
			throw new IllegalStateException("This is not the Scans>Scan List page");
		}
	}

	

	public void waitForPageToMask() throws ElementNotFoundException {
		try {
			log.info("waiting for site report tab to mask");
			Utility.waitForElementPresent(PageElements.SITE_REPORT_TAB_MASK);
		} catch (ElementNotFoundException e) {
			waitForPageToUnMask();
		}

	}

	public void waitForPageToUnMask() {
		log.info("waiting for site report tab to unmask");
		Utility.waitUntilElementDissAppears(PageElements.SITE_REPORT_TAB_MASK);

	}

	public SiteReportTab clickOnSaveReportDropDownBtn() {
		Utility.click(PageElements.SAVE_REPORT_BTN);
		return this;
	}

	public CompressedHTMLSiteReport selectCompressedHTML() throws ElementNotFoundException {
		clickOnSaveReportDropDownBtn();
		Utility.click(PageElements.COMPRESSED_HTML_PAGES);
		return new CompressedHTMLSiteReport();
	}

	public PortableDocFormatPdfSiteReport selectPortableDocFormatPDF() throws ElementNotFoundException {
		clickOnSaveReportDropDownBtn();
		Utility.click(PageElements.PORTABLE_DOCUMENT_FORMAT);
		return new PortableDocFormatPdfSiteReport();
	}

	public EncryptedPortableDocumentPdfSiteReport selectEncryptedDocFormatPDF() throws ElementNotFoundException {
		clickOnSaveReportDropDownBtn();
		Utility.click(PageElements.ENCRYPTED_PORTABLE_DOCUMENT);
		return new EncryptedPortableDocumentPdfSiteReport();
	}

	public SiteReportTab clickChangeBtnLink() throws ElementNotFoundException {

		// Utility.waitForElementPresent(PageElements.SITE_REPORT_TAB_VERIFY);
		waitForPageToUnMask();
		Utility.waitForElementPresent(PageElements.SITE_REPORT_TITLE_CHANGE_BTN_LINK);
		Utility.click(PageElements.SITE_REPORT_TITLE_CHANGE_BTN_LINK);

		return this;
	}

	public SiteReportTab clickSaveBtnLink() {
		Utility.click(PageElements.SITE_REPORT_TITLE_SAVE_BTN_LINK);
		return this;
	}

	public SiteReportTab clickCancelBtnLink() {
		Utility.click(PageElements.SITE_REPORT_TITLE_CANCEL_BTN_LINK);
		return this;
	}

	public SiteReportTab editAndSaveSiteReportTitle(String scanTitle) throws ElementNotFoundException {
		clickChangeBtnLink();
		log.info("Clicked on CHANGE link to rename scan title");
		Utility.typeInEditBox(PageElements.SITE_REPORT_TITLE_TEXTBOX, scanTitle);
		log.info("Renamed scan title to : " + scanTitle);
		clickSaveBtnLink();
		log.info("Clicked on save button.Scan title name has changed");
		return this;
	}

	public ReportListTab closeSiteReport() throws ElementNotFoundException {
		Utility.waitForElementPresent(PageElements.SITE_REPORT_TAB_VERIFY);
		Utility.click(PageElements.SITE_REPORT_CLOSE);
		return new ReportListTab();
	}
}
